require("./lib/function.js");
const { Telegraf } = require("telegraf");
const config = require("./config");
const DataBase = require("./lib/database.js");
const ubotManager = require("./lib/ubotManager");

const database = new DataBase();

(async () => {
  // ── Load database global ──────────────────────────────────────
  const load = await database.read() || {};
  global.db = {
    users: load.users || {},
    groups: load.groups || {},
    settings: load.settings || {}
  };
  await database.write(global.db);
  setInterval(() => database.write(global.db), 2000);

  // ── Launch bot manager (Telegraf) ─────────────────────────────
  const bot = new Telegraf(config.botToken);

  bot.catch((err, ctx) => {
    console.error(`❌ Error Telegraf [${ctx.updateType}]:`, err.message);
    if (err.response?.error_code === 429) {
      console.warn(`⚠️ Rate limit. Retry after ${err.response.parameters.retry_after}s`);
    }
  });

  // Load bot.js (handler command bot manager + flow login)
  require("./bot")(bot);

  bot.launch();
  console.log("• Bot Manager aktif");
  console.log(`• Owner ID: ${config.ownerId}`);

  // ── Restore semua userbot aktif setelah bot siap ──────────────
  setTimeout(async () => {
    await ubotManager.restoreAll(bot);
  }, 3000);

  // ── Graceful shutdown ─────────────────────────────────────────
  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
})();