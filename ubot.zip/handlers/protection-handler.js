const PTERO_PATH = '/var/www/pterodactyl';

/**
 * File ini berisi contoh skrip untuk proteksi panel Pterodactyl.
 * Perintah yang sebenarnya mungkin lebih kompleks dan bergantung pada versi panel.
 * Skrip ini adalah contoh dan harus diverifikasi dan disesuaikan.
 * Umumnya melibatkan perubahan izin file, penggantian file, atau menggunakan `sed` untuk mengubah konten.
 */
const protectionScripts = {
    // 1: Anti Edit Settings (Admin)
    1: {
        install: `chmod 640 ${PTERO_PATH}/.env && echo "✅ Protection 1 Installed: .env file locked."`,
        uninstall: `chmod 664 ${PTERO_PATH}/.env && echo "✅ Protection 1 Uninstalled: .env file unlocked."`
    },
    // 2: Anti Edit Users
    2: {
        install: `echo "Installing protection 2 (Anti Edit Users)... This is a placeholder." # Placeholder`,
        uninstall: `echo "Uninstalling protection 2... This is a placeholder." # Placeholder`
    },
    // 3: Anti Intip Locations
    3: {
        install: `mv ${PTERO_PATH}/resources/scripts/routers/admin/locations ${PTERO_PATH}/resources/scripts/routers/admin/locations.bak && echo "✅ Protection 3 Installed: Locations page hidden."`,
        uninstall: `mv ${PTERO_PATH}/resources/scripts/routers/admin/locations.bak ${PTERO_PATH}/resources/scripts/routers/admin/locations && echo "✅ Protection 3 Uninstalled: Locations page restored."`
    },
    // 4: Anti Intip Nodes
    4: {
        install: `mv ${PTERO_PATH}/resources/scripts/routers/admin/nodes ${PTERO_PATH}/resources/scripts/routers/admin/nodes.bak && echo "✅ Protection 4 Installed: Nodes page hidden."`,
        uninstall: `mv ${PTERO_PATH}/resources/scripts/routers/admin/nodes.bak ${PTERO_PATH}/resources/scripts/routers/admin/nodes && echo "✅ Protection 4 Uninstalled: Nodes page restored."`
    },
    // 5: Anti Intip Nests
    5: {
        install: `mv ${PTERO_PATH}/resources/scripts/routers/admin/nests ${PTERO_PATH}/resources/scripts/routers/admin/nests.bak && echo "✅ Protection 5 Installed: Nests page hidden."`,
        uninstall: `mv ${PTERO_PATH}/resources/scripts/routers/admin/nests.bak ${PTERO_PATH}/resources/scripts/routers/admin/nests && echo "✅ Protection 5 Uninstalled: Nests page restored."`
    },
    // 6: Anti Edit Panel Settings
    6: {
        install: `echo "Installing protection 6 (Anti Edit Panel Settings)... This is a placeholder." # Placeholder`,
        uninstall: `echo "Uninstalling protection 6... This is a placeholder." # Placeholder`
    },
    // 7: Anti Akses File Server
    7: {
        install: `echo "Installing protection 7 (Anti Akses File Server)... This is a placeholder." # Placeholder`,
        uninstall: `echo "Uninstalling protection 7... This is a placeholder." # Placeholder`
    },
    // 8: Anti Intip Server
    8: {
        install: `echo "Installing protection 8 (Anti Intip Server)... This is a placeholder." # Placeholder`,
        uninstall: `echo "Uninstalling protection 8... This is a placeholder." # Placeholder`
    },
    // 9: Anti Intip Application API
    9: {
        install: `mv ${PTERO_PATH}/resources/scripts/routers/admin/api ${PTERO_PATH}/resources/scripts/routers/admin/api.bak && echo "✅ Protection 9 Installed: API page hidden."`,
        uninstall: `mv ${PTERO_PATH}/resources/scripts/routers/admin/api.bak ${PTERO_PATH}/resources/scripts/routers/admin/api && echo "✅ Protection 9 Uninstalled: API page restored."`
    },
    // 10: Anti Create Client API Key
    10: {
        install: `echo "Installing protection 10 (Anti Create Client API Key)... This is a placeholder." # Placeholder`,
        uninstall: `echo "Uninstalling protection 10... This is a placeholder." # Placeholder`
    },
    // 11: Anti Intip Database
    11: {
        install: `mv ${PTERO_PATH}/resources/scripts/routers/admin/databases ${PTERO_PATH}/resources/scripts/routers/admin/databases.bak && echo "✅ Protection 11 Installed: Databases page hidden."`,
        uninstall: `mv ${PTERO_PATH}/resources/scripts/routers/admin/databases.bak ${PTERO_PATH}/resources/scripts/routers/admin/databases && echo "✅ Protection 11 Uninstalled: Databases page restored."`
    },
    // 12: Anti Intip Mounts
    12: {
        install: `mv ${PTERO_PATH}/resources/scripts/routers/admin/mounts ${PTERO_PATH}/resources/scripts/routers/admin/mounts.bak && echo "✅ Protection 12 Installed: Mounts page hidden."`,
        uninstall: `mv ${PTERO_PATH}/resources/scripts/routers/admin/mounts.bak ${PTERO_PATH}/resources/scripts/routers/admin/mounts && echo "✅ Protection 12 Uninstalled: Mounts page restored."`
    },
    // 13: Anti Button Two Factor
    13: {
        install: `echo "Installing protection 13 (Anti Button Two Factor)... This is a placeholder." # Placeholder`,
        uninstall: `echo "Uninstalling protection 13... This is a placeholder." # Placeholder`
    },
    // 14: Hide Menu Admin
    14: {
        install: `echo "Installing protection 14 (Hide Menu Admin)... This is a placeholder." # Placeholder`,
        uninstall: `echo "Uninstalling protection 14... This is a placeholder." # Placeholder`
    }
};

function execute(ssh, command, onProgress) {
    return new Promise((resolve, reject) => {
        ssh.exec(command, (err, stream) => {
            if (err) return reject(err);
            stream.on('close', (code) => {
                if (code !== 0) return reject(new Error(`Command failed with exit code ${code}`));
                resolve();
            }).on('data', (data) => onProgress(data.toString()))
              .stderr.on('data', (data) => onProgress(`[STDERR] ${data.toString()}`));
        });
    });
}

async function handleProtection(ssh, type, protectNum, onProgress) {
    const script = protectionScripts[protectNum]?.[type];
    if (!script) throw new Error(`Script for protection ${protectNum} (${type}) not found.`);

    onProgress(`Executing script for Protect ${protectNum} (${type})...\n`);
    onProgress(`------------------------------------\n`);
    
    const commandToRun = `cd ${PTERO_PATH} && ${script}`;
    await execute(ssh, commandToRun, onProgress);

    onProgress(`------------------------------------\n`);
    onProgress(`Panel rebuild might be needed for changes to take effect.\n`);
    onProgress(`Running: yarn build:production\n`);
    
    await execute(ssh, `cd ${PTERO_PATH} && yarn build:production`, onProgress);
}

module.exports = { handleProtection };