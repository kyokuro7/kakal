
module.exports = {
  /**
   * ===== TELEGRAM API =====
   */
  apiId: 36040039, // api_id Telegram (didapat dari my.telegram.org)
  apiHash: "GANTI_API_HASH", // api_hash Telegram
  sessionFile: "./session.txt", // File penyimpanan session Telegram (login user)
  vpsSessionFile: "./vps_sessions.json", // File penyimpanan sesi login VPS

  /**
   * ===== BOT CONFIG =====
   */
  botToken: "GANTI_BOT_TOKEN", // Gak usah diganti
  botUsername: "xyubots_bot", // gak usah diganti

  /**
   * ===== TAMPILAN & UMUM =====
   */
  prefix: "x", // Prefix command bot (contoh: .menu)
  
  /**
   * ===== OWNER BOT =====
   */
  ownerName: "Xynoz Dev", // Nama owner
  ownerId: "8466192481", // User ID Telegram owner (hak penuh)

  /**
   * ===== CHANNEL LOG =====
   */
  doneLogChannel: "testixynoz", // Username channel untuk log transaksi 'done' (tanpa @)

  /**
   * ===== PAYMENT METHOD =====
   */
  payment: {
    qris: "Masukinlinkfotoqrislu", // QRIS (gambar)
    dana: "085179920155", // Nomor DANA
    ovo: "085179920155", // OVO belum tersedia
    gopay: "085179920155" // GoPay belum tersedia
  },

  /**
   * ===== PAKASIR API =====
   * Digunakan untuk fitur QRIS
   */
  pakasir: {
    baseUrl: "https://app.pakasir.com/api",
    apiKey: "MASUKIN_APIKEY_PAKASIR", // Ganti dengan API Key Pakasir Anda
    projectSlug: "xynoz", // Ganti dengan Project Slug Pakasir Anda
    endpoints: {
      createQris: "/transactioncreate/qris",
      checkStatus: "/transactiondetail",
      cancel: "/transactioncancel"
    }
  },

  /**
   * ===== DIGITALOCEAN API =====
   */
  digitalOcean: {
    apiToken: "YOUR_DIGITALOCEAN_API_TOKEN", // Ganti dengan API Token DigitalOcean Anda
  },

  /**
   * ===== SUBDOMAIN (CLOUDFLARE) =====
   * Digunakan untuk create / delete DNS record (subdomain)
   */
  subdomain: {
    "naell.my.id": {
      zone: "090a81422da7b258cdf3ef02de1e4ca3", // Zone ID Cloudflare
      apitoken: "hmph2bybLMWa-_4EgVhQqi3lSXYaKgWgyXVMwzm_" // API Token Cloudflare
    },

    "apcb.biz.id": {
      zone: "01592fa9553ff4692ed443e5932ff285",
      apitoken: "le350OqR25wWm5SpSJpcTbalOaTOKJA3FcRV4ohK"
    },

    "panelwebsite.biz.id": {
      zone: "2d6aab40136299392d66eed44a7b1122",
      apitoken: "SbRAPRzC34ccmf4cJs-0qZ939yHe3Ko6CpolxqW4"
    },

    "publicserverr.my.id": {
      zone: "b23d82b98aa932317c93571a3846240a",
      apitoken: "2ltJMUmL2QZ-H3IQ0NGM8n84zxoJlU1D8Wwj26AB"
    },

    "tamaoffc.biz.id": {
      zone: "177538af7fb12443a80892554d01206f",
      apitoken: "ZaVSjxa96NQDV6lQgspAVsVXrvVzdOpqL1z6PG0Z"
    },

    "orang-gantengg.biz.id": {
      zone: "a9dd58ec424aa4bb2439d0c569d07573",
      apitoken: "3rDda7Q7k6N19CXpfGVoq3WOpCatxmDlnQHVjWWC"
    },

    "naell.cloud": {
      zone: "1b662cae2a8214a8468c97fb552070d0",
      apitoken: "EX4ezkgaSvD3JeXeKoDQzfmqI_Mh0yUek7WmDO0u"
    },
    
    "mamhost.biz.id": {
      zone: "d88dccee1fd5fd2dcd47ddb7c91e2591",
      apitoken: "3rDda7Q7k6N19CXpfGVoq3WOpCatxmDlnQHVjWWC"
    },
    
    "xyzmam.biz.id": {
      zone: "49bb8266d07adee6b8b0999db470f45d",
      apitoken: "3rDda7Q7k6N19CXpfGVoq3WOpCatxmDlnQHVjWWC"
    },
    
    "xyzmamhost.my.id": {
      zone: "0b61c1c8287675fcbc9c5894cb3d1b92",
      apitoken: "3rDda7Q7k6N19CXpfGVoq3WOpCatxmDlnQHVjWWC"
    },
    
    "cellopanel.biz.id": {
      zone: "7f050dec96464f9a2fc7378fe3c5732e",
      apitoken: "HvyLDbp1COydVHNQCpQx6qB-e28hMYHlIPL9RjxE"
    },
    
    "perzxlystore.my.id": {
      zone: "588e8e8b0bd0e0a4831db9ac56ea06ef",
      apitoken: "NXv3mKs2zFsg-Sk4VEVeq3WLVIUJFqEAJsqWMLfC"
    },
    
    "vinzzstrr.biz.id": {
      zone: "e2c96b428cbb4dad91a467b7b3e13e93",
      apitoken: "68h5Vxh9oShK7KRvUkLY38uzkWDsmj7Yan1soj0u"
    },
    
    "jhonaley.web.id": {
      zone: "dd00b76d94af1e8d5f37f4253f77861f",
      apitoken: "TWeBC584CrKxdR_o2Uo4Wlow8miuhHJ-ZfUvKPgT"
    },
    
    "anti-ddos.me": {
      zone: "3f33f6c4b5a3dd00ed16d1eb7677338e",
      apitoken: "le350OqR25wWm5SpSJpcTbalOaTOKJA3FcRV4ohK"
    },
    
    "pterohost.biz.id": {
      zone: "f5979b1cd5814d962b3c7672ccb2ec25",
      apitoken: "6xAnCuFXgtf14nMgKoyvyLr5TJ-QpsICkysixABL"
    },
    
    "centzzcloud.my.id": {
      zone: "749f1d7d69e9329195761b570010c00f",
      apitoken: "9Su8A1EDXnt9-yGDb7YSGlY_ogJAw2vR9IDtpFrQ"
    },
    
    "ashrixweb.my.id": {
      zone: "bd24c7d262fa83cedd0e14f1204c65b5",
      apitoken: "NbHGsj8sV87dAHonygjt-w66Qg0OIrzMXANzrLRR"
    }
  },

  /**
   * KONFIGURASI PTERODACTYL PANEL
   * ===============================
   */
  /**
   * ===== PAKET UBOT =====
   * Harga dalam Rupiah, durasi dalam hari (0 = permanen)
   */
  paketUbot: [
    { id: "1bulan",   label: "1 Bulan",    harga: 15000,  hari: 30  },
    { id: "3bulan",   label: "3 Bulan",    harga: 35000,  hari: 90  },
    { id: "permanen", label: "Permanen",   harga: 75000,  hari: 0   },
  ],

  egg: "15",       // ID Egg (jenis server)
  nestid: "5",     // ID Nest
  loc: "1",        // ID Location
  domain: "https://xavierpublic.jhonaley.web.id", // URL panel Pterodactyl
  apikey: "ptla_f8XhYrVKYgHjFoYGnogO9XsDBKngViLPh4W2pRxO00n",   // API Key PTLA (Application API)
  capikey: "ptlc_i5yvmfXtSUFtOZ5MaC9VqWyUT6TRv1s5dzaLxmFq5EH"   // API Key PTLC (Client API)
};