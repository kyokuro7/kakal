require("./lib/function.js");
const fs = require("fs");
const { NewMessage } = require("telegram/events/NewMessage");
const axios = require("axios");
const { CallbackQuery } = require("telegram/events/CallbackQuery");
const rimraf = require("rimraf");
const { Api } = require("telegram");
const FormData = require("form-data");
const archiver = require("archiver");
const config = require("./config");
const PDFDocument = require('pdfkit');
const path = require("path");
const { CustomFile } = require("telegram/client/uploads");
const { handleProtection } = require("./handlers/protection-handler.js");
const { Client: SSHClient } = require("ssh2");

const cvpsSessions = new Map();

function readVpsSessions() {
    try {
        if (fs.existsSync(config.vpsSessionFile)) {
            const data = fs.readFileSync(config.vpsSessionFile, 'utf8');
            const obj = JSON.parse(data);
            return new Map(Object.entries(obj));
        }
        fs.writeFileSync(config.vpsSessionFile, '{}', 'utf8');
        return new Map();
    } catch (error) {
        console.error("Error membaca vps_sessions.json:", error);
        return new Map();
    }
}

function writeVpsSessions(sessions) {
    try {
        const obj = Object.fromEntries(sessions);
        fs.writeFileSync(config.vpsSessionFile, JSON.stringify(obj, null, 2), 'utf8');
    } catch (error) {
        console.error("Error menulis ke vps_sessions.json:", error);
    }
}

const vpsLoginSessions = readVpsSessions();
let promotionJobs = {};
let autoBcJobs = {}; // autobc jobs storage

const protectDescriptions = {
  1: {
    title: "Anti Edit Settings",
    desc: [
      "Mengunci menu Settings",
      "Hanya Admin ID 1 yang dapat mengubah konfigurasi panel"
    ]
  },
  2: {
    title: "Anti Edit Users",
    desc: [
      "Mencegah user mengedit data user lain",
      "Proteksi penuh menu Users"
    ]
  },
  3: {
    title: "Anti Intip Locations",
    desc: [
      "Mengunci menu Locations",
      "User selain Admin ID 1 akan diblokir (403)"
    ]
  },
  4: {
    title: "Anti Intip Nodes",
    desc: [
      "Menutup akses menu Nodes",
      "Node hanya terlihat oleh Admin utama"
    ]
  },
  5: {
    title: "Anti Intip Nests",
    desc: [
      "Melindungi menu Nests",
      "User biasa tidak bisa melihat Egg & Nest"
    ]
  },
  6: {
    title: "Anti Edit Panel Settings",
    desc: [
      "Mengunci seluruh menu Settings panel",
      "Mencegah sabotase konfigurasi"
    ]
  },
  7: {
    title: "Anti Akses File Server",
    desc: [
      "Mencegah akses file server orang lain",
      "Anti download, edit, rename file ilegal"
    ]
  },
  8: {
    title: "Anti Intip Server",
    desc: [
      "Server hanya bisa diakses owner",
      "Anti intip detail server user lain"
    ]
  },
  9: {
    title: "Anti Intip Application API",
    desc: [
      "Mengunci menu Application API",
      "Khusus Admin ID 1 create & delete API"
    ]
  },
  10: {
    title: "Anti Create Client API Key",
    desc: [
      "Mencegah user membuat Client API Key",
      "API Key hanya untuk Admin utama"
    ]
  },
  11: {
    title: "Anti Intip Database",
    desc: [
      "Mengunci menu Database",
      "User lain tidak bisa melihat DB Host"
    ]
  },
  12: {
    title: "Anti Intip Mounts",
    desc: [
      "Melindungi menu Mounts",
      "Mount hanya bisa dikelola Admin utama"
    ]
  },
  13: {
    title: "Anti Button Two Factor",
    desc: [
      "Menutup akses pengaturan 2FA",
      "Hanya Admin ID 1 bisa enable / disable"
    ]
  },
  14: {
    title: "Hide Menu Admin",
    desc: [
      "Menyembunyikan menu sensitif Admin",
      "Nodes, Locations, API, DB tidak terlihat user"
    ]
  }
};

function escapehtml(text) {
    if (!text || typeof text !== 'string') return '';
    return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

function readBlacklist() {
    try {
        const data = fs.readFileSync('./blacklist.json', 'utf8');
        return JSON.parse(data);
    } catch (error) {
        if (error.code === 'ENOENT') {
            // Jika file tidak ada, buat file baru dengan array kosong
            fs.writeFileSync('./blacklist.json', '[]', 'utf8');
            return [];
        }
        console.error("Error membaca blacklist.json:", error);
        return [];
    }
}

function writeBlacklist(data) {
    try {
        fs.writeFileSync('./blacklist.json', JSON.stringify(data, null, 2), 'utf8');
    } catch (error) {
        console.error("Error menulis ke blacklist.json:", error);
    }
}

async function sendAlbum(client, msg, chatId, imageUrls, caption = "") {
    const media = [];
    const tempFiles = [];
    try {
        for (let i = 0; i < imageUrls.length; i++) {
            const res = await axios.get(imageUrls[i], { responseType: "arraybuffer" });
            const tmpPath = `./tmp/album_${Date.now()}_${i}.jpg`;
            fs.writeFileSync(tmpPath, res.data);
            tempFiles.push(tmpPath);
            const uploaded = await client.uploadFile({
                file: new CustomFile(path.basename(tmpPath), fs.statSync(tmpPath).size, tmpPath),
                workers: 1
            });
            media.push(new Api.InputMediaUploadedPhoto({
                file: uploaded,
                ...(i === 0 ? { message: caption || "" } : {}) // Pastikan message selalu string
            }));
        }
        return await client.sendFile(chatId, { // Menggunakan multiMedia untuk album
            multiMedia: media,
            caption: caption || "", // Pastikan caption selalu string
            replyTo: msg.id,
            parseMode: "html"
        });
    } finally {
        for (const file of tempFiles) {
            if (fs.existsSync(file)) fs.unlinkSync(file);
        }
    }
}

function setTempData(data, type, ttl = 600000) {
    const cacheId = `cache_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const cacheData = { ...data, type: type, timestamp: Date.now() };
    global.tempData[cacheId] = cacheData;
    console.log(`Cache set: ${cacheId}, type: ${type}, data keys:`, Object.keys(data));
    setTimeout(() => {
        if (global.tempData[cacheId]) {
            console.log(`Cache expired: ${cacheId}`);
            delete global.tempData[cacheId];
        }
    }, ttl);
    return cacheId;
}

async function sendInline(client, chatId, query) {
    try {
        const botEntity = await client.getInputEntity(config.botUsername);
        const peer = await client.getInputEntity(chatId);
        console.log("[INLINE] Querying:", query, "| bot:", config.botUsername);
        const results = await client.invoke(new Api.messages.GetInlineBotResults({ bot: botEntity, peer, query, offset: "" }));
        console.log("[INLINE] Results count:", results.results.length);
        if (results.results.length) await client.invoke(new Api.messages.SendInlineBotResult({ peer, queryId: results.queryId, id: results.results[0].id, hideVia: true }));
    } catch (e) {
        console.error("[INLINE ERROR]", e.message);
    }
}

async function getDoData(endpoint) {
    if (!config.digitalOcean?.apiToken) throw new Error("API Token DigitalOcean belum diatur.");
    const { data } = await axios.get(`https://api.digitalocean.com/v2/${endpoint}?per_page=200`, {
        headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` }
    });
    return data;
}

function createProgressBar(percentage, length = 20) {
    const filledLength = Math.round(length * (percentage / 100));
    const emptyLength = length - filledLength;
    const filled = '█'.repeat(filledLength);
    const empty = '░'.repeat(emptyLength);
    return `[${filled}${empty}]`;
}

module.exports = (client, bot) => {
    /**
     * Handles all broadcast-like functionality (cfd, bc, gikes).
     * This function is placed inside the module export to have access to the `client` instance.
     */
    async function handleBroadcast(msg, { targetType, actionType }) {
        const chatId = msg.chatId;
        const fromId = msg?.senderId || msg?.fromId?.userId || "";
        const me = await client.getMe();
        const myId = me.id.toString();
        const isOwner = fromId.toString() === config.ownerId?.toString() || fromId.toString() === myId;
        const prefix = config.prefix;
        const command = msg.message.split(' ')[0];

        if (global.statusBc) return msg.reply({ message: `⚠️ Masih ada proses ${global.bcType} yang berjalan. Hentikan dengan ${prefix}stopbc` });

        if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
        if (!msg.replyTo) return client.sendMessage(chatId, { message: `<b>Contoh:</b> Balas pesan lalu ketik <code>${command}</code>`, replyTo: msg.id, parseMode: "html" });

        const replied = await msg.getReplyMessage();
        if (!replied) return msg.reply({ message: "⚠️ Tidak dapat menemukan pesan yang dibalas." });

        const msgId = replied.id;
        const fromPeer = replied.chatId;
        const dialogs = await client.getDialogs();
        const blacklist = readBlacklist();
        let targets = [];

        const filterMap = {
            'group': d => d.isGroup,
            'user': d => d.isUser && !d.entity.bot && d.entity.id.toString() !== myId,
            'channel': d => d.isChannel && !d.isGroup,
            'all_gc': d => d.isGroup || (d.isChannel && !d.isGroup),
            'semua': d => (d.isGroup || (d.isChannel && !d.isGroup) || (d.isUser && !d.entity.bot && d.entity.id.toString() !== myId))
        };

        const filterFunc = filterMap[targetType];
        if (!filterFunc) return msg.reply({ message: "⚠️ Tipe target tidak valid." });

        targets = dialogs.filter(d => filterFunc(d) && !blacklist.includes(d.id.toString()));

        const total = targets.length;
        if (total === 0) return msg.reply({ message: `Tidak ada target ${targetType} yang ditemukan.` });

        let sukses = 0, gagal = 0, processed = 0, failedNames = [];
        const actionVerb = { 'copy': 'Copy', 'forward': 'Forward', 'broadcast': 'Broadcast' }[actionType];
        global.statusBc = true;
        global.bcType = actionVerb;

        const statusMsg = await msg.reply({ message: `🚀 Memulai ${actionVerb} ke ${total} ${targetType}...`, parseMode: "html" });

        const updateStatus = async () => {
            const percentage = Math.round((processed / total) * 100);
            const progressBar = createProgressBar(percentage, 10);
            const progressText = `**🚀 ${actionVerb} sedang berjalan...**\n\n${progressBar} ${percentage}%\n\n▫️ **Proses:** ${processed} / ${total}\n✅ **Sukses:** ${sukses}\n❌ **Gagal:** ${gagal}`;
            try { await client.editMessage(statusMsg.chatId, { message: statusMsg.id, text: progressText, parseMode: "markdown" }); } catch (e) {}
        };

        for (const d of targets) {
            if (!global.statusBc) {
                let stopText = `⏹️ **${actionVerb} Dihentikan!**\n\n▫️ **Proses:** ${processed} / ${total}\n✅ **Sukses:** ${sukses}\n❌ **Gagal:** ${gagal}`;
                await client.editMessage(statusMsg.chatId, { message: statusMsg.id, text: stopText, parseMode: "markdown" });
                delete global.statusBc;
                delete global.bcType;
                return;
            }
            processed++;
            try {
                if (actionType === 'copy') {
                    const copyOptions = { message: replied.message || "" };
                    if (replied.media) {
                        copyOptions.file = replied.media;
                    }
                    await client.sendMessage(d.id, copyOptions);
                }
                else if (actionType === 'forward') await client.forwardMessages(d.id, { messages: [msgId], fromPeer: fromPeer, dropAuthor: false });
                else if (actionType === 'broadcast') await client.forwardMessages(d.id, { messages: [msgId], fromPeer: fromPeer, dropAuthor: true });
                sukses++;
            } catch (e) {
                gagal++;
                const targetName = d.name || d.title || d.id.toString();
                failedNames.push(targetName);
                console.log(`[•] ${actionVerb} ${targetName} Error: ${e}`);
                if (e.seconds) await sleep(e.seconds * 1000);
            }
            if (processed % 5 === 0 || processed === total) await updateStatus();
            const delay = Math.floor(Math.random() * 500) + 500; // Delay acak
            await sleep(delay);
        }
        delete global.statusBc;
        delete global.bcType;

        let finalText = `✅ **${actionVerb} Selesai!**\n\n▫️ **Total Target:** ${total}\n✅ **Sukses:** ${sukses}\n❌ **Gagal:** ${gagal}`;
        return client.editMessage(statusMsg.chatId, { message: statusMsg.id, text: finalText, parseMode: "markdown" });
    }

    client.addEventHandler(async event => {
    const msg = event.message;
    const body = msg.message || "";
    const isCmd = body.startsWith(config.prefix);
    
    // DEBUG SEMENTARA
    console.log("[DEBUG] body:", body, "| isCmd:", isCmd, "| outgoing:", msg.out);
        const me = await client.getMe();
        const myId = me.id?.value?.toString() ?? me.id?.toString() ?? "";
        const fromId = msg?.senderId || msg?.fromId?.userId || "";
        const fromIdStr = fromId?.value?.toString() ?? fromId?.toString() ?? "";

        // Hanya proses pesan dari diri sendiri (outgoing biasa + saved messages)
        if (!msg.out && fromIdStr !== myId) return;

        const args = body.trim().split(/ +/).slice(1)
        const text = args.join(" ")
        const prefix = config.prefix;
        const command = isCmd ? body.slice(config.prefix.length).trim().split(" ").shift().toLowerCase() : ""
        const cmd = prefix + command;
        const chatId = msg.chatId;
        const isOwner = fromIdStr === config.ownerId?.toString() || fromIdStr === myId;
        const blacklist = readBlacklist();
        if ((msg.isGroup || (msg.isChannel && !msg.isGroup)) && !isOwner && blacklist.includes(chatId.toString())) return        
        
        // == CVPS Interactive Session Handler ==
        const cvpsSession = cvpsSessions.get(fromIdStr);
        if (cvpsSession && !isCmd && msg.isPrivate) {
            try {
                switch (cvpsSession.step) {
                    case 'hostname':
                        cvpsSession.hostname = body.trim();
                        if (!cvpsSession.hostname || !/^[a-zA-Z0-9.-]+$/.test(cvpsSession.hostname)) {
                            await msg.reply({ message: '❌ Hostname tidak valid. Hanya boleh berisi huruf, angka, titik, dan strip.' });
                            return;
                        }
                        cvpsSession.step = 'password';
                        await msg.reply({ message: '✅ Hostname diatur. Sekarang masukkan **password** untuk VPS:' });
                        break;

                    case 'password':
                        cvpsSession.password = body.trim();
                        if (!cvpsSession.password) {
                            await msg.reply({ message: '❌ Password tidak boleh kosong.' });
                            return;
                        }
                        cvpsSession.step = 'os';
                        const osData = await getDoData('images?type=distribution');
                        const osImages = osData.images.filter(img => img.status === 'available' && (img.slug.includes('ubuntu') || img.slug.includes('debian')));

                        const osButtons = osImages.map(os =>
                            [new Api.KeyboardButtonCallback(
                                `${os.distribution} ${os.name}`,
                                `cvps_os|${os.slug}`
                            )]
                        );

                        const osMsg = await msg.reply({
                            message: '✅ Password diatur. Sekarang pilih **Sistem Operasi**:',
                            buttons: client.buildReplyMarkup(osButtons)
                        });
                        cvpsSession.lastMsgId = osMsg.id;
                        break;
                }
                cvpsSessions.set(fromIdStr, cvpsSession);
            } catch (e) {
                cvpsSessions.delete(fromIdStr);
                await msg.reply({ message: `❌ Terjadi error pada sesi CVPS: ${e.message}` });
            }
            return; // Stop further processing for this message
        }

        // Inisialisasi DB jika belum ada
        if (!db.settings.notes) db.settings.notes = {};
        if (!db.settings.transactions) db.settings.transactions = [];

        // ============================== AFK HANDLER ==============================
        // Un-AFK jika owner mengirim pesan apapun (kecuali perintah afk itu sendiri)
        if (isOwner && db?.settings?.afk?.status && command !== 'afk') {
            let data = db.settings.afk;
            let dur = Date.now() - data.afkTime;
            let reason = data.reason;
            delete db.settings.afk;
            await msg.reply({ message: `<b>Owner Telah Kembali Dari Afk 🌟</b>\n\n<b>Waktu:</b> ${clockString(dur)}\n<b>Alasan:</b> ${reason}`, parseMode: "html" });
        }
        
        // Balas mention/DM jika sedang AFK
        if (!isOwner && db?.settings?.afk?.status) {
            let shouldReply = false;
            if (msg.isPrivate) {
                shouldReply = true;
            } else if (msg.mentioned) {
                shouldReply = true;
            } else if (msg.replyTo) {
                const replyMsg = await msg.getReplyMessage().catch(() => null);
                if (replyMsg && replyMsg.senderId && replyMsg.senderId.toString() === myId) {
                    shouldReply = true;
                }
            }

            if (shouldReply) {
                let data = db.settings.afk;
                let dur = Date.now() - data.afkTime;
                let reason = data.reason;
                await client.sendMessage(msg.chatId, { message: `<b>Owner Sedang AFK 💤</b>\n\n<b>Waktu:</b> ${clockString(dur)}\n<b>Alasan:</b> ${reason}`, parseMode: "html", replyTo: msg.id });
            }
        }

        // ============================== AUTO PROMOSI ==============================
        if (msg.isGroup && !isOwner && !isCmd && db?.settings?.autopromosi?.status) {
            let promo = db.settings.autopromosi;
            if (!promo?.msgId) return;
            await sleep(3000);
            await client.forwardMessages(
                msg.chatId,
                { messages: [promo.msgId], fromPeer: promo.chatId, dropAuthor: false }
            );
        }

        if (isCmd && global.selfMode && !isOwner) return;

        switch (command) {
            // ============================== MENU ==============================
            case "menu": case "help": case "p": case "start": {
                const cacheId = setTempData({}, 'menu');
                return sendInline(client, chatId, `${prefix}menu ${cacheId}`);
            }

            // ============================== AFK ==============================
            case "afk": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} alasan`, parseMode: "html" });
                db.settings.afk = {
                    status: true,
                    reason: text,
                    afkTime: Date.now()
                };
                return msg.reply({ message: `<b>AFK Berhasil ✅</b>\n<b>Alasan:</b> ${text}`, parseMode: "html" });
            }

            case "unafk": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (db?.settings?.afk?.status) {
                    delete db.settings.afk;
                    return msg.reply({ message: `<b>✅ Owner tidak lagi AFK.</b>`, parseMode: "html" });
                } else {
                    return msg.reply({ message: `<b>⚠️ Owner tidak sedang AFK.</b>`, parseMode: "html" });
                }
            }


            // ============================== SELF/PUBLIC MODE ==============================
            case "self": case "public": {
                if (!isOwner) return msg.reply({ message: "❌ Owner Only Bro!" });
                const status = command == "self";
                global.selfMode = status;
                return msg.reply({ message: `<b>✅ Berhasil Beralih Ke Mode ${status ? "Self" : "Public"}</b>`, parseMode: "html" });
            }

            // ============================== CEK CHANNEL ==============================
            case "idch": case "cekch": case "cekchannel": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} https://whatsapp.com/channel/xxx`, parseMode: "html" });
                const prosesCache = setTempData({ text }, 'cekch');
                return sendInline(client, chatId, `${prefix}cekch ${prosesCache}`);
            }

            // ============================== PROSES ==============================
            case "proses": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!text) return client.sendMessage(chatId, { message: `<b>Ex:</b> ${cmd} jasa install panel`, replyTo: msg.id, parseMode: "html" });
                const prosesCache = setTempData({ text }, 'proses');
                return sendInline(client, chatId, `${prefix}proses ${prosesCache}`);
            }

            // ============================== PAYMENT ==============================
            case "payment": case "pay": {
                const paymentCache = setTempData({}, 'payment');
                return sendInline(client, chatId, `${prefix}payment ${paymentCache}`);
            }

            // ============================== DELETE PANEL ==============================
            case "delpanel": case "delp": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const delpanelCache = setTempData({}, 'delpanel');
                return sendInline(client, chatId, `${prefix}delpanel ${delpanelCache}`);
            }

            // ============================== DELETE ADMIN ==============================
            case "deladmin": case "dela": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const deladminCache = setTempData({}, 'deladmin');
                return sendInline(client, chatId, `${prefix}deladmin ${deladminCache}`);
            }

            // ============================== NSFW ==============================
            case "nsfw": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                let imagesUrl = [];
                const waitMsg = await msg.reply({ message: "👀 Mencari gambar..." });
                try {
                    for (let i = 0; i < 5; i++) imagesUrl.push("https://api.skyzopedia.web.id/random/nsfw?apikey=skyy");
                    await waitMsg.delete();
                    await sendAlbum(client, msg, chatId, imagesUrl, "Random NSFW 💦");
                } catch (err) {
                    console.error(err);
                    return msg.reply({ message: "❌ Gagal mengambil NSFW" });
                }
                break;
            }

            // ============================== WAIFU ==============================
            case "waifu": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                let imagesUrl = [];
                const waitMsg = await msg.reply({ message: "👀 Mencari gambar..." });
                try {
                    for (let i = 0; i < 5; i++) imagesUrl.push("https://api.skyzopedia.web.id/random/waifu?apikey=skyy");
                    await waitMsg.delete();
                    await sendAlbum(client, msg, chatId, imagesUrl, "Random Waifu 💦");
                } catch (err) {
                    console.error(err);
                    return msg.reply({ message: "❌ Gagal mengambil Waifu" });
                }
                break;
            }
            
            // ============================== AUTO PROMOSI SETTING ==============================
            case "autopromosi": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!text) return msg.reply({ message: `<b>Ex:</b>\n${cmd} on\n${cmd} off`, parseMode: "html" });
                if (text === "on") {
                    db.settings.autopromosi = {
                        status: true,
                        text: db.settings.autopromosi?.text || "",
                        lastSend: 0
                    };
                    return msg.reply({ message: "✅ AutoPromosi berhasil diaktifkan!", parseMode: "html" });
                }
                if (text === "off") {
                    db.settings.autopromosi.status = false;
                    return msg.reply({ message: "❌ AutoPromosi dimatikan!", parseMode: "html" });
                }
            }

            // ============================== SET PROMOSI ==============================
            case "setpromosi": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const msgg = await msg.getReplyMessage();
                if (!msgg || !msgg.id) return msg.reply({ message: `❌ Reply pesan promosi lalu ketik ${cmd}` });
                db.settings.autopromosi = {
                    status: db.settings.autopromosi?.status || false,
                    chatId: msg.chatId,
                    msgId: msgg.id,
                    lastSend: 0
                };
                return msg.reply({ message: "✅ Pesan promosi berhasil disimpan (forward mode)!" });
            }

            // ============================== LIST PANEL ==============================
            case "listpanel": case "listserver": {
                if (!isOwner) return msg.reply({ message: "❌ Owner Only Brok!" });
                try {
                    const res = await fetch(`${config.domain}/api/application/servers`, {
                        method: "GET",
                        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${config.apikey}` }
                    });
                    const data = await res.json();
                    const servers = data.data || [];
                    if (!servers.length) return msg.reply({ message: "⚠️ Tidak ada server panel!" });
                    let teks = `<b>📊 Total Server Panel:</b> ${servers.length}\n`;
                    for (const sObj of servers) {
                        const s = sObj.attributes;
                        const ram = s.limits.memory === 0 ? "Unlimited" : (s.limits.memory >= 1024 ? `${Math.floor(s.limits.memory / 1024)} GB` : `${s.limits.memory} MB`);
                        const disk = s.limits.disk === 0 ? "Unlimited" : (s.limits.disk >= 1024 ? `${Math.floor(s.limits.disk / 1024)} GB` : `${s.limits.disk} MB`);
                        const cpu = s.limits.cpu === 0 ? "Unlimited" : `${s.limits.cpu}%`;
                        teks += `\n<b>▢ Server ID:</b> ${s.id}\n<b>▢ Nama:</b> ${escapehtml(s.name)}\n<b>▢ RAM:</b> ${ram}\n<b>▢ Disk:</b> ${disk}\n<b>▢ CPU:</b> ${cpu}\n<b>▢ Dibuat:</b> ${s.created_at?.split("T")[0] || "-"}\n`;
                    }
                    const listpanelCache = setTempData({ teks }, 'listpanel');
                    return sendInline(client, chatId, `${prefix}listpanel ${listpanelCache}`);
                } catch (err) {
                    console.error("Error listpanel:", err);
                    msg.reply({ message: "Error! terjadi kesalahan saat mengambil data server panel!" });
                }
                break;
            }

            // ============================== LIST ADMIN ==============================
            case "listadmin": {
                if (!isOwner) return msg.reply({ message: "❌ Owner Only Bro!" });
                try {
                    const res = await fetch(`${config.domain}/api/application/users`, {
                        method: "GET",
                        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${config.apikey}` }
                    });
                    const data = await res.json();
                    const users = data.data || [];
                    const admins = users.filter(u => u.attributes.root_admin);
                    if (!admins.length) return msg.reply({ message: "⚠️ Tidak ada admin panel!" });
                    let teks = `<b>📊 Total Admin Panel:</b> ${admins.length}\n`;
                    for (const a of admins) {
                        const u = a.attributes;
                        teks += `\n<b>▢ User ID:</b> ${u.id}\n<b>▢ Username:</b> ${escapehtml(u.username)}\n<b>▢ Dibuat:</b> ${u.created_at?.split("T")[0] || "-"}\n`;
                    }
                    const listadminCache = setTempData({ teks }, 'listadmin');
                    return sendInline(client, chatId, `${prefix}listadmin ${listadminCache}`);
                } catch (err) {
                    console.error("Error listadmin:", err);
                    await msg.reply({ message: "Error! terjadi kesalahan saat mengambil data server panel!" });
                }
                break;
            }

            // ============================== TIKTOK DOWNLOAD ==============================
            case "tiktokmp3": case "ttmp3": case "tiktokdl": case "tt": case "tiktok": case "ttdl": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} https://vt.tiktok.com/xxxxxx`, parseMode: "html" });
                try {
                    const waitMsg = await msg.reply({ message: "📥 Mengambil data TikTok..." });
                    const apiUrl = `https://api.skyzopedia.web.id/download/tiktok?apikey=skyy&url=${encodeURIComponent(text)}`;
                    const { data: res } = await axios.get(apiUrl);
                    if (!res?.status || !res?.result) return waitMsg.edit({ text: "❌ Gagal mengambil data TikTok" });
                    await waitMsg.delete();
                    const d = res.result;
                    const caption = d.caption || "";
                    if (d.type === "photo" && Array.isArray(d.slide)) {
                        await sendAlbum(client, msg, chatId, d.slide, caption);
                        if (d.audio) {
                            const audioCacheId = setTempData({ type: "audio", audioUrl: d.audio, cover: d.slide[0], title: caption || "TikTok Audio", caption: caption }, "tiktok-audio");
                            setTimeout(async () => {
                                await sendInline(client, chatId, `${prefix}tiktok-audio ${audioCacheId}`);
                            }, 300);
                        }
                        return;
                    }
                    const videoCacheId = setTempData({ type: "video", videoUrl: d.video, watermarkUrl: d.watermark || null, cover: d.cover || d.video, title: caption || "TikTok Video", caption: caption }, "tiktok-video");
                    await sendInline(client, chatId, `${prefix}tiktok-video ${videoCacheId}`);
                    if (d.audio) {
                        const audioCacheId = setTempData({ type: "audio", audioUrl: d.audio, cover: d.cover || d.video, title: caption || "TikTok Audio", caption: caption }, "tiktok-audio");
                        setTimeout(async () => {
                            await sendInline(client, chatId, `${prefix}tiktok-audio ${audioCacheId}`);
                        }, 500);
                    }
                } catch (e) {
                    console.error("TikTok DL Error:", e);
                    msg.reply({ message: "❌ Terjadi kesalahan saat memproses TikTok" });
                }
                break;
            }

            // ============================== PINTEREST ==============================
            case "pinterest": case "pin": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} Boruto`, parseMode: "html" });
                try {
                    const waitMsg = await msg.reply({ message: "🔎 Mencari gambar Pinterest..." });
                    const apiUrl = `https://api.skyzopedia.web.id/search/pinterest?apikey=skyy&q=${encodeURIComponent(text)}`;
                    const { data: res } = await axios.get(apiUrl);
                    if (!res?.status || !Array.isArray(res.result) || res.result.length === 0) return waitMsg.edit({ text: "❌ Tidak ditemukan hasil Pinterest" });
                    await waitMsg.delete();
                    const images = res.result.slice(0, 5);
                    const caption = `<b>🔍 Pinterest Search Query:</b> ${escapehtml(text)}\n<b>🖼️ Result:</b> ${images.length}`;
                    await sendAlbum(client, msg, chatId, images, caption);
                } catch (e) {
                    console.error("Pinterest Error:", e);
                    msg.reply({ message: "❌ Terjadi kesalahan saat mengambil Pinterest" });
                }
                break;
            }

            // ============================== CLEAR DNS ==============================
            case "cleardns": {
                if (!text || !text.includes("|")) return msg.reply({ message: `<b>Ex:</b> ${cmd} apitoken|zoneid`, parseMode: "html" });
                const [apiToken, zoneId] = text.split("|").map(v => v.trim());
                if (!apiToken || !zoneId) return msg.reply({ message: "❌ API Token atau Zone ID tidak valid!" });
                try {
                    const waitMsg = await msg.reply({ message: "📄 Mengambil DNS record..." });
                    const { data } = await axios.get(`https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`, {
                        headers: { Authorization: `Bearer ${apiToken}`, "Content-Type": "application/json" }
                    });
                    const records = data?.result;
                    if (!records || records.length === 0) return waitMsg.edit({ text: "✅ Tidak ada DNS record untuk dihapus." });
                    await waitMsg.edit({ text: `🗑️ Menghapus ${records.length} DNS record...` });
                    const deletePromises = records.map(r => axios.delete(`https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records/${r.id}`, {
                        headers: { Authorization: `Bearer ${apiToken}`, "Content-Type": "application/json" }
                    }));
                    await Promise.all(deletePromises);
                    await waitMsg.edit({ text: `<b>✅ Berhasil menghapus ${records.length} DNS record.</b>`, parseMode: "html" });
                } catch (err) {
                    console.error("ClearDNS error:", err.response?.data || err.message);
                    await msg.reply({ text: `<b>❌ Gagal menghapus DNS.</b>\n\n${err.response?.data?.errors?.[0]?.message || err.message}`, parseMode: "html" });
                }
                break;
            }

            // ============================== AI/GPT ==============================
            case "ai": case "gpt": case "ask": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} Halo siapa kamu?`, parseMode: "html" });
                try {
                    const apiUrl = `https://api.skyzopedia.web.id/ai/gpt?apikey=skyy&question=${encodeURIComponent(text)}`;
                    const { data: res } = await axios.get(apiUrl);
                    if (!res?.status || !res?.result) return waitMsg.edit({ text: "❌ Gagal mendapatkan jawaban AI" });
                    const aiText = res.result;
                    const aiCacheId = setTempData({ type: "text", title: "AI Response", question: text, answer: aiText, caption: aiText }, "ai-response");
                    await sendInline(client, chatId, `${prefix}ai-response ${aiCacheId}`);
                } catch (e) {
                    console.error("AI Error:", e);
                    msg.reply({ message: "❌ Terjadi kesalahan saat memproses AI" });
                }
                break;
            }
            
            // ============================== NPM SEARCH ==============================
            case "npm": case "npmsearch": case "searchnpm": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} axios`, parseMode: "html" });
                try {
                    const apiUrl = `https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(text)}&size=10`;
                    const { data: res } = await axios.get(apiUrl);
                    if (!res?.objects || res.objects.length === 0) return msg.reply({ message: "❌ Package tidak ditemukan!" });
                    const npmCacheId = setTempData({ type: "text", title: "NPM Search Result", query: text, caption: res }, "npm-search");
                    await sendInline(client, chatId, `${prefix}npm-search ${npmCacheId}`);
                } catch (e) {
                    console.error("NPM Search Error:", e);
                    msg.reply({ message: "❌ Terjadi kesalahan saat search npm" });
                }
                break;
            }

            // ============================== SPOTIFY DOWNLOAD ==============================
            case "spotify": case "spdl": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} https://open.spotify.com/track/xxxx`, parseMode: "html" });
                let audioUrl;
                try {
                    const waitMsg = await msg.reply({ message: "🎧 Mengambil data Spotify..." });
                    const apiUrl = `https://api.skyzopedia.web.id/download/spotify2?apikey=skyy&url=${encodeURIComponent(text)}`;
                    const { data: res } = await axios.get(apiUrl);
                    if (!res?.status || !res?.result?.url) return waitMsg.edit({ text: "❌ Gagal mengambil data Spotify" });
                    await waitMsg.delete();
                    audioUrl = res.result.url;
                    const trackTitle = res.result.title || "Spotify Track";
                    await client.sendFile(chatId, { file: audioUrl, caption: `<b>🎵 ${escapehtml(trackTitle)}</b>`, replyTo: msg.id, parseMode: "html" });
                } catch (err) {
                    console.error("Spotify error:", err);
                    await msg.reply({ message: `<b>❌ Error:</b> ${escapehtml(err.message || "Gagal memproses Spotify")}\n\n${audioUrl ? `Coba download manual:\n${audioUrl}` : `URL audio tidak tersedia`}`, parseMode: "html" });
                }
                break;
            }

            // ============================== YOUTUBE MP3 ==============================
            case "ytmp3": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} https://youtu.be/xxxx`, parseMode: "html" });
                let audioUrl;
                try {
                    const waitMsg = await msg.reply({ message: "📥 Mendownload audio..." });
                    const apiUrl = `https://api.skyzopedia.web.id/download/ytdl-mp3?apikey=skyy&url=${encodeURIComponent(text)}`;
                    const { data: res } = await axios.get(apiUrl);
                    if (!res?.status || !res?.result?.download) return waitMsg.edit({ text: "❌ Gagal mendapatkan audio!" });
                    await waitMsg.delete();
                    audioUrl = res.result.download;
                    const title = res.result.title || "YouTube Audio";
                    await client.sendFile(chatId, { file: audioUrl, caption: `<b>🎵 ${escapehtml(title)}</b>`, replyTo: msg.id, parseMode: "html" });
                } catch (err) {
                    console.error("YTMP3 URL error:", err);
                    await msg.reply({ message: `<b>❌ Error:</b> ${escapehtml(err.message || "Gagal memproses audio")}\n\n${audioUrl ? `Download manual:\n${audioUrl}` : `URL audio tidak tersedia`}`, parseMode: "html" });
                }
                break;
            }

            // ============================== YOUTUBE MP4 ==============================
            case "ytmp4": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} https://youtu.be/xxxx`, parseMode: "html" });
                const processingMsg = await msg.reply({ message: "⏳ Mengunduh video YouTube..." });
                try {
                    const apiUrl = `https://co.wuk.sh/api/json`;
                    const response = await axios.post(apiUrl, {
                        url: text,
                        vQuality: '720',
                        isNoTTWatermark: true
                    }, {
                        headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' }
                    });
                    const data = response.data;

                    if (data && data.status === 'stream' && data.url) {
                        const videoUrl = data.url;
                        const caption = data.title || "Video YouTube";
                        await processingMsg.delete();
                        await client.sendFile(chatId, { file: videoUrl, caption: `<b>▶️ ${escapehtml(caption)}</b>`, replyTo: msg.id, parseMode: "html" });
                    } else {
                         const errorDetail = data ? (data.text || JSON.stringify(data)) : 'Respon API tidak valid.';
                         await processingMsg.edit({ text: `❌ Gagal: ${errorDetail}` });
                    }
                } catch (err) {
                    const errorText = err.response ? (err.response.data.text || JSON.stringify(err.response.data)) : err.message;
                    await processingMsg.edit({ text: `❌ Error API: ${errorText}` });
                }
                break;
            }

            // ============================== PLAY MUSIC ==============================
            case "play": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} nama lagu`, parseMode: "html" });
                try {
                    const processingMsg = await msg.reply({ message: "🔍 Mencari lagu..." });
                    const yts = require("yt-search");
                    const searchResults = await yts(text);
                    if (!searchResults.videos || searchResults.videos.length === 0) {
                        await processingMsg.edit({ text: "❌ Lagu tidak ditemukan!" });
                        return;
                    }
                    const video = searchResults.videos[0];
                    const videoId = video.videoId;
                    const youtubeUrl = `https://youtu.be/${videoId}`;
                    await processingMsg.edit({ text: "📥 Mendownload audio..." });
                    const apiUrl = `https://api.skyzopedia.web.id/download/ytdl-mp3?apikey=skyy&url=${encodeURIComponent(youtubeUrl)}`;
                    const response = await axios.get(apiUrl);
                    if (!response.data.status || !response.data.result) {
                        await processingMsg.edit({ text: "❌ Gagal mendapatkan link download!" });
                        return;
                    }
                    const { title, download: audioUrl } = response.data.result;
                    await processingMsg.delete();
                    const playCache = setTempData({ youtubeUrl, audioUrl, title }, 'play-result');
                    return sendInline(client, chatId, `${prefix}play-result ${playCache}`);
                } catch (error) {
                    console.error("Play error:", error);
                    await msg.reply({ message: `<b>❌ Error:</b> ${escapehtml(error.message || "Gagal memproses lagu")}`, parseMode: "html" });
                }
                break;
            }

            // ============================== PING ==============================
            case "ping": {
                const os = require("os");
                const nou = require("node-os-utils");
                const speed = require("performance-now");
                const start = speed();
                const cpu = nou.cpu;
                const drive = nou.drive;
                const mem = nou.mem;
                const netstat = nou.netstat;
                const [osName, driveInfo, memInfo, cpuUsage, netStats] = await Promise.all([
                    nou.os.oos().catch(() => "Unknown"),
                    drive.info().catch(() => ({ usedGb: "N/A", totalGb: "N/A" })),
                    mem.info().catch(() => ({ totalMemMb: 0, usedMemMb: 0, freeMemMb: 0 })),
                    cpu.usage().catch(() => 0),
                    netstat.inOut().catch(() => ({ total: null }))
                ]);
                const totalGB = (memInfo.totalMemMb / 1024 || 0).toFixed(2);
                const usedGB = (memInfo.usedMemMb / 1024 || 0).toFixed(2);
                const freeGB = (memInfo.freeMemMb / 1024 || 0).toFixed(2);
                const cpuList = os.cpus() || [];
                const cpuModel = cpuList[0]?.model || "Unknown CPU";
                const cpuSpeed = cpuList[0]?.speed || "N/A";
                const cpuCores = cpuList.length || 0;
                const vpsUptime = runtime(os.uptime());
                const botUptime = runtime(process.uptime());
                const latency = (speed() - start).toFixed(2);
                const loadAvg = os.loadavg().map(n => n.toFixed(2)).join(" | ");
                const nodeVersion = process.version;
                const platform = os.platform();
                const hostname = os.hostname();
                const arch = os.arch();
                const network = netStats.total ? `${netStats.total.inputMb.toFixed(2)} MB ↓ / ${netStats.total.outputMb.toFixed(2)} MB ↑` : "N/A";
                const tt = `<b>⚙️ SYSTEM STATUS</b>\n<b>▢ OS :</b> ${nou.os.type()} (${osName})\n<b>▢ Platform :</b> ${platform.toUpperCase()}\n<b>▢ Arch :</b> ${arch}\n<b>▢ Hostname :</b> ${hostname}\n\n<b>💾 STORAGE</b>\n<b>▢ Disk :</b> ${driveInfo.usedGb}/${driveInfo.totalGb} GB\n<b>▢ RAM :</b> ${usedGB}/${totalGB} GB (Free: ${freeGB} GB)\n\n<b>🧠 CPU INFO</b>\n<b>▢ Model :</b> ${cpuModel}\n<b>▢ Core(s) :</b> ${cpuCores}\n<b>▢ Speed :</b> ${cpuSpeed} MHz\n<b>▢ Usage :</b> ${cpuUsage.toFixed(2)}%\n<b>▢ Load Avg :</b> ${loadAvg}\n\n<b>🤖 BOT STATUS</b>\n<b>▢ Response Time :</b> ${latency} sec\n<b>▢ Bot Uptime :</b> ${botUptime}\n<b>▢ VPS Uptime :</b> ${vpsUptime}\n<b>▢ Node.js :</b> ${nodeVersion}`;
                const pingCache = setTempData({ tt }, 'ping');
                return sendInline(client, chatId, `${prefix}ping ${pingCache}`);
            }

            // ============================== MY ID ==============================
            case "me": case "my": case "myid": case "cekid": {
                const sender = await client.getEntity(msg.senderId);
                const info = `<b>▢ ID:</b> <code>${sender.id}</code> (${msg.senderId.toString().length})\n<b>▢ Nama:</b> <b>${escapehtml(sender.firstName || "")} ${escapehtml(sender.lastName || "")}</b>\n<b>▢ Username:</b> @${sender.username || "-"}\n<b>▢ Bot:</b> ${sender.bot ? "Ya" : "Tidak"}\n<b>▢ Premium:</b> ${sender.premium ? "Ya" : "Tidak"}`;
                const meCache = setTempData({ teks: info, username: sender.username || "" }, 'me');
                return sendInline(client, chatId, `${prefix}me ${meCache}`);
            }

            // ============================== ID COMMAND ==============================
            case "id": {
                let targetUser;
                let title = "ID Anda";

                if (msg.replyTo) {
                    const replyMsg = await msg.getReplyMessage();
                    if (replyMsg && replyMsg.sender) {
                        targetUser = await client.getEntity(replyMsg.sender);
                        title = "ID Pengguna";
                    }
                } else if (text) {
                    try {
                        targetUser = await client.getEntity(text);
                        title = "ID Pengguna/Grup/Channel";
                    } catch (e) {
                        return msg.reply({ message: "⚠️ Entitas tidak ditemukan." });
                    }
                }
                const entity = targetUser || await msg.getChat();
                const name = entity.title || `${entity.firstName || ""} ${entity.lastName || ""}`.trim();
                return msg.reply({ message: `<b>${title}</b>\n\n👤 Nama: ${escapehtml(name)}\n🆔 ID: <code>${entity.id}</code>`, parseMode: "html" });
            }
            // ============================== BROADCAST GROUP ==============================
            case "bcgc":
                return handleBroadcast(msg, { targetType: 'group', actionType: 'broadcast' });

            // ============================== FORWARD GROUP ==============================
            case "cfd":
                {
                    const target = args[0]?.toLowerCase();
                    const validTargets = {
                        'group': 'group',
                        'user': 'user',
                        'channel': 'channel',
                        'ch': 'channel',
                        'all': 'all_gc',
                        'semua': 'semua'
                    };
    
                    if (validTargets[target]) {
                        return handleBroadcast(msg, { targetType: validTargets[target], actionType: 'forward' });
                    } else if (!target) {
                        return handleBroadcast(msg, { targetType: 'group', actionType: 'forward' });
                    } else {
                        return msg.reply({ message: `<b>Target "${escapehtml(target)}" tidak valid.</b>\n\n<b>Penggunaan:</b> ${prefix}cfd [group|user|channel|all|semua]\n\nContoh: <code>${prefix}cfd group</code>`, parseMode: "html" });
                    }
                }
                
            // ============================== BROADCAST USER ==============================
            case "bcuser":
                return handleBroadcast(msg, { targetType: 'user', actionType: 'broadcast' });

            // ============================== STOP BROADCAST ==============================
            case "stopbc": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!global.statusBc) return msg.reply({ message: "⚠️ Tidak ada broadcast yang sedang berjalan." });
                global.statusBc = false;
                return msg.reply({ message: `<b>✅ ${global.bcType} dihentikan!</b>`, parseMode: "html" });
            }

            // ============================== BLACKLIST GROUP ==============================
            case "addbl": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!(msg.isGroup || (msg.isChannel && !msg.isGroup))) return msg.reply({ message: "❌ Harus di dalam grup/channel!" });
                const id = chatId.toString();
                if (blacklist.includes(id)) return msg.reply({ message: "⚠️ Grup sudah ada di blacklist." });
                blacklist.push(id);
                writeBlacklist(blacklist);
                const blCache = setTempData({ id }, 'bl');
                return sendInline(client, chatId, `${prefix}bl ${blCache}`);
            }

            // ============================== DELETE BLACKLIST ==============================
            case "delbl": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!(msg.isGroup || (msg.isChannel && !msg.isGroup))) return msg.reply({ message: "❌ Harus di dalam grup/channel!" });
                const id = chatId.toString();
                if (!blacklist.includes(id)) return msg.reply({ message: "⚠️ Grup tidak ada di blacklist." });
                const newBlacklist = blacklist.filter(i => i !== id);
                writeBlacklist(newBlacklist);
                const delblCache = setTempData({ id }, 'delbl');
                return sendInline(client, chatId, `${prefix}delbl ${delblCache}`);
            }

            case "storych": case "storychannel": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!(msg.isChannel && !msg.isGroup)) return msg.reply({ message: "❌ Harus di dalam channel!" });
                if (!msg.replyTo) return msg.reply({ message: "❌ Reply foto/video untuk story." });
                const replied = await msg.getReplyMessage().catch(() => null);
                if (!replied) return msg.reply({ message: "⚠️ Tidak dapat menemukan pesan yang dibalas." });
                const caption = text || "";
                let mediaType = null;
                if (replied.photo) mediaType = "photo";
                else if (replied.document && (replied.document.mimeType || "").startsWith("video/")) mediaType = "video";
                if (!mediaType) return msg.reply({ message: "❌ Reply foto/video untuk story." });
                const peer = await client.getInputEntity(chatId);
                try {
                    const can = await client.invoke(new Api.stories.CanSendStory({ peer }));
                    if (can === false) return msg.reply({ message: "❌ Tidak bisa kirim story dari channel ini." });
                } catch {}
                let tmpPath = null;
                try {
                    if (!fs.existsSync("./tmp")) fs.mkdirSync("./tmp", { recursive: true });
                    const ext = mediaType === "photo" ? ".jpg" : ".mp4";
                    tmpPath = `./tmp/story_${Date.now()}${ext}`;
                    const dl = await client.downloadMedia(replied, { outputFile: tmpPath });
                    if (Buffer.isBuffer(dl)) fs.writeFileSync(tmpPath, dl);
                    const uploaded = await client.uploadFile({
                        file: new CustomFile(path.basename(tmpPath), fs.statSync(tmpPath).size, tmpPath),
                        workers: 1
                    });
                    const media = mediaType === "photo"
                        ? new Api.InputMediaUploadedPhoto({ file: uploaded })
                        : new Api.InputMediaUploadedDocument({
                            file: uploaded,
                            mimeType: replied.document?.mimeType || "video/mp4",
                            attributes: replied.document?.attributes || []
                        });
                    const args = {
                        peer,
                        media,
                        privacyRules: [new Api.InputPrivacyValueAllowAll()]
                    };
                    if (caption) args.caption = caption;
                    await client.invoke(new Api.stories.SendStory(args));
                    return msg.reply({ message: "✅ Story terkirim.", parseMode: "html" });
                } catch (e) {
                    console.error("Story error:", e);
                    return msg.reply({ message: "❌ Story channel tidak support / gagal dikirim." });
                } finally {
                    if (tmpPath && fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
                }
            }

            // ============================== SUBDOMAIN ==============================
            case "subdo": case "sub": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!text.includes("|")) return client.sendMessage(chatId, { message: `<b>Ex:</b> ${cmd} hostname|ip`, replyTo: msg.id, parseMode: "html" });
                
                const [hostname, ip] = text.split("|").map(s => s.trim());
                if (!hostname || !ip) return msg.reply({ message: `<b>Ex:</b> ${cmd} hostname|ip`, parseMode: "html" });

                const availableDomains = Object.keys(config.subdomain || {});
                if (availableDomains.length < 1) return msg.reply({ message: "❌ Tidak ada domain tersedia di konfigurasi." });

                const buttons = availableDomains.map(domain => {
                    const callbackData = `createsubdo|${hostname}|${ip}|${domain}`;
                    return [new Api.KeyboardButtonCallback(domain, callbackData)];
                });

                await msg.reply({
                    message: "Silakan pilih domain untuk subdomain Anda:",
                    buttons: client.buildReplyMarkup(buttons)
                });
                break;
            }

            // ============================== CREATE PANEL ==============================
            case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} username`, parseMode: "html" });
                const username = text.toLowerCase();
                const email = `${username}@gmail.com`;
                const name = `${global.capital ? global.capital(username) : username} Server`;
                const password = `${username}001`;
                const resourceMap = {
                    "1gb": { ram: "1000", disk: "1000", cpu: "40" },
                    "2gb": { ram: "2000", disk: "1000", cpu: "60" },
                    "3gb": { ram: "3000", disk: "2000", cpu: "80" },
                    "4gb": { ram: "4000", disk: "2000", cpu: "100" },
                    "5gb": { ram: "5000", disk: "3000", cpu: "120" },
                    "6gb": { ram: "6000", disk: "3000", cpu: "140" },
                    "7gb": { ram: "7000", disk: "4000", cpu: "160" },
                    "8gb": { ram: "8000", disk: "4000", cpu: "180" },
                    "9gb": { ram: "9000", disk: "5000", cpu: "200" },
                    "10gb": { ram: "10000", disk: "5000", cpu: "220" },
                    "unlimited": { ram: "0", disk: "0", cpu: "0" },
                    "unli": { ram: "0", disk: "0", cpu: "0" }
                };
                const { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" };
                try {
                    const f = await fetch(`${config.domain}/api/application/users`, {
                        method: "POST",
                        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${config.apikey}` },
                        body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
                    });
                    const data = await f.json();
                    if (data.errors) return msg.reply({ message: `<b>❌ Error create user:</b>\n${JSON.stringify(data.errors[0], null, 2)}`, parseMode: "html" });
                    const user = data.attributes;
                    const f1 = await fetch(`${config.domain}/api/application/nests/${config.nestid}/eggs/${config.egg}`, {
                        method: "GET",
                        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${config.apikey}` }
                    });
                    const data2 = await f1.json();
                    const startup_cmd = data2.attributes?.startup || "npm start";
                    const f2 = await fetch(`${config.domain}/api/application/servers`, {
                        method: "POST",
                        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${config.apikey}` },
                        body: JSON.stringify({
                            name,
                            description: global.tanggal ? global.tanggal(Date.now()) : new Date().toLocaleString(),
                            user: user.id,
                            egg: parseInt(config.egg),
                            docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                            startup: startup_cmd,
                            environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                            limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                            feature_limits: { databases: 5, backups: 5, allocations: 5 },
                            deploy: { locations: [parseInt(config.loc)], dedicated_ip: false, port_range: [] }
                        })
                    });
                    const result = await f2.json();
                    if (result.errors) return msg.reply({ message: `<b>❌ Error create server:</b>\n${JSON.stringify(result.errors[0], null, 2)}`, parseMode: "html" });
                    const server = result.attributes;
                    const domainClean = (config.domain || "").replace(/https?:\/\//g, "");
                    const panelData = { username: user.username, password, serverId: server.id, ram, disk, cpu, domainClean };
                    const panelCache = setTempData(panelData, 'cpanel-result');
                    return sendInline(client, chatId, `${prefix}cpanel-result ${panelCache}`);
                } catch (err) {
                    console.error(err);
                    await msg.reply({ message: `<b>❌ Gagal membuat panel:</b>\n${err.message || err}`, parseMode: "html" });
                }
                break;
            }

            case "totalserver": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const statusMsg = await msg.reply({ message: `📊 Menghitung status server...` });
                try {
                    const serversRes = await axios.get(`${config.domain}/api/application/servers?per_page=10000`, {
                        headers: { Authorization: `Bearer ${config.apikey}` }
                    });
                    const serversData = serversRes.data;
                    if (serversData.errors) throw new Error('Gagal mengambil data server dari panel.');
                    
                    const servers = serversData.data;
                    let active = 0, offline = 0, unknown = 0;

                    await client.editMessage(chatId, { message: statusMsg.id, text: `📊 Menghitung status ${servers.length} server...` });

                    for (const server of servers) {
                        try {
                            const resRes = await axios.get(`${config.domain}/api/client/servers/${server.attributes.uuid}/resources`, {
                                headers: { Authorization: `Bearer ${config.capikey}` },
                                timeout: 5000
                            });
                            if (resRes.status === 200) {
                                const state = resRes.data.attributes.current_state;
                                if (state === 'running' || state === 'starting') {
                                    active++;
                                } else {
                                    offline++;
                                }
                            } else {
                                unknown++;
                            }
                        } catch (e) {
                            unknown++;
                        }
                        await sleep(50); // Mencegah rate limit API
                    }

                    const teks = `<b>📊 Statistik Server Panel</b>\n\n` +
                                 `🟢 Server Aktif: ${active}\n` +
                                 `🔴 Server Offline: ${offline}\n` +
                                 `⚪ Server Tidak Diketahui: ${unknown}\n\n` +
                                 `🖥️ Total Server: <b>${servers.length}</b>`;
                    await client.editMessage(chatId, { message: statusMsg.id, text: teks, parseMode: 'html' });

                } catch (err) {
                    await client.editMessage(chatId, { message: statusMsg.id, text: `❌ Error: ${err.message}` }).catch(()=>{});
                }
                break;
            }

            // ============================== CREATE ADMIN ==============================
            case "cadmin": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} username`, parseMode: "html" });
                const username = text.toLowerCase();
                const email = `${username}@gmail.com`;
                const name = global.capital ? global.capital(username) : username;
                const password = `${username}001`;
                try {
                    const res = await fetch(`${config.domain}/api/application/users`, {
                        method: "POST",
                        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${config.apikey}` },
                        body: JSON.stringify({ email, username, first_name: name, last_name: "Admin", root_admin: true, language: "en", password })
                    });
                    const data = await res.json();
                    if (data.errors) return msg.reply({ message: `<b>❌ Error create admin:</b>\n${JSON.stringify(data.errors[0], null, 2)}`, parseMode: "html" });
                    const user = data.attributes;
                    const domainClean = (config.domain || "").replace(/https?:\/\//g, "");
                    let id = user.id;
                    const adminData = { id, username: user.username, password, domainClean };
                    const adminCache = setTempData(adminData, 'cadmin-result');
                    return sendInline(client, chatId, `${prefix}cadmin-result ${adminCache}`);
                } catch (err) {
                    console.error(err);
                    await msg.reply({ message: `<b>❌ Gagal membuat admin:</b>\n${err.message || err}`, parseMode: "html" });
                }
                break;
            }

            // ============================== ENCRYPT JS ==============================
            case "encjs": case "enc": {
                const jsconfuser = require("js-confuser");
                const chatId = msg.chatId;
                if (!msg.replyTo) return client.sendMessage(chatId, { message: "Reply file `.js` untuk dienkripsi!", replyTo: msg.id });
                const repl = await msg.getReplyMessage();
                const file = repl.media;
                if (!file || !repl.media.document || !repl.media.document.attributes[0].fileName.endsWith(".js"))
                    return client.sendMessage(chatId, { message: "Hanya bisa untuk file `.js`", replyTo: msg.id });
                await client.sendMessage(chatId, { message: `<b>🔒 Sedang memproses encrypt ${repl.media.document.attributes[0].fileName}...</b>`, replyTo: msg.id, parseMode: "html" });
                try {
                    const buffer = await client.downloadMedia(repl.media);
                    if (!buffer) return client.sendMessage(chatId, { message: "Gagal download file!", replyTo: msg.id });
                    const inputCode = buffer.toString();
                    const encryptedCode = await jsconfuser.obfuscate(inputCode, {
                        target: "node",
                        preset: "high",
                        stringEncoding: true,
                        identifierGenerator: "zeroWidth",
                    });
                    const outPath = `./tmp/${repl.media.document.attributes[0].fileName}`;
                    await fs.writeFileSync(outPath, encryptedCode.code);
                    await client.sendFile(chatId, { file: outPath, caption: `<b>✅ Berhasil encrypt file ${repl.media.document.attributes[0].fileName}</b>`, replyTo: msg.id, parseMode: "html" });
                    fs.unlinkSync(outPath);
                } catch (err) {
                    console.error(err);
                    await client.sendMessage(chatId, { message: "❌ Gagal mengenkripsi file!", replyTo: msg.id });
                }
                break;
            }

            // ============================== CLEAR DATABASE ==============================
            case "cleardb": case "uninstallpanel": case "uninstalpanel": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                let t = text.split("|");
                if (t.length < 2) return msg.reply({ message: `<b>Ex:</b> ${cmd} ipvps|pwvps`, parseMode: "html" });
                const { Client: SSHClient } = require("ssh2");
                const net = require("net");
                let [ipvps, passwd] = t;
                const connSettings = { host: ipvps, port: 22, username: "root", password: passwd };
                async function waitForSSH(host, port = 22, timeout = 300) {
                    return new Promise((resolve, reject) => {
                        let elapsed = 0;
                        const interval = setInterval(() => {
                            const socket = new net.Socket();
                            socket.setTimeout(2000);
                            socket.on("connect", () => { clearInterval(interval); socket.destroy(); resolve(true); });
                            socket.on("error", () => socket.destroy());
                            socket.on("timeout", () => socket.destroy());
                            socket.connect(port, host);
                            elapsed += 2;
                            if (elapsed >= timeout) { clearInterval(interval); reject(new Error("VPS tidak merespon SSH setelah reboot")); }
                        }, 2000);
                    });
                }
                const ssh = new SSHClient();
                ssh.on("ready", async () => {
                    try {
                        await new Promise((res, rej) => {
                            ssh.exec("sudo reboot", (err, stream) => {
                                if (err) return rej(err);
                                stream.on("close", () => res()).on("data", () => {}).stderr.on("data", () => {});
                            });
                        });
                        ssh.end();
                        client.sendMessage(msg.chatId, { message: "♻️ VPS direstart, menunggu aktif kembali...", replyTo: msg.id });
                        await waitForSSH(ipvps);
                        client.sendMessage(msg.chatId, { message: "✅ VPS sudah aktif kembali, menjalankan uninstall panel + cleardb...", replyTo: msg.id });
                        const ssh2 = new SSHClient();
                        ssh2.on("ready", () => {
                            const uninstallCommand = `bash <(curl -s https://pterodactyl-installer.se)`;
                            const cleardbCommand = `sudo dpkg --configure -a
sudo DEBIAN_FRONTEND=noninteractive apt-get purge -y mariadb-server mariadb-client mariadb-common mysql-common mysql-server-core-* mysql-client-core-*
sudo apt-get autoremove -y
sudo rm -rf /var/lib/mysql /etc/mysql
echo "✅ Panel dan Database MySQL/MariaDB berhasil dibersihkan!"
sudo reboot`.trim();
                            ssh2.exec(uninstallCommand, { pty: true }, (err, stream) => {
                                if (err) return client.sendMessage(msg.chatId, { message: "❌ Gagal menjalankan uninstall panel", replyTo: msg.id });
                                stream.on('close', async () => {
                                    ssh2.exec(cleardbCommand, { pty: true }, (err, stream2) => {
                                        if (err) return client.sendMessage(msg.chatId, { message: "❌ Gagal menjalankan cleardb", replyTo: msg.id });
                                        stream2.on("close", async (code) => {
                                            await client.sendMessage(msg.chatId, { message: "✅ Uninstall Panel + Cleardb Selesai!", replyTo: msg.id });
                                            ssh2.end();
                                        }).on("data", data => console.log("OUTPUT:", data.toString()))
                                          .stderr.on("data", data => console.log("STDERR:", data.toString()));
                                    });
                                }).on("data", (data) => {
                                    console.log("OUTPUT uninstall:", data.toString());
                                    if (data.toString().includes('Input 0-6')) stream.write("6\n");
                                    if (data.toString().includes('(y/N)')) stream.write("y\n");
                                    if (data.toString().includes('Choose the panel user')) stream.write("\n");
                                    if (data.toString().includes('Choose the panel database')) stream.write("\n");
                                }).stderr.on('data', (data) => {
                                    console.log("STDERR uninstall:", data.toString());
                                });
                            });
                        }).on("error", err => {
                            client.sendMessage(msg.chatId, { message: `<b>❌ Gagal SSH setelah reboot:</b> ${err.message}`, replyTo: msg.id, parseMode: "html" });
                        }).connect(connSettings);
                    } catch (e) {
                        client.sendMessage(msg.chatId, { message: `<b>❌ Error:</b> ${e.message}`, replyTo: msg.id, parseMode: "html" });
                    }
                }).on("error", err => {
                    client.sendMessage(msg.chatId, { message: `<b>❌ Gagal terhubung ke VPS:</b> ${err.message}`, replyTo: msg.id, parseMode: "html" });
                }).connect(connSettings);
                break;
            }

            // ============================== START WINGS ==============================
            case "startwings": case "cwings": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                let t = text.split("|");
                if (t.length < 3) return msg.reply({ message: `<b>Ex:</b> ${cmd} ipvps|pwvps|token`, parseMode: "html" });
                const { Client: SSHClient } = require("ssh2");
                let [ipvps, passwd, token] = t;
                const connSettings = { host: ipvps, port: 22, username: "root", password: passwd };
                const ssh = new SSHClient();
                ssh.on("ready", () => {
                    ssh.exec(`${token} && systemctl start wings`, (err, stream) => {
                        if (err) return client.sendMessage(msg.chatId, { message: "Gagal menjalankan perintah di VPS", replyTo: msg.id });
                        stream.on("close", async () => {
                            await client.sendMessage(msg.chatId, { message: "✅ Wings node Pterodactyl berhasil dijalankan!", replyTo: msg.id });
                            ssh.end();
                        }).on("data", data => stream.write("y\n\n"))
                          .stderr.on("data", data => {
                            console.log("STDERR:", data.toString());
                            client.sendMessage(msg.chatId, { message: `<b>Terjadi error saat eksekusi:</b>\n${data.toString()}`, replyTo: msg.id, parseMode: "html" });
                        });
                    });
                }).on("error", err => {
                    console.log("Connection Error:", err.message);
                    client.sendMessage(msg.chatId, { message: "Gagal Terhubung ke VPS: IP atau password salah.", replyTo: msg.id });
                }).connect(connSettings);
                break;
            }

            // ============================== INSTALL PANEL ==============================
            case "installpanel": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!text) return client.sendMessage(msg.chatId, { message: `<b>Ex:</b> ${cmd} ipvps|pwvps|panel.com|node.com|ram`, parseMode: "html", replyTo: msg.id });
                const vii = text.split("|");
                if (vii.length < 5) return client.sendMessage(msg.chatId, { message: `<b>Ex:</b> ${cmd} ipvps|pwvps|panel.com|node.com|ram`, parseMode: "html", replyTo: msg.id });
                const { Client: SSHClient } = require("ssh2");
                const ssh = new SSHClient();
                const ipVps = vii[0];
                const pwVps = vii[1];
                const domainpanel = vii[2];
                const domainnode = vii[3];
                const ramserver = vii[4];
                const chatId = msg.chatId;
                const passwordPanel = "admin001";
                const installer = "bash <(curl -s https://pterodactyl-installer.se)";
                const connSettings = {
                    host: ipVps.includes("@") ? ipVps.split("@")[1] : ipVps,
                    username: ipVps.includes("@") ? ipVps.split("@")[0] : "root",
                    password: pwVps,
                    port: 22
                };
                function installPanel() {
                    ssh.exec(installer, (err, stream) => {
                        if (err) return;
                        stream.on("data", (data) => {
                            const str = data.toString();
                            console.log("PANEL:", str);
                            if (str.includes("Input 0-6")) stream.write("0\n");
                            if (str.includes("(y/N)")) stream.write("y\n");
                            if (str.includes("(Y)es/(N)o")) stream.write("y\n");
                            if (str.includes("Do you want to automatically configure HTTPS using Let's Encrypt? (y/N)")) stream.write("y\n");
                            if (str.includes("Database name")) stream.write("\n");
                            if (str.includes("Database username")) stream.write("admin\n");
                            if (str.includes("Password (press enter")) stream.write("admin\n");
                            if (str.includes("Select timezone")) stream.write("Asia/Jakarta\n");
                            if (str.includes("Provide the email")) stream.write("admin@gmail.com\n");
                            if (str.includes("Email address for the initial admin account")) stream.write("admin@gmail.com\n");
                            if (str.includes("Username for the initial admin")) stream.write("admin\n");
                            if (str.includes("First name")) stream.write("Admin\n");
                            if (str.includes("Last name")) stream.write("Panel\n");
                            if (str.includes("Password for the initial admin")) stream.write(`${passwordPanel}\n`);
                            if (str.includes("Set the FQDN of this panel")) stream.write(`${domainpanel}\n`);
                            if (str.includes("configure UFW")) stream.write("y\n");
                            if (str.includes("configure HTTPS")) stream.write("y\n");
                            if (str.includes("Select the appropriate number")) stream.write("1\n");
                            if (str.includes("(A)gree/(C)ancel")) stream.write("A\n");
                        });
                        stream.on("close", () => installWings());
                    });
                }
                function installWings() {
                    ssh.exec(installer, (err, stream) => {
                        if (err) return;
                        stream.on("data", (data) => {
                            const str = data.toString();
                            console.log("WINGS:", str);
                            if (str.includes("Input 0-6")) stream.write("1\n");
                            if (str.includes("(y/N)")) stream.write("y\n");
                            if (str.includes("Enter the panel address")) stream.write(`${domainpanel}\n`);
                            if (str.includes("Database host username")) stream.write("admin\n");
                            if (str.includes("Database host password")) stream.write("admin\n");
                            if (str.includes("Set the FQDN")) stream.write(`${domainnode}\n`);
                            if (str.includes("Enter email address")) stream.write("admin@gmail.com\n");
                        });
                        stream.on("close", () => installNode());
                    });
                }
                function installNode() {
                    ssh.exec("bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)", (err, stream) => {
                        if (err) return;
                        stream.on("data", (data) => {
                            const str = data.toString();
                            console.log("NODE:", str);
                            if (str.includes("Masukkan nama lokasi")) stream.write("Singapore\n");
                            if (str.includes("Masukkan deskripsi lokasi")) stream.write("Node By Bot AshRixHexline\n");
                            if (str.includes("Masukkan domain")) stream.write(`${domainnode}\n`);
                            if (str.includes("Masukkan nama node")) stream.write("BY ASHRIXHEXLINE\n");
                            if (str.includes("Masukkan RAM")) stream.write(`${ramserver}\n`);
                            if (str.includes("jumlah maksimum disk")) stream.write(`${ramserver}\n`);
                            if (str.includes("Masukkan Locid")) stream.write("1\n");
                        });
                        stream.on("close", async () => {
                            const panelData = { domainpanel, username: "admin", password: passwordPanel, ipVps, pwVps };
                            const installCache = setTempData(panelData, "installpanel-result");
                            await sendInline(client, chatId, `${prefix}installpanel-result ${installCache}`);
                            ssh.end();
                        });
                    });
                }
                ssh.on("ready", async () => {
                    await client.sendMessage(chatId, {
                        message: `<b>🛠️ Install Panel Dimulai...</b>\n\n<b>IP VPS:</b> ${ipVps}\n<b>Panel:</b> ${domainpanel}`,
                        replyTo: msg.id,
                        parseMode: "html"
                    });
                    installPanel();
                });
                ssh.on("error", (err) => {
                    client.sendMessage(chatId, { message: `<b>❌ SSH Error:</b> ${err.message}`, replyTo: msg.id, parseMode: "html" });
                });
                ssh.connect(connSettings);
                break;
            }

            // ============================== TO ANIME ==============================
            case "toanime": case "jadianime": case "toanim": {
                let target;
                if (msg.replyToMsgId) {
                    try { target = await msg.getReplyMessage(); } catch {}
                }
                if (!target?.media) return msg.reply({ message: "❌ Reply gambar untuk menggunakan Jadi Anime." });
                const waitMsg = await msg.reply({ message: "🖼️ Memproses anime style image..." });
                try {
                    const raw = await target.downloadMedia({ downloadUrl: false });
                    if (!raw) throw new Error("BUFFER_EMPTY");
                    const buffer = Buffer.isBuffer(raw) ? raw : Buffer.from(raw);
                    const form = new FormData();
                    form.append("apikey", "skyy");
                    form.append('file', buffer, 'image.jpg');
                    const { data } = await axios.post("https://api.skyzopedia.web.id/tools/jadianime", form, { headers: form.getHeaders() });
                    if (!data?.status || !data?.result) throw new Error("TOANIME_FAILED");
                    const cache = setTempData({ before: null, after: data.result }, "jadianime");
                    await waitMsg.delete();
                    return sendInline(client, chatId, `${prefix}jadianime ${cache}`);
                } catch (e) {
                    console.log(e);
                    await waitMsg.delete();
                    return msg.reply({ message: "❌ Gagal memproses To Anime." });
                }
            }

            // ============================== REMINI/HD ==============================
            case "hd": case "remini": case "tohd": {
                let target;
                if (msg.replyToMsgId) {
                    try { target = await msg.getReplyMessage(); } catch {}
                }
                if (!target?.media) return msg.reply({ message: "❌ Reply gambar untuk menggunakan Remini / HD." });
                const waitMsg = await msg.reply({ message: "🖼️ Memproses upscaler image..." });
                try {
                    const buffer = await target.downloadMedia({ downloadUrl: false });
                    if (!buffer) throw new Error("BUFFER_EMPTY");
                    const form = new FormData();
                    form.append('apikey', 'skyy');
                    form.append('file', buffer, 'image.jpg');
                    const { data } = await axios.post("https://api.skyzopedia.web.id/tools/upscale", form, { headers: form.getHeaders() });
                    if (!data?.status || !data?.result) throw new Error("UPSCALE_FAILED");
                    const cache = setTempData({ before: null, after: data.result }, "remini");
                    await waitMsg.delete();
                    return sendInline(client, chatId, `${prefix}remini ${cache}`);
                } catch (e) {
                    console.log("Error:", e.message, e.response?.data);
                    await waitMsg.delete();
                    return msg.reply({ message: "❌ Gagal memproses Remini / HD." });
                }
            }

            // ============================== OWNER ==============================
            case "owner": case "dev": {
                const user = await client.getEntity(config.ownerId);
                const ownerUrl = `https://t.me/${user.username}`;
                return client.sendMessage(chatId, { message: `<span class="tg-spoiler">${ownerUrl}</span>`, parseMode: "html", replyTo: msg.id });
            }

            // ============================== TO URL (CATBOX) ==============================
            case "tourl": {
                let targetMessage;
                if (msg.replyToMsgId) {
                    try {
                        const replied = await msg.getReplyMessage();
                        if (replied) targetMessage = replied;
                    } catch (error) {
                        console.error("Gagal mengambil pesan yang dibalas:", error.message);
                    }
                }
                const msgMedia = targetMessage?.media;
                if (!msgMedia) return msg.reply({ message: `Reply media (foto, video, atau dokumen) untuk menggunakannya.` });
                let buffer;
                try {
                    buffer = await targetMessage.downloadMedia({ downloadUrl: false });
                } catch (error) {
                    console.error("Gagal mendownload media:", error.message);
                    return msg.reply({ message: `❌ Gagal mendownload media.` });
                }
                if (!buffer) return msg.reply({ message: `❌ Gagal mendapatkan data buffer dari media.` });
                const { fromBuffer } = require("file-type");
                const fetchModule = await import("node-fetch");
                const fetch = fetchModule.default;
                async function uploadToCatbox(buf) {
                    let { ext } = await fromBuffer(buf);
                    let bodyForm = new FormData();
                    bodyForm.append("fileToUpload", buf, "file." + ext);
                    bodyForm.append("reqtype", "fileupload");
                    let res = await fetch("https://catbox.moe/user/api.php", { method: "POST", body: bodyForm });
                    return await res.text();
                }
                try {
                    const url = await uploadToCatbox(buffer);
                    const tourlCache = setTempData({ url }, 'tourl');
                    return sendInline(client, chatId, `${prefix}tourl ${tourlCache}`);
                } catch (error) {
                    console.error("Gagal upload ke Catbox:", error.message);
                    await msg.reply({ message: `❌ Terjadi kesalahan saat mengupload media.` });
                }
                break;
            }

            // ============================== TO URL (PIXHOST) ==============================
            case "tourl2": {
                let targetMessage;
                if (msg.replyToMsgId) {
                    try {
                        const replied = await msg.getReplyMessage();
                        if (replied) targetMessage = replied;
                    } catch {}
                }
                const msgMedia = targetMessage?.media;
                if (!msgMedia) return msg.reply({ message: "Reply gambar untuk menggunakan Pixhost." });
                let buffer;
                try {
                    buffer = await targetMessage.downloadMedia({ downloadUrl: false });
                } catch {
                    return msg.reply({ message: "❌ Gagal mendownload media." });
                }
                if (!buffer) return msg.reply({ message: "❌ Buffer media kosong." });
                const { ImageUploadService } = require("node-upload-images");
                async function uploadImageBuffer(buffer) {
                    try {
                        const service = new ImageUploadService("pixhost.to");
                        const { directLink } = await service.uploadFromBinary(buffer, "image.png");
                        return directLink || null;
                    } catch {
                        return null;
                    }
                }
                try {
                    const url = await uploadImageBuffer(buffer);
                    if (!url) throw new Error();
                    const tourl2Cache = setTempData({ url }, 'tourl2');
                    return sendInline(client, chatId, `${prefix}tourl2 ${tourl2Cache}`);
                } catch {
                    return msg.reply({ message: "❌ Gagal upload ke Pixhost (hanya support gambar)." });
                }
                break;
            }

            // ============================== TO BUGIL ==============================
            case "telanjang": case "bugil": case "tobugil": {
                let target;
                if (msg.replyToMsgId) {
                    try { target = await msg.getReplyMessage(); } catch {}
                }
                if (!target?.media) return msg.reply({ message: "❌ Reply gambar untuk menggunakan fitur tobugil." });
                const waitMsg = await msg.reply({ message: "🔄 Memproses gambar..." });
                try {
                    const buffer = await target.downloadMedia({ downloadUrl: false });
                    if (!buffer) throw new Error("BUFFER_EMPTY");
                    const form = new FormData();
                    form.append("apikey", "skyy");
                    form.append("prompt", text || "Best quality, hot bikini");
                    form.append("image", buffer, "image.jpg");
                    const { data } = await axios.post("https://skyzopedia-api2.vercel.app/tools/removeclothes", form, {
                        headers: { ...form.getHeaders() },
                        timeout: 60000
                    });
                    if (!data?.status || !data?.result) throw new Error("REMOVE_CLOTHES_FAILED");
                    await waitMsg.delete();
                    return client.sendFile(chatId, { file: data.result, caption: "<b>✅ Clothes Remover Success</b>", replyTo: msg.id, parseMode: "html", forceDocument: false });
                } catch (e) {
                    console.log("Error:", e.message, e.response?.data);
                    await waitMsg.delete();
                    return msg.reply({ message: "❌ Gagal memproses gambar." });
                }
            }

            // ============================== NPM DOWNLOAD ==============================
            case "npmdl": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} @whiskeysockets/baileys`, parseMode: "html" });
                try {
                    const axios = require("axios");
                    const fs = require("fs");
                    const path = require("path");
                    const tar = require("tar");
                    const archiver = require("archiver");
                    const pkgName = text.trim();
                    await msg.reply({ message: `<b>📦 Mengambil data package ${escapehtml(pkgName)}...</b>`, parseMode: "html" });
                    const info = await axios.get(`https://registry.npmjs.org/${encodeURIComponent(pkgName)}`);
                    const version = info.data["dist-tags"].latest;
                    const meta = await axios.get(`https://registry.npmjs.org/${encodeURIComponent(pkgName)}/${version}`);
                    const tarballUrl = meta.data?.dist?.tarball;
                    if (!tarballUrl) return msg.reply({ message: "❌ Tarball tidak ditemukan." });
                    const tmpDir = path.join(process.cwd(), "tmp");
                    const safeName = pkgName.replace(/[\/@]/g, "_");
                    const tarPath = path.join(tmpDir, `${safeName}-${version}.tgz`);
                    const extractPath = path.join(tmpDir, `${safeName}-${version}`);
                    const zipPath = path.join(tmpDir, `${safeName}-${version}.zip`);
                    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
                    if (!fs.existsSync(extractPath)) fs.mkdirSync(extractPath, { recursive: true });
                    const res = await axios.get(tarballUrl, { responseType: "arraybuffer" });
                    fs.writeFileSync(tarPath, res.data);
                    await tar.x({ file: tarPath, cwd: extractPath, strip: 1 });
                    const output = fs.createWriteStream(zipPath);
                    const archive = archiver("zip", { zlib: { level: 9 } });
                    archive.pipe(output);
                    archive.directory(extractPath, false);
                    archive.finalize();
                    await new Promise((resolve, reject) => {
                        output.on("close", resolve);
                        archive.on("error", reject);
                    });
                    await client.sendFile(msg.chatId, { file: zipPath, caption: `<b>✅ ${pkgName}@${version} berhasil diunduh</b>`, parseMode: "html", replyTo: msg.id });
                    try { fs.unlinkSync(tarPath); } catch {}
                    try { fs.rmSync(extractPath, { recursive: true, force: true }); fs.unlinkSync(zipPath); rimraf.sync(extractPath); } catch (e) { console.error("CLEANUP ERROR:", e); }
                } catch (err) {
                    console.error("NPMDL ERROR:", err);
                    await msg.reply({ message: `<b>❌ Gagal mengunduh package.</b>\nPastikan nama package benar.\n\n${err.message}`, parseMode: "html" });
                }
                break;
            }

            // ============================== MEDIAFIRE DOWNLOAD ==============================
            case "mediafire": case "mf": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} https://www.mediafire.com/file/xxxxx/file.zip`, parseMode: "html" });
                try {
                    const axios = require("axios");
                    const fs = require("fs");
                    const path = require("path");
                    await msg.reply({ message: "📥 Mengambil file MediaFire..." });
                    const { data } = await axios.get(`https://api.skyzopedia.web.id/download/mediafire?apikey=skyy&url=${encodeURIComponent(text)}`);
                    if (!data?.status || !data?.result?.url) return msg.reply({ message: "❌ Gagal mengambil file MediaFire." });
                    const { fileName, fileSize, url: downloadUrl } = data.result;
                    const tmpDir = path.join(process.cwd(), "tmp");
                    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
                    const filePath = path.join(tmpDir, fileName);
                    const res = await axios.get(downloadUrl, { responseType: "arraybuffer", headers: { "User-Agent": "Mozilla/5.0" } });
                    fs.writeFileSync(filePath, res.data);
                    await client.sendFile(msg.chatId, { file: filePath, caption: "<b>✅ MediaFire Downloader</b>", parseMode: "html", replyTo: msg.id });
                    fs.unlinkSync(filePath);
                } catch (err) {
                    console.error("MEDIAFIRE ERROR:", err);
                    msg.reply({ message: `<b>❌ Gagal download MediaFire.</b>\n\n${err.message}`, parseMode: "html" });
                }
                break;
            }

            // ============================== GIT CLONE ==============================
            case "gitclone": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} https://github.com/Skyzopedia/Baileys`, parseMode: "html" });
                try {
                    const axios = require("axios");
                    const fs = require("fs");
                    const path = require("path");
                    const archiver = require("archiver");
                    const { exec } = require("child_process");
                    const repoUrl = text.trim().replace(/\.git$/, "");
                    await msg.reply({ message: `<b>📦 Mengambil repository...</b>`, parseMode: "html" });
                    const api = await axios.get(`https://api.skyzopedia.web.id/download/github?apikey=skyy&url=${encodeURIComponent(repoUrl)}`);
                    if (!api.data?.status || !api.data?.result) return msg.reply({ message: "❌ Repository tidak valid / tidak ditemukan." });
                    const repoName = repoUrl.split("/").pop();
                    const owner = repoUrl.split("/").slice(-2, -1)[0];
                    const safeName = `${owner}-${repoName}`;
                    const tmpDir = path.join(process.cwd(), "tmp");
                    const clonePath = path.join(tmpDir, safeName);
                    const zipPath = path.join(tmpDir, `${safeName}.zip`);
                    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
                    await new Promise((resolve, reject) => {
                        exec(`git clone --depth=1 ${repoUrl} "${clonePath}"`, (err) => {
                            if (err) reject(err);
                            else resolve();
                        });
                    });
                    const output = fs.createWriteStream(zipPath);
                    const archive = archiver("zip", { zlib: { level: 9 } });
                    archive.pipe(output);
                    archive.directory(clonePath, false);
                    archive.finalize();
                    await new Promise((resolve, reject) => {
                        output.on("close", resolve);
                        archive.on("error", reject);
                    });
                    await client.sendFile(msg.chatId, { file: zipPath, caption: `<b>✅ ${owner}/${repoName}</b>\nBerhasil di-clone`, parseMode: "html", replyTo: msg.id });
                    try { fs.rmSync(clonePath, { recursive: true, force: true }); fs.unlinkSync(zipPath); } catch {}
                } catch (err) {
                    console.error("GITCLONE ERROR:", err);
                    await msg.reply({ message: `<b>❌ Gagal clone repository.</b>\nPastikan URL GitHub valid.\n\n${err.message}`, parseMode: "html" });
                }
                break;
            }

            // ============================== EVAL ==============================
            case "eval": case "ev": {
                if (!isOwner) return;
                if (!text) return msg.reply({ message: `Masukan kode untuk di evaluasi.` });
                try {
                    let result = await eval(`(async () => { ${text} })()`);
                    if (typeof result !== "string") result = require("util").inspect(result, { depth: 1 });
                    if (result.length > 4000) {
                        const fs = require("fs");
                        const filePath = "./eval_result.txt";
                        fs.writeFileSync(filePath, result);
                        await client.sendFile(msg.chatId, { file: filePath, caption: "<b>✅ Eval berhasil (hasil dikirim sebagai file)</b>", parseMode: "html" });
                        fs.unlinkSync(filePath);
                    } else {
                        const evalCache = setTempData({ result }, 'eval');
                        return sendInline(client, chatId, `${prefix}eval ${evalCache}`);
                    }
                } catch (err) {
                    const evalErrorCache = setTempData({ error: err.toString() }, 'eval-error');
                    return sendInline(client, chatId, `${prefix}eval-error ${evalErrorCache}`);
                }
                break;
            }

            // ============================== INSTAGRAM DOWNLOAD ==============================
            case "instagram": case "ig": {
                if (!text) return msg.reply({ message: `<b>Ex:</b> ${cmd} https://www.instagram.com/p/xxxx`, parseMode: "html" });
                const processingMsg = await msg.reply({ message: "⏳ Mengunduh dari Instagram..." });
                try {
                    const apiUrl = `https://co.wuk.sh/api/json`;
                    const response = await axios.post(apiUrl, { url: text, isNoTTWatermark: true }, { headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' } });
                    const data = response.data;

                    if (data && data.status === 'stream' && data.url) {
                        const mediaUrl = data.url;
                        const caption = data.title || "Konten Instagram";
                        await processingMsg.delete();
                        await client.sendFile(chatId, { file: mediaUrl, caption: escapehtml(caption), replyTo: msg.id, parseMode: "html" });
                    } else {
                         const errorDetail = data ? (data.text || JSON.stringify(data)) : 'Respon API tidak valid.';
                         await processingMsg.edit({ text: `❌ Gagal: ${errorDetail}` });
                    }
                } catch (err) {
                    const errorText = err.response ? (err.response.data.text || JSON.stringify(err.response.data)) : err.message;
                    await processingMsg.edit({ text: `❌ Error API: ${errorText}` });
                }
                break;
            }

            case "menuvpshelp": {
                if (!isOwner) return;
                const helpText = `
╭─「 📖 <b>Bantuan Perintah CVPS</b> 」
│
├ <b>Gunakan:</b>
├ <code>${prefix}cvps &lt;host&gt;,&lt;pass&gt;,&lt;os&gt;,&lt;region&gt;,&lt;size&gt;</code>
│
├ <b>Contoh:</b>
├ <code>${prefix}cvps serverku,pass123,ubuntu-22-04-x64,sgp1,s-1vcpu-1gb</code>
│
├ <i>Semua parameter dipisahkan dengan koma (,) tanpa spasi.</i>
╰─「 By ${config.ownerName} 」`;
                return msg.reply({ message: helpText.trim(), parseMode: "html" });
            }

            // ============================== RESTART ==============================
            case "restart": {
                if (!isOwner) return;
                await msg.reply({ message: "✅ Bot sedang direstart..." });
                process.exit(1);
            }

            // ============================== BACKUP ==============================
            case "backup": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const waitMsg = await msg.reply({ message: "⚙️ Memulai proses backup, ini mungkin memakan waktu..." });
                try {
                    const tmpDir = path.join(process.cwd(), "tmp");
                    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

                    const fileName = `backup-project-${new Date().toISOString().split('T')[0]}.tar.gz`;
                    const outputPath = path.join(tmpDir, fileName);
                    const output = fs.createWriteStream(outputPath);
                    const archive = archiver('tar', { gzip: true });

                    output.on('close', async () => {
                        try {
                            await waitMsg.edit({ text: `✅ Backup selesai! Mengirim file ${fileName}...` });
                            await client.sendFile(chatId, {
                                file: outputPath,
                                caption: `<b>✅ Backup Project Berhasil</b>\n\nBerikut adalah file backup project Anda.`,
                                parseMode: 'html',
                                replyTo: msg.id
                            });
                            await waitMsg.delete();
                        } catch (sendErr) {
                            console.error("Backup send error:", sendErr);
                            await waitMsg.edit({ text: `❌ Gagal mengirim file backup: ${sendErr.message}` });
                        } finally {
                            fs.unlinkSync(outputPath);
                        }
                    });

                    archive.on('error', (err) => { throw err; });
                    archive.pipe(output);

                    archive.glob('**/*', {
                        cwd: process.cwd(),
                        ignore: ['node_modules/**', 'tmp/**', 'session.txt', '*.zip', '*.tar.gz', '*.pdf', 'package-lock.json', 'vps_sessions.json', '.git/**']
                    });

                    await archive.finalize();
                } catch (err) {
                    console.error("Backup error:", err);
                    await waitMsg.edit({ message: `❌ Gagal membuat backup: ${err.message}` });
                }
                break;
            }

            // ============================== RESTORE ==============================
            case "restore": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!msg.replyTo) return msg.reply({ message: "❌ Reply ke file backup (.tar.gz) untuk restore." });

                const replied = await msg.getReplyMessage();
                if (!replied.media || !replied.media.document || !replied.media.document.attributes[0].fileName.endsWith(".tar.gz")) {
                    return msg.reply({ message: "❌ File yang di-reply harus berekstensi .tar.gz" });
                }

                const waitMsg = await msg.reply({ message: "⚙️ Memulai proses restore..." });

                try {
                    const tar = require('tar');
                    const tmpDir = path.join(process.cwd(), "tmp");
                    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
                    
                    const filePath = path.join(tmpDir, 'restore.tar.gz');
                    
                    await client.downloadMedia(replied.media, { outputFile: filePath });

                    await waitMsg.edit({ text: "⚙️ Mengekstrak file backup..." });

                    await tar.x({ file: filePath, cwd: process.cwd() });

                    fs.unlinkSync(filePath); // clean up

                    await waitMsg.edit({ text: "✅ Restore berhasil! Merestart bot..." });
                    process.exit(1); // Restart bot
                } catch (err) {
                    console.error("Restore error:", err);
                    await waitMsg.edit({ message: `❌ Gagal melakukan restore: ${err.message}` });
                }
                break;
            }

            // ============================== PROMOSI ==============================
            case "promosi": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!msg.replyTo) return msg.reply({ message: "⚠️ Reply ke pesan yang mau dipromosikan!" });

                const parts = text.split(" ");
                const targetType = parts[0];
                const intervalMinutes = parseInt(parts[1]);

                if (!targetType || !['group', 'user'].includes(targetType) || isNaN(intervalMinutes) || intervalMinutes <= 0) {
                    return msg.reply({ message: "⚠️ Format salah. Gunakan: `promosi <group|user> <interval_menit>`" });
                }

                const jobId = msg.chatId.toString();
                if (promotionJobs[jobId]) {
                    return msg.reply({ message: "⚠️ Sudah ada promosi yang berjalan di chat ini. Hentikan dulu dengan `stoppromosi`." });
                }

                const replyMsg = await msg.getReplyMessage();
                const intervalMs = intervalMinutes * 60 * 1000;

                const job = async () => {
                    console.log(`[Promosi] Menjalankan promosi otomatis ke ${targetType}...`);
                    const dialogs = await client.getDialogs();
                    let targets;
                    if (targetType === 'group') {
                        targets = dialogs.filter(d => d.isGroup && !blacklist.includes(d.id.toString()));
                    } else {
                        targets = dialogs.filter(d => d.isUser && !d.entity.bot && d.entity.id.toString() !== myId && !blacklist.includes(d.id.toString()));
                    }

                    if (targets.length === 0) {
                        console.log(`[Promosi] Tidak ada target ${targetType} yang ditemukan.`);
                        return;
                    }

                    for (const dialog of targets) {
                        try {
                            await client.forwardMessages(dialog.inputEntity, { messages: replyMsg.id, fromPeer: msg.chatId });
                        } catch (error) {
                            console.log(`[Promosi] Gagal forward ke ${targetType} ${dialog.id}: ${error.message}`);
                        }
                        await sleep(2000);
                    }
                    if (promotionJobs[jobId]) promotionJobs[jobId].lastRun = new Date();
                };

                const intervalId = setInterval(job, intervalMs);
                promotionJobs[jobId] = { intervalId, targetType, intervalMinutes, lastRun: null };
                job();

                await msg.reply({ message: `✅ Promosi otomatis ke <b>${targetType}</b> setiap <b>${intervalMinutes} menit</b> telah dimulai.\n\nGunakan <code>${prefix}stoppromosi</code> untuk menghentikan.`, parseMode: "html" });
                break;
            }

            case "stoppromosi": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const jobId = msg.chatId.toString();
                const job = promotionJobs[jobId];

                if (job) {
                    clearInterval(job.intervalId);
                    delete promotionJobs[jobId];
                    await msg.reply({ message: "✅ Promosi otomatis telah dihentikan." });
                } else {
                    await msg.reply({ message: "⚠️ Tidak ada promosi yang sedang berjalan di chat ini." });
                }
                break;
            }

            case "statuspromosi": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const jobIds = Object.keys(promotionJobs);
                if (jobIds.length === 0) return msg.reply({ message: "✅ Tidak ada promosi otomatis yang sedang berjalan." });

                let statusMessage = "<b>📊 STATUS PROMOSI OTOMATIS</b>\n\n";
                for (const jobId of jobIds) {
                    const job = promotionJobs[jobId];
                    const lastRunTime = job.lastRun ? new Date(job.lastRun).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : "Belum pernah";
                    statusMessage += `• <b>Chat ID:</b> <code>${jobId}</code>\n  - <b>Target:</b> ${job.targetType}\n  - <b>Interval:</b> ${job.intervalMinutes} menit\n  - <b>Terakhir Jalan:</b> ${lastRunTime}\n\n`;
                }
                await msg.reply({ message: statusMessage, parseMode: "html" });
                break;
            }

            // ============================== AUTO BC (CFD style repeat) ==============================
            case "autobc": {
                const subCmd = args[0]?.toLowerCase();

                // ─── STATUS ───────────────────────────────────────────────
                if (subCmd === "status") {
                    const jobIds = Object.keys(autoBcJobs);
                    if (jobIds.length === 0) return msg.reply({ message: "✅ Tidak ada autobc yang sedang berjalan." });

                    let statusMsg = "<b>📊 STATUS AUTO BC</b>\n\n";
                    for (const jid of jobIds) {
                        const j = autoBcJobs[jid];
                        const nextRun = j.nextRunAt ? new Date(j.nextRunAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : "-";
                        const lastRun = j.lastRun ? new Date(j.lastRun).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : "Belum pernah";
                        const running = j.isRunning ? "🔄 Sedang jalan" : "⏳ Menunggu";
                        statusMsg += `• <b>Key:</b> <code>${jid}</code>\n`;
                        statusMsg += `  ├ Target: <b>${j.targetType}</b> | Action: <b>${j.actionType}</b>\n`;
                        statusMsg += `  ├ Interval: <b>${j.intervalMinutes} menit</b>\n`;
                        statusMsg += `  ├ Status: ${running}\n`;
                        statusMsg += `  ├ Last run: ${lastRun}\n`;
                        statusMsg += `  └ Next run: ${nextRun}\n\n`;
                    }
                    return msg.reply({ message: statusMsg, parseMode: "html" });
                }

                // ─── OFF ──────────────────────────────────────────────────
                if (subCmd === "off" || subCmd === "stop") {
                    const jobIds = Object.keys(autoBcJobs);
                    if (jobIds.length === 0) return msg.reply({ message: "⚠️ Tidak ada autobc yang berjalan." });

                    for (const jid of jobIds) {
                        clearTimeout(autoBcJobs[jid].timeoutId);
                        autoBcJobs[jid].active = false;
                        delete autoBcJobs[jid];
                    }
                    return msg.reply({ message: "✅ Semua autobc telah dihentikan." });
                }

                // ─── ON ───────────────────────────────────────────────────
                if (subCmd === "on") {
                    if (!msg.replyTo) return msg.reply({
                        message: `⚠️ <b>Harus reply ke pesan dulu!</b>\n\nSama kayak <code>${prefix}cfd</code>, autobc butuh tau pesan mana yang mau diforward secara berulang.\n\n<b>Caranya:</b>\n1. Reply pesan yang mau di-autobc\n2. Ketik <code>${prefix}autobc on &lt;menit&gt; [target]</code>\n\n<b>Contoh:</b>\n• <code>${prefix}autobc on 60</code> → forward ke group tiap 60 menit\n• <code>${prefix}autobc on 30 all</code> → forward ke semua tiap 30 menit\n\n💡 Pesan akan di-forward <b>with "Forwarded from"</b> sehingga emoji prem, font, dan format tetap preserved!`,
                        parseMode: "html"
                    });

                    const intervalMinutes = parseInt(args[1]);
                    if (isNaN(intervalMinutes) || intervalMinutes <= 0) {
                        return msg.reply({ message: `⚠️ Masukkan interval menit yang valid!\n\n<b>Contoh:</b> <code>${prefix}autobc on 60</code>`, parseMode: "html" });
                    }

                    const rawTarget = args[2]?.toLowerCase() || "group";
                    const validTargets = {
                        'group': 'group',
                        'user': 'user',
                        'channel': 'channel',
                        'ch': 'channel',
                        'all': 'all_gc',
                        'semua': 'semua'
                    };
                    const targetType = validTargets[rawTarget];
                    if (!targetType) {
                        return msg.reply({ message: `⚠️ Target tidak valid! Gunakan: group, user, channel, all, semua` });
                    }

                    const jobId = `autobc_${chatId}_${Date.now()}`;
                    const existingJobs = Object.keys(autoBcJobs);
                    if (existingJobs.length > 0) {
                        return msg.reply({
                            message: `⚠️ Sudah ada autobc yang berjalan (${existingJobs.length} job).\nHentikan dulu dengan <code>${prefix}autobc off</code>`,
                            parseMode: "html"
                        });
                    }

                    const replyMsg = await msg.getReplyMessage();
                    if (!replyMsg) return msg.reply({ message: "⚠️ Tidak bisa ambil pesan yang direply." });

                    const intervalMs = intervalMinutes * 60 * 1000;
                    const msgId = replyMsg.id;
                    const fromPeer = replyMsg.chatId;

                    // Simpan job state
                    autoBcJobs[jobId] = {
                        active: true,
                        isRunning: false,
                        targetType,
                        actionType: "broadcast",
                        intervalMinutes,
                        lastRun: null,
                        nextRunAt: null,
                        timeoutId: null
                    };

                    // Kirim 1 pesan status yang akan di-edit terus (ga spam)
                    const statusBoard = await msg.reply({
                        message: `🔁 <b>AutoBC Aktif</b>\n\n🎯 Target: <b>${targetType}</b>\n⏱️ Interval: <b>${intervalMinutes} menit</b>\n\n⏳ Memulai broadcast pertama...`,
                        parseMode: "html"
                    });
                    autoBcJobs[jobId].statusMsgId = statusBoard.id;
                    autoBcJobs[jobId].statusChatId = chatId;

                    const updateBoard = async (text) => {
                        try {
                            await client.editMessage(chatId, { message: statusBoard.id, text, parseMode: "html" });
                        } catch (e) {}
                    };

                    const runOnce = async () => {
                        if (!autoBcJobs[jobId]?.active) return;

                        autoBcJobs[jobId].isRunning = true;
                        autoBcJobs[jobId].lastRun = new Date();
                        const runCount = (autoBcJobs[jobId]?.runCount || 0) + 1;
                        autoBcJobs[jobId].runCount = runCount;

                        const dialogs = await client.getDialogs();
                        const blacklist = readBlacklist();
                        const me2 = await client.getMe();
                        const myId2 = me2.id?.value?.toString() ?? me2.id?.toString() ?? "";

                        const filterMap = {
                            'group':   d => d.isGroup,
                            'user':    d => d.isUser && !d.entity.bot && d.entity.id.toString() !== myId2,
                            'channel': d => d.isChannel && !d.isGroup,
                            'all_gc':  d => d.isGroup || (d.isChannel && !d.isGroup),
                            'semua':   d => (d.isGroup || (d.isChannel && !d.isGroup) || (d.isUser && !d.entity.bot && d.entity.id.toString() !== myId2))
                        };

                        const targets = dialogs.filter(d => filterMap[targetType]?.(d) && !blacklist.includes(d.id.toString()));
                        const total = targets.length;

                        if (total === 0) {
                            console.log(`[AutoBC] Tidak ada target ${targetType}.`);
                            autoBcJobs[jobId].isRunning = false;
                            scheduleNext();
                            return;
                        }

                        await updateBoard(`🔁 <b>AutoBC Berjalan... (Run #${runCount})</b>\n\n🎯 Target: <b>${targetType}</b> (${total} target)\n⏱️ Interval: <b>${intervalMinutes} menit</b>\n\n⏳ Sedang broadcast...`);

                        let sukses = 0, gagal = 0;

                        for (const d of targets) {
                            if (!autoBcJobs[jobId]?.active) break;
                            try {
                                await client.forwardMessages(d.id, { messages: [msgId], fromPeer: fromPeer, dropAuthor: false });
                                sukses++;
                            } catch (e) {
                                gagal++;
                                console.log(`[AutoBC] Gagal ke ${d.name || d.id}: ${e.message}`);
                                if (e.seconds) await sleep(e.seconds * 1000);
                            }
                            const randDelay = Math.floor(Math.random() * 500) + 500;
                            await sleep(randDelay);
                        }

                        autoBcJobs[jobId].isRunning = false;

                        const nextTime = new Date(Date.now() + intervalMs).toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit' });
                        await updateBoard(`🔁 <b>AutoBC Standby (Run #${runCount} selesai)</b>\n\n🎯 Target: <b>${targetType}</b>\n📊 Sukses: <b>${sukses}</b> | Gagal: <b>${gagal}</b> | Total: <b>${total}</b>\n⏱️ Interval: <b>${intervalMinutes} menit</b>\n⏰ Next run: <b>~${nextTime} WIB</b>\n\n<i>Gunakan .autobc off untuk berhenti</i>`);

                        scheduleNext();
                    };

                    const scheduleNext = () => {
                        if (!autoBcJobs[jobId]?.active) return;
                        autoBcJobs[jobId].nextRunAt = Date.now() + intervalMs;
                        autoBcJobs[jobId].timeoutId = setTimeout(() => runOnce(), intervalMs);
                    };

                    runOnce(); // langsung jalan pertama kali
                    break;
                }

                // ─── HELP ─────────────────────────────────────────────────
                return msg.reply({
                    message: `📣 <b>AutoBC - Auto Broadcast (Forward)</b>\n\n<b>Cara pakai:</b>\n1. Reply pesan yang mau diforward berulang\n2. Ketik command\n\n<b>Command:</b>\n• <code>${prefix}autobc on &lt;menit&gt; [target]</code> — mulai autobc\n• <code>${prefix}autobc off</code> — hentikan autobc\n• <code>${prefix}autobc status</code> — cek status\n\n<b>Target tersedia:</b> group, user, channel, all, semua\n<b>Default target:</b> group\n\n<b>Contoh:</b>\n• <code>${prefix}autobc on 60</code>\n• <code>${prefix}autobc on 30 all</code>\n• <code>${prefix}autobc on 120 semua</code>\n\n💡 Pesan diforward <b>"with Forwarded from"</b> — emoji prem, font, quote, stiker tetap preserved!`,
                    parseMode: "html"
                });
            }

            // ============================== GIKES (SEND COPY) ==============================
            case "gikes": {
                const [targetType] = args;
                if (!['group', 'user'].includes(targetType)) return msg.reply({ message: `Gunakan: ${cmd} <group|user>` });
                return handleBroadcast(msg, { targetType: targetType, actionType: 'copy' });
            }

            // ============================== SPAM ==============================
            case "spam": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!msg.replyTo) return msg.reply({ message: "⚠️ Reply pesan yang mau dispam!" });
                const count = parseInt(text);
                if (isNaN(count) || count <= 0) return msg.reply({ message: `Gunakan: ${cmd} <jumlah>` });

                const replyMsg = await msg.getReplyMessage();
                await msg.delete();

                for (let i = 0; i < count; i++) {
                    try {
                        const spamOptions = { message: replyMsg.message || "" };
                        if (replyMsg.media) {
                            spamOptions.file = replyMsg.media;
                        }
                        await client.sendMessage(chatId, spamOptions);
                    } catch {}
                    await sleep(200);
                }
                break;
            }

            // ============================== PAKASIR QRIS ==============================
            case "qris": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const amount = parseInt(text);
                if (!amount || isNaN(amount)) return msg.reply({ message: `Gunakan: ${cmd} <nominal>` });
                if (!config.pakasir) return msg.reply({ message: "⚠️ Konfigurasi Pakasir tidak ditemukan di config.js" });

                const processingMsg = await msg.reply({ message: "⏳ Membuat QRIS..." });
                try {
                    const orderId = `INV${Date.now()}`;
                    const payload = { project: config.pakasir.projectSlug, order_id: orderId, amount: amount, api_key: config.pakasir.apiKey };
                    const { data } = await axios.post(`${config.pakasir.baseUrl}${config.pakasir.endpoints.createQris}`, payload);

                    if (data && data.payment && data.payment.payment_number) {
                        const qrContent = data.payment.payment_number;
                        const totalBayar = data.payment.total_payment || amount;
                        const qrImageUrl = generateQrImage(qrContent);

                        const qrisMessage = await client.sendFile(chatId, {
                            file: qrImageUrl,
                            caption: `✅ <b>Tagihan Dibuat!</b>\n\n💵 Total Bayar: <b>Rp ${totalBayar.toLocaleString('id-ID')}</b>\n🆔 ID: <code>${orderId}</code>\n\n<i>Silakan scan QR di atas. Status akan diperbarui otomatis...</i>`,
                            replyTo: msg.id,
                            parseMode: "html",
                        });
                        await processingMsg.delete();

                        // Polling logic
                        const pollInterval = 5000;
                        const pollTimeout = 5 * 60 * 1000;
                        const startTime = Date.now();

                        const pollStatus = async () => {
                            if (Date.now() - startTime > pollTimeout) {
                                try {
                                    await client.editMessage(qrisMessage.chatId, { message: qrisMessage.id, text: `⏰ Waktu cek status untuk ID <code>${orderId}</code> habis. Cek manual dengan <code>${prefix}cek ${orderId} ${amount}</code>.` });
                                } catch {}
                                return;
                            }
                            try {
                                const { data: statusData } = await axios.get(`${config.pakasir.baseUrl}${config.pakasir.endpoints.checkStatus}`, { params: { project: config.pakasir.projectSlug, amount: amount, order_id: orderId, api_key: config.pakasir.apiKey } });
                                if (statusData && statusData.transaction) {
                                    const trx = statusData.transaction;
                                    if (['completed', 'failed', 'expired'].includes(trx.status)) {
                                        const statusOutput = formatTransactionStatus(trx);
                                        await client.editMessage(qrisMessage.chatId, { message: qrisMessage.id, text: statusOutput, parseMode: "html" });
                                        return;
                                    }
                                }
                            } catch (error) {
                                console.error(`Error polling status for ${orderId}:`, error.message);
                            }
                            setTimeout(pollStatus, pollInterval);
                        };
                        setTimeout(pollStatus, pollInterval);
                    } else {
                        await processingMsg.edit({ text: `❌ Gagal membuat QRIS: Respon API tidak valid.` });
                    }
                } catch (err) {
                    const errorText = err.response ? JSON.stringify(err.response.data) : err.message;
                    await processingMsg.edit({ text: `❌ Gagal membuat QRIS.\n\n<code>${errorText}</code>`, parseMode: "html" });
                }
                break;
            }

            case "cek": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!config.pakasir) return msg.reply({ message: "⚠️ Konfigurasi Pakasir tidak ditemukan di config.js" });
                const [orderId, amount] = text.split(" ");
                if (!orderId || !amount) return msg.reply({ message: `Gunakan: ${cmd} <order_id> <nominal>` });

                try {
                    const { data } = await axios.get(`${config.pakasir.baseUrl}${config.pakasir.endpoints.checkStatus}`, { params: { project: config.pakasir.projectSlug, amount: parseInt(amount), order_id: orderId, api_key: config.pakasir.apiKey } });
                    if (data && data.transaction) {
                        const output = formatTransactionStatus(data.transaction);
                        await msg.reply({ message: output, parseMode: "html" });
                    } else {
                        await msg.reply({ message: `❌ Transaksi dengan ID <code>${orderId}</code> tidak ditemukan.`, parseMode: "html" });
                    }
                } catch (err) {
                    const errorText = err.response ? JSON.stringify(err.response.data) : err.message;
                    await msg.reply({ message: `❌ Gagal cek status.\n\n<code>${errorText}</code>`, parseMode: "html" });
                }
                break;
            }

            case "cancel": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                if (!config.pakasir) return msg.reply({ message: "⚠️ Konfigurasi Pakasir tidak ditemukan di config.js" });
                const [orderId, amount] = text.split(" ");
                if (!orderId || !amount) return msg.reply({ message: `Gunakan: ${cmd} <order_id> <nominal>` });

                try {
                    await axios.post(`${config.pakasir.baseUrl}${config.pakasir.endpoints.cancel}`, { project: config.pakasir.projectSlug, order_id: orderId, amount: parseInt(amount), api_key: config.pakasir.apiKey });
                    await msg.reply({ message: `✅ Transaksi <code>${orderId}</code> berhasil dibatalkan.`, parseMode: "html" });
                } catch (err) {
                    const errorText = err.response ? JSON.stringify(err.response.data) : err.message;
                    await msg.reply({ message: `❌ Gagal membatalkan transaksi.\n\n<code>${errorText}</code>`, parseMode: "html" });
                }
                break;
            }

            // ============================== BUSINESS TOOLS ==============================
            case "done": {
                 if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                 if (!msg.replyTo) return msg.reply({ message: "⚠️ Perintah ini harus me-reply pesan customer." });
 
                 let itemName, price, paymentMethod;
                 const commandContent = text.trim();
 
                 const replyMsg = await msg.getReplyMessage();
                 if (!replyMsg || !replyMsg.sender) {
                     return msg.reply({ message: "⚠️ Tidak dapat menemukan customer dari balasan pesan." });
                 }
 
                 if (commandContent) {
                     const parts = commandContent.split("-");
                     if (parts.length > 2) {
                         paymentMethod = parts.pop().trim();
                         const priceStr = parts.pop().trim();
                         itemName = parts.join("-").trim();
                         price = parseInt(priceStr.replace(/[^0-9]/g, ''));
                     } else if (parts.length > 1) {
                         const priceStr = parts.pop().trim();
                         itemName = parts.join("-").trim();
                         price = parseInt(priceStr.replace(/[^0-9]/g, ''));
                         paymentMethod = null;
                     }
                 } else {
                     const customerText = replyMsg.message ? replyMsg.message.toLowerCase() : "";
                     const priceListConfig = config.priceList;
                     if (priceListConfig && Array.isArray(priceListConfig) && priceListConfig.length > 0) {
                         const foundItem = priceListConfig.find(item => item.name && customerText.includes(item.name.toLowerCase()));
                         if (foundItem) {
                             itemName = foundItem.name;
                             price = foundItem.price;
                         }
                     }
                 }
 
                 if (!itemName || isNaN(price)) {
                     return msg.reply({ message: `⚠️ <b>Format Perintah Salah</b>\n\nGunakan salah satu cara:\n1. <code>${prefix}done &lt;Item&gt; - &lt;Harga&gt; [- &lt;Metode&gt;]</code>\n2. Reply ke pesan customer yang berisi nama produk dari pricelist, lalu ketik <code>${prefix}done</code>.`, parseMode: "html" });
                 }
 
                 const targetUser = await client.getEntity(replyMsg.sender);
 
                 let fileToSend;
                 if (msg.photo) {
                     fileToSend = msg.media;
                 }
 
                 if (!db.settings.transactions) db.settings.transactions = [];
                 db.settings.transactions.push({ itemName, price, date: new Date().toISOString() });
 
                 const customerName = `${targetUser.firstName || ""} ${targetUser.lastName || ""}`.trim();
                 const customerUsername = targetUser.username ? `@${targetUser.username}` : "<i>(tidak ada)</i>";
                 const transactionDate = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });
 
                 let doneMessage = `
 ✅ <b>TRANSAKSI BERHASIL</b> ✅
 
 <blockquote>Terima kasih telah melakukan transaksi dengan kami. Berikut adalah detail transaksi Anda:</blockquote>
 
 👤 <b>Customer:</b> <a href="tg://user?id=${targetUser.id}">${escapehtml(customerName)}</a>
 🗣️ <b>Username:</b> ${customerUsername}
 🆔 <b>User ID:</b> <code>${targetUser.id}</code>
 🗓️ <b>Tanggal:</b> ${transactionDate}
 
 🛒 <b>Nama Barang:</b> ${escapehtml(itemName)}
 💰 <b>Harga:</b> Rp ${price.toLocaleString('id-ID')}
 `;
 
                 if (paymentMethod) {
                     doneMessage += `\n💳 <b>Metode Bayar:</b> ${escapehtml(paymentMethod)}`;
                 }
 
                 doneMessage += `\n<blockquote>Kami tunggu orderan selanjutnya!</blockquote>`;
 
                 const sendMessageOptions = {
                    message: doneMessage.trim(),
                    replyTo: replyMsg.id,
                    parseMode: "html"
                 };
                 if (fileToSend) {
                    sendMessageOptions.file = fileToSend;
                 }
                 const sentMessage = await client.sendMessage(chatId, sendMessageOptions);

                 if (config.doneLogChannel) {
                     try {
                         await client.forwardMessages(config.doneLogChannel, { messages: sentMessage.id, fromPeer: chatId });
                     } catch (error) {
                         console.error(`❌ Gagal forward 'done' log: ${error.message}`);
                     }
                 }
                 await msg.delete();
                 break;
             }

            case "pricelist": {
                if (!config.priceList || config.priceList.length === 0) return msg.reply({ message: "⚠️ Daftar harga tidak diatur di `config.js`." });

                let priceListMessage = "<b>🏷️ DAFTAR HARGA</b>\n\n";
                config.priceList.forEach(item => {
                    priceListMessage += `• <b>${item.name}</b>\n  - Harga: <code>Rp ${item.price.toLocaleString('id-ID')}</code>\n`;
                    if (item.description) priceListMessage += `  - Deskripsi: <i>${item.description}</i>\n`;
                    priceListMessage += `\n`;
                });
                await msg.reply({ message: priceListMessage, parseMode: "html" });
                break;
            }

            case "rekap": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                const todaysTransactions = db.settings.transactions.filter(t => new Date(t.date) >= today);
                if (todaysTransactions.length === 0) return msg.reply({ message: "Tidak ada transaksi hari ini." });

                const totalSales = todaysTransactions.reduce((sum, t) => sum + t.price, 0);
                let rekapMessage = `<b>📊 REKAP PENJUALAN HARIAN</b>\n\n<b>Total:</b> <code>Rp ${totalSales.toLocaleString('id-ID')}</code> (${todaysTransactions.length} Transaksi)\n\n<b>Detail:</b>\n`;
                todaysTransactions.forEach((t, i) => {
                    rekapMessage += `${i + 1}. ${t.itemName} - <code>Rp ${t.price.toLocaleString('id-ID')}</code>\n`;
                });
                await msg.reply({ message: rekapMessage, parseMode: "html" });
                break;
            }

            case "exportrekap": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                const todaysTransactions = db.settings.transactions.filter(t => new Date(t.date) >= today);
                if (todaysTransactions.length === 0) return msg.reply({ message: "Tidak ada transaksi hari ini untuk diekspor." });

                const totalSales = todaysTransactions.reduce((sum, t) => sum + t.price, 0);
                const dateString = new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric' });
                let rekapText = `REKAPITULASI PENJUALAN HARIAN\nTanggal: ${dateString}\n\nTotal Penjualan: Rp ${totalSales.toLocaleString('id-ID')}\nJumlah Transaksi: ${todaysTransactions.length}\n\n---Detail---\n`;
                todaysTransactions.forEach((t, i) => {
                    rekapText += `${i + 1}. ${t.itemName} - Rp ${t.price.toLocaleString('id-ID')}\n`;
                });

                const rekapBuffer = Buffer.from(rekapText.trim(), 'utf-8');
                const fileName = `rekap_${new Date().toISOString().split('T')[0]}.txt`;
                await client.sendFile(chatId, { file: rekapBuffer, caption: `Rekap penjualan ${dateString}`, attributes: [new Api.DocumentAttributeFilename({ fileName })] });
                break;
            }

            case "exportpdf": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                const todaysTransactions = db.settings.transactions.filter(t => new Date(t.date) >= today);

                if (todaysTransactions.length === 0) {
                    return msg.reply({ message: "Tidak ada transaksi hari ini untuk diekspor ke PDF." });
                }

                const waitMsg = await msg.reply({ message: "📄 Membuat PDF rekap harian..." });

                try {
                    const doc = new PDFDocument({ margin: 50, size: 'A4' });
                    const dateString = new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric' });
                    const fileName = `Rekap_Harian_${new Date().toISOString().split('T')[0]}.pdf`;
                    const filePath = `./tmp/${fileName}`;
                    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp');

                    const writeStream = fs.createWriteStream(filePath);
                    doc.pipe(writeStream);

                    // --- PDF Content ---
                    // Header
                    doc.font('Helvetica-Bold').fontSize(18).text('Rekapitulasi Penjualan Harian', { align: 'center' });
                    doc.fontSize(12).text(dateString, { align: 'center' });
                    doc.moveDown(2);

                    // Table Header
                    const tableTop = doc.y;
                    const itemX = 50;
                    const dateX = 150;
                    const priceX = 400;
                    
                    doc.font('Helvetica-Bold');
                    doc.text('No.', itemX, tableTop);
                    doc.text('Nama Barang', dateX, tableTop);
                    doc.text('Harga', priceX, tableTop, { width: 100, align: 'right' });
                    doc.moveTo(itemX, doc.y).lineTo(550, doc.y).stroke();
                    doc.moveDown();

                    // Table Rows
                    doc.font('Helvetica');
                    let totalSales = 0;
                    todaysTransactions.forEach((t, i) => {
                        const y = doc.y;
                        doc.text(i + 1, itemX, y);
                        doc.text(t.itemName, dateX, y, { width: 240 });
                        doc.text(`Rp ${t.price.toLocaleString('id-ID')}`, priceX, y, { width: 100, align: 'right' });
                        totalSales += t.price;
                        doc.moveDown();
                    });
                    
                    doc.moveTo(itemX, doc.y).lineTo(550, doc.y).stroke();
                    doc.moveDown();

                    // Summary
                    doc.font('Helvetica-Bold');
                    doc.text(`Total Transaksi: ${todaysTransactions.length}`, { align: 'right' });
                    doc.text(`Total Penjualan: Rp ${totalSales.toLocaleString('id-ID')}`, { align: 'right' });
                    
                    // Footer
                    const range = doc.page.bufferedPageRange();
                    for (let i = range.start; i < range.start + range.count; i++) {
                        doc.switchToPage(i);
                        doc.fontSize(8).text(`Halaman ${i + 1} dari ${range.count}`, 50, doc.page.height - 30, { align: 'center' });
                    }

                    doc.end();
                    // --- End PDF Content ---

                    writeStream.on('finish', async () => {
                        await client.sendFile(chatId, {
                            file: filePath,
                            caption: `📄 Berikut adalah rekap penjualan harian dalam format PDF.`,
                            replyTo: msg.id,
                            attributes: [new Api.DocumentAttributeFilename({ fileName })]
                        });
                        await waitMsg.delete();
                        fs.unlinkSync(filePath);
                    });

                } catch (error) {
                    console.error("PDF Export Error:", error);
                    await waitMsg.edit({ text: `❌ Gagal membuat PDF: ${error.message}` });
                }
                break;
            }

            case "exportpdfbulan": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                
                const [month, year] = text.split(" ").map(Number);
                const targetMonth = isNaN(month) ? new Date().getMonth() : month - 1;
                const targetYear = isNaN(year) ? new Date().getFullYear() : year;

                const monthlyTransactions = db.settings.transactions.filter(t => {
                    const d = new Date(t.date);
                    return d.getMonth() === targetMonth && d.getFullYear() === targetYear;
                });

                if (monthlyTransactions.length === 0) {
                    return msg.reply({ message: `Tidak ada transaksi untuk bulan ${targetMonth + 1}/${targetYear} untuk diekspor.` });
                }

                const waitMsg = await msg.reply({ message: "📄 Membuat PDF rekap bulanan..." });

                try {
                    const doc = new PDFDocument({ margin: 50, size: 'A4' });
                    const monthName = new Date(targetYear, targetMonth).toLocaleString('id-ID', { month: 'long', year: 'numeric' });
                    const fileDateString = `${targetYear}-${String(targetMonth + 1).padStart(2, '0')}`;
                    const fileName = `Rekap_Bulanan_${fileDateString}.pdf`;
                    const filePath = `./tmp/${fileName}`;
                    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp');

                    const writeStream = fs.createWriteStream(filePath);
                    doc.pipe(writeStream);

                    // --- PDF Content ---
                    doc.font('Helvetica-Bold').fontSize(18).text('Rekapitulasi Penjualan Bulanan', { align: 'center' });
                    doc.fontSize(12).text(monthName, { align: 'center' });
                    doc.moveDown(2);

                    const drawHeader = () => {
                        const tableTop = doc.y;
                        doc.font('Helvetica-Bold');
                        doc.text('No.', 50, tableTop);
                        doc.text('Tanggal', 90, tableTop);
                        doc.text('Nama Barang', 180, tableTop);
                        doc.text('Harga', 400, tableTop, { width: 100, align: 'right' });
                        doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
                        doc.moveDown();
                    };

                    drawHeader();

                    doc.font('Helvetica');
                    let totalSales = 0;
                    monthlyTransactions.forEach((t, i) => {
                        if (doc.y > doc.page.height - 80) {
                            doc.addPage();
                            drawHeader();
                        }
                        const y = doc.y;
                        const transactionDate = new Date(t.date).toLocaleDateString('id-ID');
                        doc.text(i + 1, 50, y);
                        doc.text(transactionDate, 90, y);
                        doc.text(t.itemName, 180, y, { width: 210 });
                        doc.text(`Rp ${t.price.toLocaleString('id-ID')}`, 400, y, { width: 100, align: 'right' });
                        totalSales += t.price;
                        doc.moveDown(0.5);
                    });
                    
                    doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
                    doc.moveDown();

                    doc.font('Helvetica-Bold');
                    doc.text(`Total Transaksi: ${monthlyTransactions.length}`, { align: 'right' });
                    doc.text(`Total Penjualan: Rp ${totalSales.toLocaleString('id-ID')}`, { align: 'right' });
                    
                    const range = doc.page.bufferedPageRange();
                    for (let i = range.start; i < range.start + range.count; i++) {
                        doc.switchToPage(i);
                        doc.fontSize(8).text(`Halaman ${i + 1} dari ${range.count}`, 50, doc.page.height - 30, { align: 'center' });
                    }

                    doc.end();
                    // --- End PDF Content ---

                    writeStream.on('finish', async () => {
                        await client.sendFile(chatId, {
                            file: filePath,
                            caption: `📄 Berikut adalah rekap penjualan bulanan untuk ${monthName} dalam format PDF.`,
                            replyTo: msg.id,
                            attributes: [new Api.DocumentAttributeFilename({ fileName })]
                        });
                        await waitMsg.delete();
                        fs.unlinkSync(filePath);
                    });

                } catch (error) {
                    console.error("PDF Export Error:", error);
                    await waitMsg.edit({ text: `❌ Gagal membuat PDF: ${error.message}` });
                }
                break;
            }

            case "rekapbulan": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const [month, year] = text.split(" ").map(Number);
                const targetMonth = isNaN(month) ? new Date().getMonth() : month - 1;
                const targetYear = isNaN(year) ? new Date().getFullYear() : year;

                const monthlyTransactions = db.settings.transactions.filter(t => {
                    const d = new Date(t.date);
                    return d.getMonth() === targetMonth && d.getFullYear() === targetYear;
                });
                if (monthlyTransactions.length === 0) return msg.reply({ message: `Tidak ada transaksi untuk bulan ${targetMonth + 1}/${targetYear}.` });

                const totalSales = monthlyTransactions.reduce((sum, t) => sum + t.price, 0);
                const monthName = new Date(targetYear, targetMonth).toLocaleString('id-ID', { month: 'long', year: 'numeric' });
                let rekapMessage = `<b>📊 REKAP PENJUALAN BULANAN</b>\nBulan: ${monthName}\n\n<b>Total:</b> <code>Rp ${totalSales.toLocaleString('id-ID')}</code> (${monthlyTransactions.length} Transaksi)\n\n<b>Detail:</b>\n`;
                monthlyTransactions.forEach((t, i) => {
                    rekapMessage += `${i + 1}. ${t.itemName} - <code>Rp ${t.price.toLocaleString('id-ID')}</code>\n`;
                });
                await msg.reply({ message: rekapMessage, parseMode: "html" });
                break;
            }

            case "exportrekapbulan": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const [month, year] = text.split(" ").map(Number);
                const targetMonth = isNaN(month) ? new Date().getMonth() : month - 1;
                const targetYear = isNaN(year) ? new Date().getFullYear() : year;

                const monthlyTransactions = db.settings.transactions.filter(t => {
                    const d = new Date(t.date);
                    return d.getMonth() === targetMonth && d.getFullYear() === targetYear;
                });

                if (monthlyTransactions.length === 0) {
                    const monthName = new Date(targetYear, targetMonth).toLocaleString('id-ID', { month: 'long' });
                    return msg.reply({ message: `Tidak ada transaksi bulan ${monthName} ${targetYear} untuk diekspor.` });
                }

                const totalSales = monthlyTransactions.reduce((sum, t) => sum + t.price, 0);
                const monthName = new Date(targetYear, targetMonth).toLocaleString('id-ID', { month: 'long', year: 'numeric' });
                const fileDateString = `${targetYear}-${String(targetMonth + 1).padStart(2, '0')}`;

                let rekapText = `REKAPITULASI PENJUALAN BULANAN\nBulan: ${monthName}\n\nTotal Penjualan: Rp ${totalSales.toLocaleString('id-ID')}\nJumlah Transaksi: ${monthlyTransactions.length}\n\n---Detail---\n`;
                monthlyTransactions.forEach((t, i) => {
                    const transactionDate = new Date(t.date).toLocaleDateString('id-ID');
                    rekapText += `[${transactionDate}] ${i + 1}. ${t.itemName} - Rp ${t.price.toLocaleString('id-ID')}\n`;
                });

                const rekapBuffer = Buffer.from(rekapText.trim(), 'utf-8');
                const fileName = `rekap_bulanan_${fileDateString}.txt`;
                await client.sendFile(chatId, { file: rekapBuffer, caption: `Rekap penjualan bulanan ${monthName}`, attributes: [new Api.DocumentAttributeFilename({ fileName })] });
                break;
            }


            case "cleantrx": {
                if (!isOwner) return msg.reply({ message: "❌ Owner only!" });
                const days = parseInt(text);
                if (isNaN(days) || days <= 0) return msg.reply({ message: `Gunakan: ${cmd} <jumlah_hari>` });

                const cutoffDate = new Date();
                cutoffDate.setDate(cutoffDate.getDate() - days);
                const oldLength = db.settings.transactions.length;
                db.settings.transactions = db.settings.transactions.filter(t => new Date(t.date) >= cutoffDate);
                const deletedCount = oldLength - db.settings.transactions.length;

                if (deletedCount === 0) return msg.reply({ message: `Tidak ada transaksi lebih tua dari ${days} hari.` });
                await msg.reply({ message: `✅ Berhasil membersihkan <b>${deletedCount}</b> log transaksi.`, parseMode: "html" });
                break;
            }

            case "batalcvps": {
                if (!isOwner) return;
                if (cvpsSessions.has(fromIdStr)) {
                    cvpsSessions.delete(fromIdStr);
                    await msg.reply({ message: '✅ Sesi pembuatan VPS dibatalkan.' });
                } else {
                    await msg.reply({ message: '⚠️ Tidak ada sesi pembuatan VPS yang aktif.' });
                }
                break;
            }

            case "cvps": {
                if (!isOwner) return;
                if (cvpsSessions.has(fromIdStr)) {
                    return msg.reply({ message: 'Anda sudah dalam sesi pembuatan VPS. Ketik /batalcvps untuk membatalkan.' });
                }
                if (!config.digitalOcean?.apiToken) return msg.reply({ message: "⚠️ API Token DigitalOcean belum diatur di `config.js`." });

                cvpsSessions.set(fromIdStr, { step: 'hostname', chatId: chatId.toString() });
                await msg.reply({ message: 'Memulai sesi pembuatan VPS interaktif...\n\nSilakan masukkan **hostname** untuk VPS baru:' });
                break;
            }

            case "listvps": {
                if (!isOwner) return;
                if (!config.digitalOcean?.apiToken) return msg.reply({ message: "⚠️ API Token DigitalOcean belum diatur." });
                const processingMsg = await msg.reply({ message: "⏳ Mengambil daftar VPS..." });
                try {
                    const { data } = await axios.get('https://api.digitalocean.com/v2/droplets?per_page=200', { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                    if (data.droplets.length === 0) return await processingMsg.edit({ text: "Tidak ada VPS aktif." });

                    let listText = `<b>📋 LIST VPS AKTIF (${data.droplets.length})</b>\n\n`;
                    data.droplets.forEach(d => {
                        const ip = d.networks.v4.find(n => n.type === 'public')?.ip_address || 'N/A';
                        listText += `• <b>${d.name}</b>\n  ID: <code>${d.id}</code>\n  IP: <code>${ip}</code>\n  Status: ${d.status}\n\n`;
                    });
                    await processingMsg.edit({ text: listText, parseMode: "html" });
                } catch (error) {
                    await processingMsg.edit({ text: `❌ Gagal mengambil list: ${error.message}` });
                }
                break;
            }

            case "delvps":
            case "startvps":
            case "stopvps":
            case "rebootvps":
            case "cekvps": {

                if (!isOwner) return;
                if (!config.digitalOcean?.apiToken) return msg.reply({ message: "⚠️ API Token DigitalOcean belum diatur." });
                const dropletId = text;
                if (!dropletId) return msg.reply({ message: `Gunakan: ${cmd} <vps_id>` });

                if (command === "cekvps") {
                    const processingMsg = await msg.reply({ message: `⏳ Mengecek VPS ${dropletId}...` });
                    try {
                        const { data } = await axios.get(`https://api.digitalocean.com/v2/droplets/${dropletId}`, { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                        const d = data.droplet;
                        const ip = d.networks.v4.find(n => n.type === 'public')?.ip_address || 'N/A';
                        let detailText = `<b>ℹ️ DETAIL VPS</b>\n\n<b>Nama:</b> ${d.name}\n<b>ID:</b> <code>${d.id}</code>\n<b>IP:</b> <code>${ip}</code>\n<b>Status:</b> ${d.status}\n<b>OS:</b> ${d.image.distribution} ${d.image.name}\n<b>RAM:</b> ${d.size.memory}MB\n<b>CPU:</b> ${d.size.vcpus} vCPU\n<b>Disk:</b> ${d.size.disk}GB`;
                        return await processingMsg.edit({ text: detailText, parseMode: "html" });
                    } catch (error) {
                        return await processingMsg.edit({ text: `❌ Gagal mengecek: ${error.message}` });
                    }
                }

                if (command === "delvps") {
                    const processingMsg = await msg.reply({ message: `⏳ Menghapus VPS ${dropletId}...` });
                    try {
                        await axios.delete(`https://api.digitalocean.com/v2/droplets/${dropletId}`, { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                        return await processingMsg.edit({ text: `✅ VPS ${dropletId} berhasil dihapus.` });
                    } catch (error) {
                        return await processingMsg.edit({ text: `❌ Gagal menghapus: ${error.message}` });
                    }
                }

                const actionMap = {
                    startvps: { type: "power_on", verb: "menyalakan" },
                    stopvps: { type: "power_off", verb: "mematikan" },
                    rebootvps: { type: "reboot", verb: "reboot" },
                };
                const { type, verb } = actionMap[command];
                const processingMsg = await msg.reply({ message: `⏳ Memproses ${verb} VPS ${dropletId}...` });
                try {
                    await axios.post(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, { type }, { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                    await processingMsg.edit({ text: `✅ Perintah ${verb} VPS ${dropletId} berhasil dikirim.` });
                } catch (error) {
                    await processingMsg.edit({ text: `❌ Gagal: ${error.message}` });
                }
                break;
            }

            case "rebuildvps": {
                if (!isOwner) return;
                if (!config.digitalOcean?.apiToken) return msg.reply({ message: "⚠️ API Token DigitalOcean belum diatur." });
                const [dropletId, osSlug] = text.split(",").map(s => s.trim());
                if (!dropletId || !osSlug) return msg.reply({ message: `Gunakan: ${cmd} <vps_id>,<os_slug>` });

                const processingMsg = await msg.reply({ message: `⏳ Merebuild VPS ${dropletId} dengan OS ${osSlug}...` });
                try {
                    await axios.post(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, { type: 'rebuild', image: osSlug }, { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                    await processingMsg.edit({ text: `✅ Perintah rebuild untuk VPS ${dropletId} berhasil dikirim.` });
                } catch (error) {
                    const errorMsg = error.response ? JSON.stringify(error.response.data) : error.message;
                    await processingMsg.edit({ text: `❌ Gagal rebuild: ${errorMsg}` });
                }
                break;
            }


            case "balance": {
                if (!isOwner) return;
                if (!config.digitalOcean?.apiToken) return msg.reply({ message: "⚠️ API Token DigitalOcean belum diatur." });
                const processingMsg = await msg.reply({ message: "⏳ Mengambil info saldo..." });
                try {
                    const { data } = await axios.get('https://api.digitalocean.com/v2/customers/my/balance', { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                    let balanceText = `<b>💰 SALDO DIGITALOCEAN</b>\n\n<b>Pemakaian Bulan Ini:</b> $${data.month_to_date_usage}\n<b>Sisa Saldo Akun:</b> $${data.account_balance}`;
                    await processingMsg.edit({ text: balanceText, parseMode: "html" });
                } catch (error) {
                    await processingMsg.edit({ text: `❌ Gagal mengambil saldo: ${error.message}` });
                }
                break;
            }

            case "limitdo": {
                if (!isOwner) return;
                if (!config.digitalOcean?.apiToken) return msg.reply({ message: "⚠️ API Token DigitalOcean belum diatur." });

                const processingMsg = await msg.reply({ message: "⏳ Mengambil info limit droplet..." });
                try {
                    const { data: accountData } = await axios.get('https://api.digitalocean.com/v2/account', { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                    const dropletLimit = accountData.account.droplet_limit;

                    const { data: dropletsData } = await axios.get('https://api.digitalocean.com/v2/droplets?per_page=1', { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                    const dropletCount = dropletsData.meta.total;

                    const remainingDroplets = dropletLimit - dropletCount;
                    const percentage = dropletLimit > 0 ? (dropletCount / dropletLimit) * 100 : 0;

                    let limitText = `<b>📊 LIMIT DROPLET DIGITALOCEAN</b>\n\n`;
                    limitText += `<b>Total Limit:</b> ${dropletLimit} Droplets\n`;
                    limitText += `<b>Droplet Digunakan:</b> ${dropletCount}\n`;
                    limitText += `<b>Sisa Droplet:</b> ${remainingDroplets}\n\n`;
                    limitText += createProgressBar(Math.round(percentage), 20);

                    await processingMsg.edit({ text: limitText, parseMode: "html" });
                } catch (error) {
                    const errorMsg = error.response ? JSON.stringify(error.response.data) : error.message;
                    await processingMsg.edit({ text: `❌ Gagal mengambil info limit: ${errorMsg}` });
                }
                break;
            }

            case "listos":
            case "listregions":
            case "listsizes": {
                if (!isOwner) return;
                if (!config.digitalOcean?.apiToken) return msg.reply({ message: "⚠️ API Token DigitalOcean belum diatur." });

                const apiEndpoints = {
                    listos: { url: 'https://api.digitalocean.com/v2/images?type=distribution&per_page=200', title: "OS" },
                    listregions: { url: 'https://api.digitalocean.com/v2/regions?per_page=200', title: "Region" },
                    listsizes: { url: 'https://api.digitalocean.com/v2/sizes?per_page=200', title: "Ukuran" }
                };

                const { url, title } = apiEndpoints[command];
                const processingMsg = await msg.reply({ message: `⏳ Mengambil daftar ${title}...` });

                try {
                    const { data } = await axios.get(url, { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                    const items = data.images || data.regions || data.sizes;

                    if (!items || items.length === 0) return await processingMsg.edit({ text: `Tidak ada ${title} yang tersedia.` });

                    let listText = `<b>📋 DAFTAR ${title.toUpperCase()} TERSEDIA</b>\n\n`;

                    if (command === "listos") {
                        items.forEach(item => {
                            listText += `• <b>${item.distribution} ${item.name}</b>\n  Slug: <code>${item.slug}</code>\n\n`;
                        });
                    } else if (command === "listregions") {
                        items.filter(r => r.available).forEach(item => {
                            listText += `• <b>${item.name}</b>\n  Slug: <code>${item.slug}</code>\n\n`;
                        });
                    } else if (command === "listsizes") {
                        items.forEach(item => {
                            listText += `• <b>${item.slug}</b>\n  RAM: ${item.memory}MB | CPU: ${item.vcpus} | Disk: ${item.disk}GB\n  Harga: $${item.price_monthly}/bln\n\n`;
                        });
                    }

                    if (listText.length > 4096) {
                        const filePath = `./tmp/do_${command}.txt`;
                        if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp');
                        fs.writeFileSync(filePath, listText.replace(/<b>|<\/b>|<code>|<\/code>/g, ''));
                        await client.sendFile(chatId, { file: filePath, caption: `Daftar ${title} terlalu panjang, dikirim sebagai file.` });
                        fs.unlinkSync(filePath);
                        await processingMsg.delete();
                    } else {
                        await processingMsg.edit({ text: listText, parseMode: "html" });
                    }
                } catch (error) {
                    await processingMsg.edit({ text: `❌ Gagal mengambil daftar ${title}: ${error.message}` });
                }
                break;
            }

            case "loginvps": {
                if (!isOwner) return;
                if (!text || !text.includes('|')) return msg.reply({ message: `Gunakan: \`${prefix}loginvps <ip>|<password>\``, parseMode: 'markdown' });
                
                const [host, password] = text.split('|');
                const conn = new SSHClient();
                const loading = await msg.reply({ message: `🔌 Menghubungkan ke ${host}...` });

                conn.on('ready', () => {
                    vpsLoginSessions.set(fromIdStr, { host, password, username: 'root' });
                    writeVpsSessions(vpsLoginSessions);
                    loading.edit({ text: `✅ Berhasil login ke VPS: \`${host}\``, parseMode: 'markdown' });
                    conn.end();
                }).on('error', (err) => {
                    loading.edit({ text: `❌ Gagal login: ${err.message}` });
                }).connect({
                    host,
                    port: 22,
                    username: 'root',
                    password,
                    readyTimeout: 20000
                });
                break;
            }

            case "logoutvps": {
                if (!isOwner) return;
                if (vpsLoginSessions.has(fromIdStr)) {
                    const { host } = vpsLoginSessions.get(fromIdStr);
                    vpsLoginSessions.delete(fromIdStr);
                    writeVpsSessions(vpsLoginSessions);
                    await msg.reply({ message: `✅ Berhasil logout dari VPS: \`${host}\``, parseMode: 'markdown' });
                } else {
                    await msg.reply({ message: "⚠️ Anda belum login ke VPS manapun." });
                }
                break;
            }

            case "installprotect": {
                if (!isOwner) return;
                if (!vpsLoginSessions.has(fromIdStr)) {
                    return msg.reply({ message: `⚠️ Anda harus login ke VPS terlebih dahulu.\n\nGunakan: \`${prefix}loginvps <ip>|<password>\``, parseMode: 'markdown' });
                }

                const buttons = Object.keys(protectDescriptions).map(key => 
                    [new Api.KeyboardButtonCallback(
                        `Install Protect ${key}`,
                        `protect|install|${key}`
                    )]
                );

                await msg.reply({
                    message: "Pilih proteksi yang ingin diinstal:",
                    buttons: client.buildReplyMarkup(buttons)
                });
                break;
            }
            
            case "uninstallprotect": {
                if (!isOwner) return;
                if (!vpsLoginSessions.has(fromIdStr)) {
                    return msg.reply({ message: `⚠️ Anda harus login ke VPS terlebih dahulu.\n\nGunakan: \`${prefix}loginvps <ip>|<password>\``, parseMode: 'markdown' });
                }

                const buttons = Object.keys(protectDescriptions).map(key => 
                    [new Api.KeyboardButtonCallback(`Uninstall Protect ${key}`, `protect|uninstall|${key}`)]
                );

                await msg.reply({ message: "Pilih proteksi yang ingin di-uninstall:", buttons: client.buildReplyMarkup(buttons) });
                break;
            }

            default:
                break;
        }
    }, new NewMessage({ outgoing: true, incoming: true }));

    // == CVPS Callback Handler ==
    client.addEventHandler(async (event) => {
        const query = event;
        const fromIdStr = query.senderId.toString();
        const cvpsSession = cvpsSessions.get(fromIdStr);

        if (!cvpsSession || !query.data) return;

        const data = query.data.toString('utf-8');
        const [action, ...params] = data.split('|');

        try {
            switch (action) {
                case 'cvps_os': {
                    const [osSlug] = params;
                    cvpsSession.os = osSlug;
                    cvpsSession.step = 'region';

                    const regionData = await getDoData('regions');
                    const availableRegions = regionData.regions.filter(r => r.available);
                    const regionButtons = availableRegions.map(r =>
                        [new Api.KeyboardButtonCallback(
                            `${r.name}`,
                            `cvps_region|${r.slug}`
                        )]
                    );

                    await client.editMessage(cvpsSession.chatId, {
                        message: cvpsSession.lastMsgId,
                        text: '✅ OS dipilih. Sekarang pilih **Region**:',
                        buttons: client.buildReplyMarkup(regionButtons)
                    });
                    break;
                }

                case 'cvps_region': {
                    const [regionSlug] = params;
                    cvpsSession.region = regionSlug;
                    cvpsSession.step = 'size';

                    const sizeData = await getDoData('sizes');
                    const availableSizes = sizeData.sizes.filter(s => s.available && s.regions.includes(cvpsSession.region) && s.price_monthly < 50);
                    const sizeButtons = availableSizes.map(s =>
                        [new Api.KeyboardButtonCallback(
                            `$${s.price_monthly} - ${s.vcpus}vCPU, ${s.memory/1024}GB RAM, ${s.disk}GB SSD`,
                            `cvps_size|${s.slug}`
                        )]
                    );

                    await client.editMessage(cvpsSession.chatId, {
                        message: cvpsSession.lastMsgId,
                        text: '✅ Region dipilih. Sekarang pilih **Ukuran VPS**:',
                        buttons: client.buildReplyMarkup(sizeButtons)
                    });
                    break;
                }

                case 'cvps_size': {
                    const [sizeSlug] = params;
                    cvpsSession.size = sizeSlug;
                    cvpsSession.step = 'creating';
                    cvpsSessions.set(fromIdStr, cvpsSession);

                    await client.editMessage(cvpsSession.chatId, {
                        message: cvpsSession.lastMsgId,
                        text: `⏳ <b>Membuat VPS...</b>\nHost: ${cvpsSession.hostname}\nOS: ${cvpsSession.os}\nUkuran: ${cvpsSession.size}\nRegion: ${cvpsSession.region}`,
                        parseMode: 'html',
                        buttons: []
                    });

                    // --- Creation Logic ---
                    try {
                        const { data: createData } = await axios.post('https://api.digitalocean.com/v2/droplets', {
                            name: cvpsSession.hostname, region: cvpsSession.region, size: cvpsSession.size, image: cvpsSession.os, user_data: `#cloud-config\npassword: ${cvpsSession.password}\nchpasswd: { expire: False }\nssh_pwauth: True`
                        }, { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                        const droplet = createData.droplet;

                        await client.editMessage(cvpsSession.chatId, { message: cvpsSession.lastMsgId, text: `✅ VPS Dibuat (ID: ${droplet.id}). Menunggu IP...` });
                        await sleep(20000);

                        const { data: finalData } = await axios.get(`https://api.digitalocean.com/v2/droplets/${droplet.id}`, { headers: { 'Authorization': `Bearer ${config.digitalOcean.apiToken}` } });
                        const ip = finalData.droplet.networks.v4.find(n => n.type === 'public')?.ip_address || 'Belum tersedia';

                        let finalMessage = `✅ <b>VPS Berhasil Dibuat!</b>\n\n🌐 <b>IP:</b> <code>${ip}</code>\n👤 <b>User:</b> <code>root</code>\n🔑 <b>Pass:</b> <code>${cvpsSession.password}</code>\n\n🆔 <b>ID:</b> <code>${droplet.id}</code>`;
                        await client.editMessage(cvpsSession.chatId, { message: cvpsSession.lastMsgId, text: finalMessage, parseMode: "html" });
                    } catch (error) {
                        const errorMsg = error.response ? JSON.stringify(error.response.data) : error.message;
                        await client.editMessage(cvpsSession.chatId, { message: cvpsSession.lastMsgId, text: `❌ <b>Gagal membuat VPS!</b>\n\n<pre>${errorMsg}</pre>`, parseMode: "html" });
                    } finally {
                        cvpsSessions.delete(fromIdStr);
                    }
                    break;
                }

                case 'createsubdo': {
                    const me = await client.getMe();
                    const myId = me.id.toString();
                    const isOwner = query.senderId.toString() === config.ownerId?.toString() || query.senderId.toString() === myId;
                    if (!isOwner) return client.answerCallbackQuery(query.id, { message: "Owner only!", alert: true });

                    const [hostname, ip, domain] = params;
                    const domainConfig = config.subdomain[domain];

                    if (!domainConfig) {
                        return client.answerCallbackQuery(query.id, { message: "Domain tidak valid.", alert: true });
                    }

                    const { zone: zoneId, apitoken: apiToken } = domainConfig;
                    const fullHostname = `${hostname}.${domain}`;

                    await client.editMessage(query.chatId, {
                        message: query.messageId,
                        text: `⏳ Membuat subdomain <b>${escapehtml(fullHostname)}</b>...`,
                        parseMode: 'html',
                        buttons: []
                    });

                    try {
                        const { data: cfData } = await axios.post(`https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`, {
                            type: 'A', name: fullHostname, content: ip, ttl: 1, proxied: false
                        }, {
                            headers: { 'Authorization': `Bearer ${apiToken}`, 'Content-Type': 'application/json' }
                        });

                        if (cfData.success) {
                            await client.editMessage(query.chatId, {
                                message: query.messageId,
                                text: `✅ <b>Subdomain Berhasil Dibuat!</b>\n\n<b>Hostname:</b> <code>${escapehtml(fullHostname)}</code>\n<b>IP:</b> <code>${escapehtml(ip)}</code>\n\nSilakan tunggu beberapa saat untuk propagasi DNS.`,
                                parseMode: 'html'
                            });
                        } else {
                            throw new Error(cfData.errors[0]?.message || 'Gagal membuat record DNS.');
                        }
                    } catch (err) {
                        const errorMsg = err.response?.data?.errors?.[0]?.message || err.message;
                        await client.editMessage(query.chatId, { message: query.messageId, text: `❌ <b>Gagal membuat subdomain!</b>\n\n<pre>${escapehtml(errorMsg)}</pre>`, parseMode: 'html' });
                    }
                    break;
                }
            }
        } catch (e) {
            cvpsSessions.delete(fromIdStr);
            if (cvpsSession.chatId && cvpsSession.lastMsgId) {
                await client.editMessage(cvpsSession.chatId, { message: cvpsSession.lastMsgId, text: `❌ Terjadi error pada sesi CVPS: ${e.message}` }).catch(() => {});
            }
        }
    }, new CallbackQuery({}));

    // == Protect Panel Callback Handler ==
    client.addEventHandler(async (event) => {
        const query = event;
        const fromIdStr = query.senderId.toString();

        if (!query.data) return;
        const data = query.data.toString('utf-8');
        const [action, ...params] = data.split('|');

        if (!['protect', 'do_protect', 'cancel_protect'].includes(action)) return;

        try {
            switch(action) {
                case 'protect': {
                    const [type, protectNum] = params;
                    if (!vpsLoginSessions.has(fromIdStr)) {
                        return client.answerCallbackQuery(query.id, { message: "Sesi login VPS tidak ditemukan. Silakan login ulang.", alert: true });
                    }
                    
                    const protectInfo = protectDescriptions[protectNum];
                    if (!protectInfo) return client.answerCallbackQuery(query.id, { message: "Proteksi tidak valid.", alert: true });
        
                    const descText = protectInfo.desc.map(d => `• ${d}`).join("\n");
                    const actionText = type === 'install' ? 'Mengaktifkan' : 'Menonaktifkan';
                    
                    const confirmationText = `⚠️ *Konfirmasi ${type === 'install' ? 'Instalasi' : 'Uninstalasi'} Protect ${protectNum}*\n\n` +
                                             `🔐 *Security:* *${protectInfo.title}*\n\n` +
                                             `${descText}\n\n` +
                                             `• ${actionText} Protect ${protectNum}\n` +
                                             `• Mengubah file inti Pterodactyl\n\n` +
                                             `Anda yakin ingin melanjutkan?`;
        
                    await client.editMessage(fromIdStr, {
                        message: query.messageId,
                        text: confirmationText,
                        parseMode: 'markdown',
                        buttons: client.buildReplyMarkup([
                            [
                                new Api.KeyboardButtonCallback('✅ Lanjut', `do_protect|${type}|${protectNum}`),
                                new Api.KeyboardButtonCallback('❌ Batal', `cancel_protect`)
                            ]
                        ])
                    });
                    break;
                }
                case 'do_protect': {
                    const [type, protectNum] = params;
                    if (!vpsLoginSessions.has(fromIdStr)) return client.answerCallbackQuery(query.id, { message: "Sesi login VPS tidak ditemukan.", alert: true });
                    
                    const session = vpsLoginSessions.get(fromIdStr);
                    const protectInfo = protectDescriptions[protectNum];
        
                    const { host, username, password } = session;

                    await client.editMessage(fromIdStr, {
                        message: query.messageId,
                        text: `⚙️ Memulai **${type}** untuk **Protect ${protectNum}: ${protectInfo.title}** pada VPS **${host}**...\n\nMenghubungkan via SSH...`,
                        buttons: [],
                        parseMode: 'markdown'
                    });

                    const conn = new SSHClient();
                    let outputLog = ``;
                    const initialText = `⚙️ Proses **${type}** untuk **Protect ${protectNum}: ${protectInfo.title}**\n\n`;

                    const updateMessage = async (newText) => {
                        outputLog += newText;
                        if (updateMessage.timeout) clearTimeout(updateMessage.timeout);
                        updateMessage.timeout = setTimeout(async () => {
                            try {
                                await client.editMessage(fromIdStr, {
                                    message: query.messageId,
                                    text: `${initialText}<code>${escapehtml(outputLog)}</code>`,
                                    parseMode: 'html'
                                });
                            } catch (e) {
                                if (!e.message.includes('MESSAGE_NOT_MODIFIED')) {
                                    console.error("Update message error:", e);
                                }
                            }
                        }, 1000);
                    };

                    conn.on('ready', async () => {
                        await updateMessage(`✅ Terhubung ke ${host}!\n\n`);
                        try {
                            await handleProtection(conn, type, protectNum, updateMessage);
                            await client.sendMessage(fromIdStr, {
                                message: `✅ Proses **${type}** untuk **Protect ${protectNum}** telah selesai.`,
                                replyTo: query.messageId,
                                parseMode: 'markdown'
                            });
                        } catch (e) {
                            await client.sendMessage(fromIdStr, {
                                message: `❌ Terjadi kesalahan saat menjalankan proteksi: ${e.message}`,
                                replyTo: query.messageId
                            });
                        } finally {
                            conn.end();
                        }
                    }).on('error', async (err) => {
                        await client.editMessage(fromIdStr, { message: query.messageId, text: `❌ Gagal terhubung ke VPS: ${err.message}` });
                    }).connect({ host, port: 22, username, password, readyTimeout: 20000 });
                    break;
                }
                case 'cancel_protect': {
                    await client.editMessage(fromIdStr, { message: query.messageId, text: '❌ Proses dibatalkan.', buttons: [], parseMode: 'markdown' });
                    break;
                }
            }
        } catch (e) {
            console.error("Protect Panel Callback Error:", e);
            await client.answerCallbackQuery(query.id, { message: "Terjadi error!", alert: true }).catch(()=>{});
        }
    }, new CallbackQuery({}));
};

let file = require.resolve(__filename);
fs.watchFile(file, () => { fs.unwatchFile(file); delete require.cache[file]; require(file); });