const config = require("./config");
const fs = require("fs");
const axios = require("axios");
const os = require("os");
const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const ubotManager = require("./lib/ubotManager");

// Simpan state login sementara per user (nomor, phoneCodeHash, client)
// Map: userId → { step, phone, phoneCodeHash, client }
const loginSessions = new Map();

/**
 * Konfigurasi Token & Username Bot
 */
const prefix = config.prefix || ".";

// ==============================
//        UTILITY FUNCTIONS
// ==============================
function escapeHTML(text) {
  if (!text || typeof text !== "string") return "";
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Format uptime
function runtime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}h ${m}m ${s}s`;
}

// Format tanggal (sederhana)
function tanggal(ms) {
  const date = new Date(ms);
  return date.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
}

// ==============================
//         MENU BUILDERS
// ==============================
const getMenuText = (ctx) => {
  const start = process.hrtime.bigint();
  const end = process.hrtime.bigint(); // HARUSNYA dihitung setelah sesuatu, tapi biar konsisten
  const speed = Number(end - start) / 1e6;
  const ownTag = `<a href="tg://user?id=${config.ownerId}">${escapeHTML(
    config.ownerName
  )}</a>`;
  
  return `<blockquote>╭─ ❖ <b>zetzubot Information</b>
│ 🤖 <b>Name:</b> zetzubot
│ ⚙️ <b>Version:</b> v3.6.0
│ ⚡ <b>Speed:</b> ${speed.toFixed(2)} ms
│ ⏳ <b>Runtime:</b> ${runtime(process.uptime())}
│ 🌐 <b>Mode:</b> ${global.selfMode ? "Self" : "Public"}
│ 👑 <b>Owner:</b> ${ownTag}
│ 🅿️ <b>Prefix:</b> [ ${config.prefix} ]
╰─ ❖
<i>By @kyounoichi</i></blockquote>`;
};

const getStoreMenu = () => `<blockquote>╭─ ❖ <b>Store & Business Menu</b>
│
├─ 📢 <b>Broadcast & Promosi</b>
│  <code>${prefix}cfd</code>, <code>${prefix}cfdch</code>, <code>${prefix}cfdall</code>
│  <code>${prefix}bcgc</code>, <code>${prefix}bcuser</code>
│  <code>${prefix}gikes &lt;group|user&gt;</code>
│  <code>${prefix}cfd [target]</code> (Forward)
│  <code>${prefix}bc [target]</code> (Broadcast)
│  <code>${prefix}gikes [target]</code> (Copy)
│  <code>${prefix}promosi &lt;group|user&gt; &lt;menit&gt;</code>
│  <code>${prefix}stoppromosi</code>, <code>${prefix}statuspromosi</code>
│  <code>${prefix}autobc on &lt;menit&gt; [target]</code>, <code>${prefix}autobc off</code>, <code>${prefix}autobc status</code>
│  <code>${prefix}spam &lt;jumlah&gt;</code>
│
├─ 🚫 <b>Manajemen Blacklist</b>
│  <code>${prefix}addbl</code>, <code>${prefix}delbl</code>
│
├─ 💸 <b>Transaksi & Penjualan</b>
│  <code>${prefix}qris &lt;nominal&gt;</code>
│  <code>${prefix}cek &lt;id&gt; &lt;nominal&gt;</code>
│  <code>${prefix}done &lt;item&gt; - &lt;harga&gt;</code>
│  <code>${prefix}pay</code>, <code>${prefix}pricelist</code>, <code>${prefix}proses</code>
│
├─ 📊 <b>Rekapitulasi</b>
│  <code>${prefix}rekap</code>, <code>${prefix}rekapbulan</code>
│  <code>${prefix}exportrekap</code>, <code>${prefix}exportpdf</code>
│  <code>${prefix}exportpdfbulan</code>, <code>${prefix}cleantrx &lt;hari&gt;</code>
│
╰─ ❖</blockquote>`;

const getPanelMenu = () => `<blockquote>╭─ ❖ <b>Pterodactyl Menu</b>
│
├─ 👤 <b>Manajemen User</b>
│  <code>${prefix}1gb</code> - <code>${prefix}10gb</code>, <code>${prefix}unli &lt;user&gt;</code>
│  <code>${prefix}listpanel</code>, <code>${prefix}delpanel</code>
│
├─ 🛠️ <b>Manajemen Admin</b>
│  <code>${prefix}cadmin</code>, <code>${prefix}listadmin</code>, <code>${prefix}deladmin</code>
│
├─ ⚙️ <b>Utilitas Server</b>
│  <code>${prefix}suspendpanel</code>, <code>${prefix}unsuspendpanel</code>
│  <code>${prefix}totalserver</code>
│
├─ 🌐 <b>Domain</b>
│  <code>${prefix}subdo</code>
│
╰─ ❖</blockquote>`;

const getVpsMenu = () => `<blockquote>╭─ ❖ <b>DigitalOcean Menu</b>
│
├─ 💻 <b>Manajemen VPS</b>
│  <code>${prefix}cvps</code> (Interaktif)
│  <code>${prefix}delvps &lt;id&gt;</code>
│  <code>${prefix}listvps</code>, <code>${prefix}cekvps &lt;id&gt;</code>
│
├─ ⚡ <b>Aksi Power</b>
│  <code>${prefix}startvps &lt;id&gt;</code>, <code>${prefix}stopvps &lt;id&gt;</code>
│  <code>${prefix}rebootvps &lt;id&gt;</code>
│  <code>${prefix}rebuildvps &lt;id&gt;,&lt;os&gt;</code>
│
├─ ℹ️ <b>Informasi Akun</b>
│  <code>${prefix}balance</code>, <code>${prefix}limitdo</code>
│
├─ 📋 <b>List Data</b>
│  <code>${prefix}listos</code>, <code>${prefix}listregions</code>, <code>${prefix}listsizes</code>
│
╰─ ❖</blockquote>`;

const getOwnerMenu = () => `<blockquote>╭─ ❖ <b>Owner Menu</b>
│
├─ 👑 <b>Akses Penuh</b>
│  <code>${prefix}eval</code>, <code>${prefix}backup</code>, <code>${prefix}restore</code>
│  <code>${prefix}restart</code>
│
├─ ⚙️ <b>Mode Bot</b>
│  <code>${prefix}self</code>, <code>${prefix}public</code>
│  <code>${prefix}afk &lt;alasan&gt;</code>
│
├─ 🛠️ <b>Installer & VPS</b>
│  <code>${prefix}installpanel</code>
│  <code>${prefix}uninstallpanel</code>
│  <code>${prefix}startwings</code>
│  <code>${prefix}loginvps &lt;ip&gt;|&lt;pass&gt;</code>, <code>${prefix}logoutvps</code>
│
├─ 🛡️ <b>Proteksi Panel</b>
│  <code>${prefix}installprotect</code>, <code>${prefix}uninstallprotect</code>
╰─ ❖</blockquote>`;

const getSearchMenu = () => `<blockquote>╭─ ❖ <b>Search Menu</b>
│
├─ 📦 <b>Package</b>
│  <code>${prefix}npm &lt;package&gt;</code>
│
├─ 🖼️ <b>Gambar</b>
│  <code>${prefix}pinterest &lt;query&gt;</code>
│
├─ 🔥 <b>Random</b>
│  <code>${prefix}nsfw</code>, <code>${prefix}waifu</code>
│
╰─ ❖</blockquote>`;

const getToolsMenu = () => `<blockquote>╭─ ❖ <b>Tools Menu</b>
│
├─ 🛠️ <b>Utilitas</b>
│  <code>${prefix}ai</code>, <code>${prefix}ping</code>
│  <code>${prefix}id</code>, <code>${prefix}me</code>
│  <code>${prefix}tourl</code>, <code>${prefix}tourl2</code>
│
├─ 📝 <b>Notes</b>
│  <code>${prefix}note</code>, <code>${prefix}get</code>
│  <code>${prefix}listnote</code>, <code>${prefix}delnote</code>
│
├─ 🎨 <b>Image Tools</b>
│  <code>${prefix}tohd</code>, <code>${prefix}jadianime</code>
│  <code>${prefix}telanjang</code>
│
├─ ⚙️ <b>Advanced</b>
│  <code>${prefix}encjs</code> (reply file)
│  <code>${prefix}cleardns</code>, <code>${prefix}cekch</code>
│
╰─ ❖</blockquote>`;

const getDownloadMenu = () => `<blockquote>╭─ ❖ <b>Download Menu</b>
│
├─ 🎵 <b>Audio & Video</b>
│  <code>${prefix}tiktok</code>, <code>${prefix}ttmp3</code>
│  <code>${prefix}ytmp3</code>, <code>${prefix}ytmp4</code>
│  <code>${prefix}play</code>
│
├─ 📱 <b>Sosial Media</b>
│  <code>${prefix}instagram</code>
│  <code>${prefix}spotify</code>
│
├─ 📂 <b>File & Kode</b>
│  <code>${prefix}npmdl</code>, <code>${prefix}gitclone</code>
│  <code>${prefix}mediafire</code>
│
╰─ ❖</blockquote>`;

// ==============================
//           CHECK OWNER
// ==============================
const isOwner = (ctx) => {
  const fromId =
    ctx.from?.id ||
    ctx.callbackQuery?.from?.id ||
    ctx.inlineQuery?.from?.id;
  const botId = ctx.botInfo?.id;
  return String(fromId) === String(config.ownerId) || String(fromId) === String(botId);
};

// ==============================
//         EXPORT MODULE
// ==============================
module.exports = (bot) => {

  // ══════════════════════════════════════════════════════════════
  //   HELPER
  // ══════════════════════════════════════════════════════════════
  const isOwner = (ctx) => String(ctx.from?.id) === String(config.ownerId);
  const isReseller = (ctx) => {
    const data = ubotManager.getUser(ctx.from?.id);
    return data?.role === "reseller" || isOwner(ctx);
  };
  const canGiveAccess = (ctx) => isReseller(ctx);

  // ══════════════════════════════════════════════════════════════
  //   /start — sambutan
  // ══════════════════════════════════════════════════════════════
  bot.command("start", async (ctx) => {
    const userId = ctx.from.id;
    const data = ubotManager.getUser(userId);
    const running = ubotManager.isRunning(userId);

    let status = "❌ Belum punya akses";
    if (data?.hasAccess && running) status = "✅ Userbot aktif";
    else if (data?.hasAccess && !running) status = "⚠️ Akses ada, userbot belum jalan";

    const expText = data?.expiry
      ? `\n⏳ <b>Expiry:</b> ${new Date(data.expiry).toLocaleDateString("id-ID")}`
      : "";

    await ctx.reply(
      `<b>🤖 Selamat datang di ${config.ownerName} Ubot!</b>\n\n` +
      `👤 <b>ID kamu:</b> <code>${userId}</code>\n` +
      `📡 <b>Status:</b> ${status}${expText}\n\n` +
      `Gunakan /buat untuk membuat userbot kamu.\n` +
      `Gunakan /status untuk cek status userbot.`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🚀 Buat Userbot", callback_data: "ubot:buat" }],
            [{ text: "📊 Status", callback_data: "ubot:status" }],
          ]
        }
      }
    );
  });

  // ══════════════════════════════════════════════════════════════
  //   /status — cek status userbot user
  // ══════════════════════════════════════════════════════════════
  bot.command("status", async (ctx) => {
    const userId = ctx.from.id;
    const data = ubotManager.getUser(userId);
    const running = ubotManager.isRunning(userId);

    if (!data?.hasAccess) {
      return ctx.reply("❌ Kamu belum punya akses userbot.\nHubungi owner atau gunakan /beli.", { parse_mode: "HTML" });
    }

    const expText = data.expiry
      ? `⏳ <b>Expiry:</b> ${new Date(data.expiry).toLocaleDateString("id-ID")}`
      : "⏳ <b>Expiry:</b> Selamanya";

    await ctx.reply(
      `📊 <b>Status Userbot</b>\n\n` +
      `👤 <b>Akun:</b> ${data.name || "-"}\n` +
      `📡 <b>Running:</b> ${running ? "✅ Aktif" : "❌ Mati"}\n` +
      `${expText}`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: running
            ? [[{ text: "⏹ Stop Userbot", callback_data: "ubot:stop" }]]
            : [[{ text: "▶️ Jalankan Userbot", callback_data: "ubot:start" }]]
        }
      }
    );
  });

  // ══════════════════════════════════════════════════════════════
  //   FLOW BUAT USERBOT — callback "ubot:buat"
  // ══════════════════════════════════════════════════════════════
  bot.action("ubot:buat", async (ctx) => {
    await ctx.answerCbQuery();
    const userId = ctx.from.id;
    const data = ubotManager.getUser(userId);

    if (!data?.hasAccess) {
      return ctx.reply("❌ Kamu belum punya akses.\nHubungi owner untuk mendapatkan akses.");
    }
    if (ubotManager.isRunning(userId)) {
      return ctx.reply("⚠️ Userbot kamu sudah aktif! Gunakan /status untuk info lebih lanjut.");
    }

    loginSessions.set(String(userId), { step: "phone" });
    await ctx.reply(
      "📱 <b>Masukkan nomor Telegram kamu</b>\n\n" +
      "Format: <code>+628xxxxxxxxxx</code>\n" +
      "Ketik /batal untuk membatalkan.",
      { parse_mode: "HTML" }
    );
  });

  // ══════════════════════════════════════════════════════════════
  //   FLOW BUAT USERBOT — command /buat (alias)
  // ══════════════════════════════════════════════════════════════
  bot.command("buat", async (ctx) => {
    const userId = ctx.from.id;
    const data = ubotManager.getUser(userId);

    if (!data?.hasAccess) {
      return ctx.reply("❌ Kamu belum punya akses.\nHubungi owner untuk mendapatkan akses.");
    }
    if (ubotManager.isRunning(userId)) {
      return ctx.reply("⚠️ Userbot kamu sudah aktif! Gunakan /status.");
    }

    loginSessions.set(String(userId), { step: "phone" });
    await ctx.reply(
      "📱 <b>Masukkan nomor Telegram kamu</b>\n\n" +
      "Format: <code>+628xxxxxxxxxx</code>\n" +
      "Ketik /batal untuk membatalkan.",
      { parse_mode: "HTML" }
    );
  });

  // ══════════════════════════════════════════════════════════════
  //   /batal — cancel flow login
  // ══════════════════════════════════════════════════════════════
  bot.command("batal", async (ctx) => {
    const userId = String(ctx.from.id);
    const sess = loginSessions.get(userId);
    if (sess?.client) {
      try { await sess.client.disconnect(); } catch {}
    }
    loginSessions.delete(userId);
    await ctx.reply("✅ Proses dibatalkan.");
  });

  // ══════════════════════════════════════════════════════════════
  //   HANDLER PESAN TEKS — proses tiap step login
  // ══════════════════════════════════════════════════════════════
  bot.on("text", async (ctx, next) => {
    const userId = String(ctx.from.id);
    const sess = loginSessions.get(userId);
    if (!sess) return next(); // bukan dalam flow login, lanjut ke handler lain

    const text = ctx.message.text.trim();

    // ── Step 1: terima nomor ──────────────────────────────────
    if (sess.step === "phone") {
      const phone = text.startsWith("+") ? text : `+${text}`;
      await ctx.reply("⏳ Mengirim kode OTP...");

      try {
        const client = new TelegramClient(
          new StringSession(""),
          config.apiId,
          config.apiHash,
          { connectionRetries: 3 }
        );
        client.setLogLevel("none");
        await client.connect();

        const result = await client.invoke(
          new Api.auth.SendCode({
            phoneNumber: phone,
            apiId: config.apiId,
            apiHash: config.apiHash,
            settings: new Api.CodeSettings({}),
          })
        );

        loginSessions.set(userId, {
          step: "otp",
          phone,
          phoneCodeHash: result.phoneCodeHash,
          client,
        });

        await ctx.reply(
          "📨 <b>Kode OTP sudah dikirim ke Telegram kamu.</b>\n\n" +
          "Masukkan kode yang kamu terima:\n" +
          "<i>(Format: 12345)</i>",
          { parse_mode: "HTML" }
        );
      } catch (e) {
        loginSessions.delete(userId);
        await ctx.reply(`❌ Gagal kirim OTP: ${e.message}\n\nCoba lagi dengan /buat`);
      }
      return;
    }

    // ── Step 2: terima OTP ────────────────────────────────────
    if (sess.step === "otp") {
      try {
        await sess.client.invoke(
          new Api.auth.SignIn({
            phoneNumber: sess.phone,
            phoneCodeHash: sess.phoneCodeHash,
            phoneCode: text.replace(/\s/g, ""),
          })
        );
        // Login berhasil tanpa 2FA
        await finishLogin(ctx, userId, sess.client);
      } catch (e) {
        if (e.message?.includes("SESSION_PASSWORD_NEEDED")) {
          // Butuh 2FA - simpan phoneCode buat referensi
          loginSessions.set(userId, { ...sess, step: "2fa", phoneCode: text.replace(/\s/g, "") });
          await ctx.reply(
            "🔐 <b>Akun kamu menggunakan 2FA.</b>\n\nMasukkan password 2FA kamu:",
            { parse_mode: "HTML" }
          );
        } else {
          loginSessions.delete(userId);
          try { await sess.client.disconnect(); } catch {}
          await ctx.reply(`❌ OTP salah atau expired: ${e.message}\n\nCoba lagi dengan /buat`);
        }
      }
      return;
    }

    // ── Step 3: terima password 2FA ───────────────────────────
    if (sess.step === "2fa") {
      try {
        const passwordObj = await sess.client.invoke(new Api.account.GetPassword());

        // Coba beberapa cara import sesuai versi GramJS yang terpasang
        let srp;
        try {
          // GramJS >= 2.x
          const PasswordModule = require("telegram/Password");
          console.log("[2FA Debug] telegram/Password exports:", Object.keys(PasswordModule));
          const { computeCheck } = PasswordModule;
          srp = await computeCheck(passwordObj, text);
        } catch {
          try {
            // GramJS versi lain
            const { computeSRPParams } = require("telegram/Password");
            srp = await computeSRPParams({
              gBytes: passwordObj.currentAlgo.g,
              p: passwordObj.currentAlgo.p,
              salt1: passwordObj.currentAlgo.salt1,
              salt2: passwordObj.currentAlgo.salt2,
              srpId: passwordObj.srpId,
              srpB: passwordObj.srpB,
              password: Buffer.from(text, "utf-8"),
            });
          } catch {
            // Fallback: pakai internal method client
            srp = await sess.client._computePasswordSrp(text, passwordObj);
          }
        }

        await sess.client.invoke(new Api.auth.CheckPassword({ password: srp }));
        await finishLogin(ctx, userId, sess.client);
      } catch (e) {
        loginSessions.delete(userId);
        try { await sess.client.disconnect(); } catch {}
        await ctx.reply(`❌ Password 2FA salah: ${e.message}\n\nCoba lagi dengan /buat`);
      }
      return;
    }

    return next();
  });

  // ── Finish login: simpan session, spawn userbot ───────────────
  async function finishLogin(ctx, userId, client) {
    const sessionString = client.session.save();
    const me = await client.getMe();
    const name = `${me.firstName || ""}${me.lastName ? " " + me.lastName : ""}`.trim();

    // Simpan ke ubots.json
    const existing = ubotManager.getUser(userId) || {};
    ubotManager.saveUser(userId, {
      ...existing,
      session: sessionString,
      name,
      telegramId: me.id.toString(),
      status: "active",
      loginAt: Date.now(),
    });

    loginSessions.delete(String(userId));

    await ctx.reply(
      `✅ <b>Login berhasil!</b>\n\n` +
      `👤 <b>Akun:</b> ${name}\n` +
      `📱 <b>ID:</b> <code>${me.id}</code>\n\n` +
      `⏳ Memulai userbot...`,
      { parse_mode: "HTML" }
    );

    // Spawn userbot
    try {
      await ubotManager.startUserbot(userId, sessionString, bot);
      await ctx.reply(
        `🚀 <b>Userbot aktif!</b>\n\n` +
        `Sekarang kamu bisa pakai command seperti <code>${config.prefix}menu</code> ` +
        `di mana saja — grup, DM, atau saved messages.`,
        { parse_mode: "HTML" }
      );
    } catch (e) {
      await ctx.reply(`⚠️ Login tersimpan tapi gagal spawn userbot: ${e.message}\nCoba /restart`);
    }
  }

  // ══════════════════════════════════════════════════════════════
  //   CALLBACK — stop & start userbot
  // ══════════════════════════════════════════════════════════════
  bot.action("ubot:stop", async (ctx) => {
    await ctx.answerCbQuery();
    const userId = ctx.from.id;
    const stopped = await ubotManager.stopUserbot(userId);
    await ctx.reply(stopped ? "⏹ Userbot dihentikan." : "⚠️ Userbot tidak sedang aktif.");
  });

  bot.action("ubot:start", async (ctx) => {
    await ctx.answerCbQuery();
    const userId = ctx.from.id;
    const data = ubotManager.getUser(userId);
    if (!data?.session) return ctx.reply("❌ Belum ada session. Gunakan /buat dulu.");
    try {
      await ubotManager.startUserbot(userId, data.session, bot);
      await ctx.reply("✅ Userbot berhasil dijalankan kembali!");
    } catch (e) {
      await ctx.reply(`❌ Gagal start: ${e.message}`);
    }
  });

  bot.action("ubot:status", async (ctx) => {
    await ctx.answerCbQuery();
    ctx.message = ctx.callbackQuery.message;
    ctx.from = ctx.callbackQuery.from;
    const userId = ctx.from.id;
    const data = ubotManager.getUser(userId);
    const running = ubotManager.isRunning(userId);
    const expText = data?.expiry
      ? `⏳ <b>Expiry:</b> ${new Date(data.expiry).toLocaleDateString("id-ID")}`
      : "⏳ <b>Expiry:</b> Selamanya";
    await ctx.reply(
      `📊 <b>Status Userbot</b>\n\n` +
      `👤 <b>Akun:</b> ${data?.name || "-"}\n` +
      `📡 <b>Running:</b> ${running ? "✅ Aktif" : "❌ Mati"}\n` +
      `${expText}`,
      { parse_mode: "HTML" }
    );
  });

  // ══════════════════════════════════════════════════════════════
  //   OWNER COMMANDS
  // ══════════════════════════════════════════════════════════════

  // /beriakses @user [hari] — beri akses manual
  bot.command("beriakses", async (ctx) => {
    if (!canGiveAccess(ctx)) return ctx.reply("❌ Tidak punya izin.");
    const args = ctx.message.text.split(" ").slice(1);
    const targetId = args[0]?.replace("@", "");
    const days = parseInt(args[1]) || 0; // 0 = permanen

    if (!targetId) {
      return ctx.reply(
        "❌ Format salah.\nGunakan: <code>/beriakses USER_ID [hari]</code>\n" +
        "Contoh: <code>/beriakses 123456789 30</code>\n" +
        "Biarkan hari kosong untuk akses permanen.",
        { parse_mode: "HTML" }
      );
    }

    const expiry = days > 0 ? Date.now() + days * 24 * 60 * 60 * 1000 : null;
    ubotManager.saveUser(targetId, {
      hasAccess: true,
      expiry,
      grantedBy: ctx.from.id,
      grantedAt: Date.now(),
    });

    const expText = days > 0 ? `${days} hari` : "Permanen";
    await ctx.reply(
      `✅ <b>Akses diberikan!</b>\n\n` +
      `👤 <b>User ID:</b> <code>${targetId}</code>\n` +
      `⏳ <b>Durasi:</b> ${expText}`,
      { parse_mode: "HTML" }
    );

    // Notif ke user
    try {
      await bot.telegram.sendMessage(
        targetId,
        `🎉 <b>Akses userbot kamu sudah aktif!</b>\n\n` +
        `⏳ <b>Durasi:</b> ${expText}\n\n` +
        `Gunakan /buat untuk mulai setup userbot kamu.`,
        { parse_mode: "HTML" }
      );
    } catch {}
  });

  // /cabutakses USER_ID — cabut akses
  bot.command("cabutakses", async (ctx) => {
    if (!canGiveAccess(ctx)) return ctx.reply("❌ Tidak punya izin.");
    const targetId = ctx.message.text.split(" ")[1];
    if (!targetId) return ctx.reply("❌ Gunakan: <code>/cabutakses USER_ID</code>", { parse_mode: "HTML" });

    await ubotManager.stopUserbot(targetId);
    ubotManager.saveUser(targetId, { hasAccess: false, expiry: null });
    await ctx.reply(`✅ Akses <code>${targetId}</code> dicabut.`, { parse_mode: "HTML" });

    try {
      await bot.telegram.sendMessage(targetId, "⚠️ Akses userbot kamu telah dicabut.");
    } catch {}
  });

  // /setreseller USER_ID — jadikan reseller
  bot.command("setreseller", async (ctx) => {
    if (!isOwner(ctx)) return ctx.reply("❌ Owner only.");
    const targetId = ctx.message.text.split(" ")[1];
    if (!targetId) return ctx.reply("❌ Gunakan: <code>/setreseller USER_ID</code>", { parse_mode: "HTML" });

    ubotManager.saveUser(targetId, { role: "reseller", hasAccess: true, expiry: null });
    await ctx.reply(`✅ <code>${targetId}</code> dijadikan reseller.`, { parse_mode: "HTML" });
  });

  // /daftaruser — lihat semua user
  bot.command("daftaruser", async (ctx) => {
    if (!canGiveAccess(ctx)) return ctx.reply("❌ Tidak punya izin.");
    const all = ubotManager.getAllUsers();
    const entries = Object.entries(all);
    if (!entries.length) return ctx.reply("📭 Belum ada user terdaftar.");

    const lines = entries.map(([id, d]) => {
      const status = ubotManager.isRunning(id) ? "🟢" : "🔴";
      const exp = d.expiry ? new Date(d.expiry).toLocaleDateString("id-ID") : "∞";
      return `${status} <code>${id}</code> — ${d.name || "?"} | ${d.hasAccess ? "✅" : "❌"} | ${exp}`;
    });

    await ctx.reply(
      `👥 <b>Daftar User (${entries.length})</b>\n\n${lines.join("\n")}`,
      { parse_mode: "HTML" }
    );
  });

  // /restart — restart userbot sendiri
  bot.command("restart", async (ctx) => {
    const userId = ctx.from.id;
    const data = ubotManager.getUser(userId);
    if (!data?.session) return ctx.reply("❌ Tidak ada session tersimpan.");

    await ubotManager.stopUserbot(userId);
    try {
      await ubotManager.startUserbot(userId, data.session, bot);
      await ctx.reply("✅ Userbot berhasil di-restart!");
    } catch (e) {
      await ctx.reply(`❌ Gagal restart: ${e.message}`);
    }
  });

  // /info — info bot manager
  bot.command("info", async (ctx) => {
    if (!isOwner(ctx)) return;
    const running = ubotManager.getRunningCount();
    const all = Object.keys(ubotManager.getAllUsers()).length;
    await ctx.reply(
      `📊 <b>Info Bot Manager</b>\n\n` +
      `🤖 <b>Total user:</b> ${all}\n` +
      `🟢 <b>Userbot aktif:</b> ${running}\n` +
      `💾 <b>RAM:</b> ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`,
      { parse_mode: "HTML" }
    );
  });

  // ══════════════════════════════════════════════════════════════
  //   SISTEM PEMBELIAN — /beli
  // ══════════════════════════════════════════════════════════════

  // Simpan transaksi pending: orderId → { userId, paketId, amount, hari, msgId, chatId }
  const pendingPayments = new Map();

  // Helper: buat QR image URL dari string content
  const generateQrImage = (content) =>
    `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(content)}`;

  // Helper: format rupiah
  const formatRp = (n) => `Rp ${Number(n).toLocaleString("id-ID")}`;

  // /beli — tampilkan pilihan paket
  bot.command("beli", async (ctx) => {
    const paket = config.paketUbot;
    if (!paket?.length) return ctx.reply("❌ Paket belum dikonfigurasi. Hubungi owner.");

    const buttons = paket.map((p) => [
      { text: `${p.label} — ${formatRp(p.harga)}`, callback_data: `beli:${p.id}` },
    ]);

    await ctx.reply(
      `🛒 <b>Pilih Paket Ubot</b>\n\n` +
      paket.map((p) => `• <b>${p.label}</b>: ${formatRp(p.harga)}`).join("\n") +
      `\n\n💳 Pembayaran via QRIS (auto-konfirmasi)`,
      {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: buttons },
      }
    );
  });

  // Callback pilih paket → generate QRIS
  bot.action(/^beli:(.+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const userId = ctx.from.id;
    const paketId = ctx.match[1];
    const paket = config.paketUbot?.find((p) => p.id === paketId);

    if (!paket) return ctx.reply("❌ Paket tidak ditemukan.");
    if (!config.pakasir?.apiKey) return ctx.reply("❌ QRIS belum dikonfigurasi. Hubungi owner.");

    // Cek kalau sudah ada transaksi pending dari user ini
    for (const [oid, trx] of pendingPayments.entries()) {
      if (String(trx.userId) === String(userId)) {
        return ctx.reply(
          `⚠️ Kamu masih punya transaksi pending.\n` +
          `Order ID: <code>${oid}</code>\n\n` +
          `Selesaikan dulu atau tunggu expired (5 menit).`,
          { parse_mode: "HTML" }
        );
      }
    }

    const orderId = `UBOT${Date.now()}`;
    const loadingMsg = await ctx.reply("⏳ Membuat QRIS...");

    try {
      const payload = {
        project: config.pakasir.projectSlug,
        order_id: orderId,
        amount: paket.harga,
        api_key: config.pakasir.apiKey,
      };

      const { data } = await axios.post(
        `${config.pakasir.baseUrl}${config.pakasir.endpoints.createQris}`,
        payload
      );

      if (!data?.payment?.payment_number) {
        await bot.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
        return ctx.reply("❌ Gagal buat QRIS. Coba lagi atau hubungi owner.");
      }

      const qrContent = data.payment.payment_number;
      const totalBayar = data.payment.total_payment || paket.harga;
      const qrImageUrl = generateQrImage(qrContent);

      // Kirim gambar QR
      const qrMsg = await bot.telegram.sendPhoto(ctx.chat.id, { url: qrImageUrl }, {
        caption:
          `💳 <b>Pembayaran Ubot — ${paket.label}</b>\n\n` +
          `💵 <b>Total:</b> ${formatRp(totalBayar)}\n` +
          `🆔 <b>Order ID:</b> <code>${orderId}</code>\n\n` +
          `Scan QR di atas lalu bayar.\n` +
          `⏳ Status akan otomatis terupdate (maks 5 menit).`,
        parse_mode: "HTML",
      });

      await bot.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});

      // Simpan pending
      pendingPayments.set(orderId, {
        userId,
        paketId,
        amount: paket.harga,
        hari: paket.hari,
        label: paket.label,
        msgId: qrMsg.message_id,
        chatId: ctx.chat.id,
      });

      // Mulai polling status
      pollPaymentStatus(orderId, bot);

    } catch (err) {
      await bot.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
      ctx.reply(`❌ Error: ${err.response ? JSON.stringify(err.response.data) : err.message}`);
    }
  });

  // Polling status pembayaran
  async function pollPaymentStatus(orderId, bot) {
    const maxTime = 5 * 60 * 1000; // 5 menit
    const interval = 5000; // 5 detik
    const startTime = Date.now();

    const check = async () => {
      const trx = pendingPayments.get(orderId);
      if (!trx) return; // sudah dihapus (selesai/cancel)

      // Timeout
      if (Date.now() - startTime > maxTime) {
        pendingPayments.delete(orderId);
        try {
          await bot.telegram.sendMessage(
            trx.chatId,
            `⏰ Transaksi <code>${orderId}</code> expired.\nGunakan /beli untuk mencoba lagi.`,
            { parse_mode: "HTML" }
          );
        } catch {}
        return;
      }

      try {
        const { data } = await axios.get(
          `${config.pakasir.baseUrl}${config.pakasir.endpoints.checkStatus}`,
          {
            params: {
              project: config.pakasir.projectSlug,
              amount: trx.amount,
              order_id: orderId,
              api_key: config.pakasir.apiKey,
            },
          }
        );

        const status = data?.transaction?.status;

        if (status === "completed") {
          pendingPayments.delete(orderId);
          // Aktifkan akses
          const expiry = trx.hari > 0 ? Date.now() + trx.hari * 24 * 60 * 60 * 1000 : null;
          ubotManager.saveUser(trx.userId, {
            hasAccess: true,
            expiry,
            grantedBy: "payment",
            grantedAt: Date.now(),
          });

          const expText = trx.hari > 0
            ? `${trx.label} (hingga ${new Date(expiry).toLocaleDateString("id-ID")})`
            : "Permanen";

          await bot.telegram.sendMessage(
            trx.chatId,
            `✅ <b>Pembayaran berhasil!</b>\n\n` +
            `🎉 Akses ubot <b>${expText}</b> sudah aktif!\n\n` +
            `Gunakan /buat untuk setup userbot kamu sekarang.`,
            { parse_mode: "HTML" }
          );

          // Log ke owner
          try {
            await bot.telegram.sendMessage(
              config.ownerId,
              `💰 <b>Pembayaran masuk!</b>\n\n` +
              `👤 User ID: <code>${trx.userId}</code>\n` +
              `📦 Paket: ${trx.label}\n` +
              `💵 Nominal: ${formatRp(trx.amount)}\n` +
              `🆔 Order: <code>${orderId}</code>`,
              { parse_mode: "HTML" }
            );
          } catch {}

        } else if (status === "failed" || status === "expired") {
          pendingPayments.delete(orderId);
          await bot.telegram.sendMessage(
            trx.chatId,
            `❌ Transaksi <code>${orderId}</code> ${status}.\nGunakan /beli untuk mencoba lagi.`,
            { parse_mode: "HTML" }
          );
        } else {
          // Masih pending, poll lagi
          setTimeout(check, interval);
        }
      } catch (e) {
        // Error sementara, coba lagi
        setTimeout(check, interval);
      }
    };

    setTimeout(check, interval);
  }

  // /cekbayar ORDER_ID — cek manual status transaksi
  bot.command("cekbayar", async (ctx) => {
    const orderId = ctx.message.text.split(" ")[1];
    if (!orderId) return ctx.reply("❌ Gunakan: <code>/cekbayar ORDER_ID</code>", { parse_mode: "HTML" });

    const trx = pendingPayments.get(orderId);
    if (!trx) return ctx.reply(`❌ Tidak ada transaksi pending dengan ID <code>${orderId}</code>`, { parse_mode: "HTML" });
    if (String(trx.userId) !== String(ctx.from.id) && !isOwner(ctx)) {
      return ctx.reply("❌ Bukan transaksi kamu.");
    }

    await ctx.reply(`🔍 Mengecek status <code>${orderId}</code>...`, { parse_mode: "HTML" });

    try {
      const { data } = await axios.get(
        `${config.pakasir.baseUrl}${config.pakasir.endpoints.checkStatus}`,
        {
          params: {
            project: config.pakasir.projectSlug,
            amount: trx.amount,
            order_id: orderId,
            api_key: config.pakasir.apiKey,
          },
        }
      );
      const t = data?.transaction;
      if (!t) return ctx.reply("❌ Data transaksi tidak ditemukan.");

      await ctx.reply(
        `📊 <b>Status Transaksi</b>\n\n` +
        `🆔 Order: <code>${orderId}</code>\n` +
        `💵 Nominal: ${formatRp(t.amount || trx.amount)}\n` +
        `📌 Status: <b>${t.status}</b>`,
        { parse_mode: "HTML" }
      );
    } catch (e) {
      ctx.reply(`❌ Gagal cek: ${e.message}`);
    }
  });

  // ══════════════════════════════════════════════════════════════
  //       INLINE QUERY HANDLER
  // ══════════════════════════════════════════════════════════════
  bot.on("inline_query", async (ctx) => {
    try {
      const msg = ctx.inlineQuery;
      const body = (msg.query || "").trim();
      const isCmd = body.startsWith(prefix);
      const args = body.split(/ +/).slice(1);
      const text = args.join(" ");
      const command = isCmd
        ? body.slice(prefix.length).trim().split(" ").shift().toLowerCase()
        : body.toLowerCase();

      const getCacheData = (cacheId) => {
        if (!cacheId) return null;
        const data = global.tempData?.[cacheId];
        if (data) delete global.tempData[cacheId];
        return data;
      };

      switch (command) {
        case "menu": {
          return ctx.answerInlineQuery(
            [
              {
                type: "photo",
                id: "menu-1",
                photo_url: "https://files.catbox.moe/vwm0om.jpg",
                thumb_url: "https://files.catbox.moe/vwm0om.jpg",
                caption: getMenuText(ctx),
                parse_mode: "HTML",
                reply_markup: {
                  inline_keyboard: [
                    [{ text: "🏪 Store & Business", callback_data: "menu:store" }],
                    [
                      { text: "☁️ Panel", callback_data: "menu:panel" },
                      { text: "💻 VPS", callback_data: "menu:vps" },
                    ],
                    [
                      { text: "🛠️ Tools", callback_data: "menu:tools" },
                      { text: "📥 Download", callback_data: "menu:download" },
                      { text: "🔍 Search", callback_data: "menu:search" },
                    ],
                    [
                      { text: "👑 Owner", callback_data: "menu:owner" },
                      { text: "Buy Script", callback_data: "menu:buy" },
                    ],
                    [
                      {
                        text: "🌟 Channel Information",
                        url: "https://t.me/aboutzete",
                      },
                    ]
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "menu-owner":
        case "owner": {
          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "owner-1",
                title: "Owner Menu",
                description: "Owner only commands",
                input_message_content: {
                  message_text: getOwnerMenu(),
                  parse_mode: "HTML",
                },
                reply_markup: {
                  inline_keyboard: [
                    [
                      {
                        text: "🔙 Back to Main Menu",
                        callback_data: "menu:main",
                      },
                    ],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "menu-tools":
        case "tools": {
          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "tools-1",
                title: "Tools Menu",
                description: "Tools commands",
                input_message_content: {
                  message_text: getToolsMenu(),
                  parse_mode: "HTML",
                },
                reply_markup: {
                  inline_keyboard: [
                    [
                      {
                        text: "🔙 Back to Main Menu",
                        callback_data: "menu:main",
                      },
                    ],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "menu-payment":
        case "payment": {
          const caption = `<b>List payment pembayaran 🔖</b>\n\n⌯ <b>Dana:</b> <code>${
            config.payment.dana || "-"
          }</code>\n⌯ <b>Ovo:</b> <code>${
            config.payment.ovo || "-"
          }</code>\n⌯ <b>Gopay:</b> <code>${
            config.payment.gopay || "-"
          }</code>\n\n<b>Penting:</b> wajib kirimkan bukti tf! demi keamanan bersama.`;

          if (config.payment?.qris && config.payment.qris.startsWith("http")) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "photo",
                  id: "payment-1",
                  photo_url: config.payment.qris,
                  thumb_url: config.payment.qris,
                  caption,
                  parse_mode: "HTML",
                  reply_markup: {
                    inline_keyboard: [
                      [
                        {
                          text: "🌟 Channel Information",
                          url: "https://t.me/aboutzete",
                        },
                      ],
                    ],
                  },
                },
              ],
              { cache_time: 0 }
            );
          } else {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "payment-2",
                  title: "Payment Info",
                  description: "Payment information",
                  input_message_content: {
                    message_text: caption,
                    parse_mode: "HTML",
                  },
                  reply_markup: {
                    inline_keyboard: [
                      [
                        {
                          text: "🌟 Channel Information",
                          url: "https://t.me/aboutzete",
                        },
                      ],
                    ],
                  },
                },
              ],
              { cache_time: 0 }
            );
          }
        }

        case "cpanel-result": {
          if (!text || !isOwner(ctx)) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan atau sudah kadaluarsa",
                  input_message_content: {
                    message_text:
                      "❌ Data panel tidak ditemukan atau sudah kadaluarsa.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          const { username, password, serverId, ram, disk, cpu, domainClean } =
            cacheData;
          const ramText = ram === "0" ? "Unlimited" : `${ram / 1000}GB`;
          const diskText = disk === "0" ? "Unlimited" : `${disk / 1000}GB`;
          const cpuText = cpu === "0" ? "Unlimited" : `${cpu}%`;

          const teks = `<b>✅ Akun Panel Berhasil Dibuat!</b>\n\n⌯ <b>Server ID:</b> <code>${escapeHTML(
            serverId
          )}</code>\n⌯ <b>Username:</b> <code>${escapeHTML(
            username
          )}</code>\n⌯ <b>Password:</b> <code>${escapeHTML(
            password
          )}</code>\n⌯ <b>Panel:</b> <span class="tg-spoiler">https://${escapeHTML(
            domainClean
          )}</span>\n\n<b>⚙️ Spesifikasi Server Panel</b>\n⌯ <b>RAM:</b> ${ramText}\n⌯ <b>Disk:</b> ${diskText}\n⌯ <b>CPU:</b> ${cpuText}`;

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "panel-result-1",
                title: "📦 Panel Created",
                description: `Panel ${username} created!`,
                input_message_content: {
                  message_text: teks,
                  parse_mode: "HTML",
                  disable_web_page_preview: true,
                },
                reply_markup: {
                  inline_keyboard: [
                    [
                      {
                        text: "🌐 Login Panel",
                        url: `https://${domainClean}/auth/login`,
                      },
                    ],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "cadmin-result": {
          if (!text || !isOwner(ctx)) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan atau sudah kadaluarsa",
                  input_message_content: {
                    message_text:
                      "❌ Data admin tidak ditemukan atau sudah kadaluarsa.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          const { id, username, password, domainClean } = cacheData;
          const teks = `<b>✅ Akun Admin Panel Berhasil Dibuat!</b>\n\n⌯ <b>User ID:</b> <code>${escapeHTML(
            id
          )}</code>\n⌯ <b>Username:</b> <code>${escapeHTML(
            username
          )}</code>\n⌯ <b>Password:</b> <code>${escapeHTML(
            password
          )}</code>\n⌯ <b>Panel:</b> <span class="tg-spoiler">https://${escapeHTML(
            domainClean
          )}</span>`;

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "cadmin-result-1",
                title: "👑 Admin Created",
                description: `Admin ${username} created!`,
                input_message_content: {
                  message_text: teks,
                  parse_mode: "HTML",
                  disable_web_page_preview: true,
                },
                reply_markup: {
                  inline_keyboard: [
                    [
                      {
                        text: "🌐 Login Panel",
                        url: `https://${domainClean}/auth/login`,
                      },
                    ],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "nsfw": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });
          try {
            const cacheData = getCacheData(text);
            if (!cacheData) return ctx.answerInlineQuery([], { cache_time: 1 });

            const { url } = cacheData;
            return ctx.answerInlineQuery(
              [
                {
                  type: "photo",
                  id: `nsfw-photo-${Date.now()}`,
                  title: "Random NSFW",
                  photo_url: url,
                  thumb_url: url,
                  reply_markup: {
                    inline_keyboard: [
                      [{ text: "🖼️ Photo URL", url }],
                    ],
                  },
                },
              ],
              { cache_time: 0, is_personal: true }
            );
          } catch (e) {
            console.error("NSFW inline error:", e);
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
        }

        case "deladmin": {
          if (!isOwner(ctx)) return ctx.answerInlineQuery([], { cache_time: 1 });

          try {
            const res = await fetch(
              `${config.domain}/api/application/users`,
              {
                method: "GET",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${config.apikey}`,
                },
              }
            );
            const data = await res.json();
            const users = data.data || [];
            const admins = users.filter(
              (u) => u.attributes.root_admin === true
            );

            if (!admins.length) {
              return ctx.answerInlineQuery([], { cache_time: 1 });
            }

            const buttons = admins.map((a) => [
              {
                text: `📡 ${a.attributes.username} (ID: ${a.attributes.id})`,
                callback_data: `deladmin|${a.attributes.id}`,
              },
            ]);

            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "deladmin-1",
                  title: "⚠️ Delete Admin",
                  description: "Select admin to delete",
                  input_message_content: {
                    message_text: `<b>⚠️ Hapus Admin Panel</b>\n\nPilih admin yang ingin dihapus:`,
                    parse_mode: "HTML",
                  },
                  reply_markup: { inline_keyboard: buttons },
                },
              ],
              { cache_time: 0 }
            );
          } catch (err) {
            console.error("Error fetch admins:", err);
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
        }

        case "delpanel": {
          if (!isOwner(ctx)) return ctx.answerInlineQuery([], { cache_time: 1 });

          try {
            const res = await fetch(
              `${config.domain}/api/application/servers`,
              {
                method: "GET",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${config.apikey}`,
                },
              }
            );
            const data = await res.json();
            const servers = data.data || [];

            if (!servers.length) {
              return ctx.answerInlineQuery([], { cache_time: 1 });
            }

            const buttons = servers.map((s) => [
              {
                text: `📡 ${s.attributes.name} (ID: ${s.attributes.id})`,
                callback_data: `delpanel|${s.attributes.id}`,
              },
            ]);

            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "delpanel-1",
                  title: "📡 Delete Server",
                  description: "Select server to delete",
                  input_message_content: {
                    message_text: `<b>⚠️ Hapus User & Server Panel</b>\n\nPilih server yang ingin dihapus:`,
                    parse_mode: "HTML",
                  },
                  reply_markup: { inline_keyboard: buttons },
                },
              ],
              { cache_time: 0 }
            );
          } catch (err) {
            console.error("Error fetch servers:", err);
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
        }

        case "proses": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data proses tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          const { text: orderText } = cacheData;
          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "proses-1",
                title: "📦 Processing Order",
                description: orderText,
                input_message_content: {
                  message_text: `<b>✅ Pesanan sedang diproses</b>\n\n📦 ${escapeHTML(
                    orderText
                  )}\n⏰ ${tanggal(
                    Date.now()
                  )}\n\n<i>Thank you for purchasing 🕊️</i>`,
                  parse_mode: "HTML",
                },
                reply_markup: {
                  inline_keyboard: [
                    [
                      {
                        text: "📢 Channel Information",
                        url: config.channelLink,
                      },
                    ],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "cekch":
        case "cekchannel": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          const cacheData = getCacheData(text);
          if (!cacheData) return ctx.answerInlineQuery([], { cache_time: 1 });

          const { text: url } = cacheData;
          const encodedUrl = encodeURIComponent(url);
          const apiUrl = `https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/metadata-proxy?url=${encodedUrl}`;

          try {
            const { data: channelData } = await axios.get(apiUrl, {
              headers: {
                Accept: "application/json, text/plain, */*",
                Authorization:
                  "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY5MzQwNjhiMTE0YWI3MTE5ZmM4NjQ1OCIsImlhdCI6MTc2OTM5MzkzOSwiZXhwIjoxNzY5OTk4NzM5fQ.OidCAKl7zAbum7lgtAqNaFcwV83iXWVtPJAIyVjKHZY",
                "User-Agent":
                  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36",
                Referer: "https://asitha.top/channel-manager",
              },
              timeout: 20000,
            });

            if (!channelData?.name || !channelData?.jid) {
              return ctx.answerInlineQuery(
                [
                  {
                    type: "article",
                    id: `cekch-notfound-${Date.now()}`,
                    title: "❌ Channel tidak ditemukan",
                    description: "Periksa URL channel WhatsApp",
                    input_message_content: {
                      message_text:
                        "❌ Channel WhatsApp tidak ditemukan atau data tidak lengkap.",
                      parse_mode: "HTML",
                    },
                  },
                ],
                { cache_time: 300 }
              );
            }

            const formattedText = `<b>📱 WhatsApp Channel Information</b>\n\n⌯ <b>Nama:</b> ${escapeHTML(
              channelData.name
            )}\n⌯ <b>Followers:</b> ${
              channelData.followers
                ? channelData.followers.toLocaleString()
                : "N/A"
            }\n⌯ <b>ID:</b> <code>${escapeHTML(channelData.jid)}</code>`;

            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: `cekch-${Date.now()}`,
                  title: `📱 ${channelData.name.slice(0, 50)}`,
                  description: channelData.followers
                    ? `${channelData.followers.toLocaleString()} followers`
                    : "No followers data",
                  input_message_content: {
                    message_text: formattedText,
                    parse_mode: "HTML",
                  },
                  reply_markup: {
                    inline_keyboard: [
                      [{ text: "Join Channel", url }],
                    ],
                  },
                },
              ],
              { cache_time: 300 }
            );
          } catch (err) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: `cekch-error-${Date.now()}`,
                  title: "❌ Error",
                  description: "Gagal mengambil data channel",
                  input_message_content: {
                    message_text: `<b>❌ Gagal mengambil data channel.</b>\nError: ${escapeHTML(
                      err.message
                    )}`,
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 300 }
            );
          }
        }

        case "autopromosi": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          const cacheData = getCacheData(text);
          if (!cacheData) return ctx.answerInlineQuery([], { cache_time: 1 });

          const promoText = cacheData.text;
          const adminUrl = `https://t.me/kyounoichi`; // Ganti dengan URL admin yang diinginkan

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: `autopromo-${Date.now()}`,
                title: "Auto Promosi",
                description: "autopromosi",
                input_message_content: {
                  message_text: `${escapeHTML(promoText)}`,
                  parse_mode: "HTML",
                },
                reply_markup: {
                  inline_keyboard: [
                    [{ text: "📞 Contact Admin", url: adminUrl }],
                  ],
                },
              },
            ],
            { cache_time: 300 }
          );
        }

        case "me": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data proses tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          const { teks: orderText, username } = cacheData;
          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "proses-1",
                title: "Me Information",
                description: orderText,
                input_message_content: {
                  message_text: orderText,
                  parse_mode: "HTML",
                },
                reply_markup: {
                  inline_keyboard: [
                    [
                      {
                        text: "🗨️ Profile URL",
                        url: `https://t.me/${username}`,
                      },
                    ],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "installpanel-result": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan atau sudah kadaluarsa",
                  input_message_content: {
                    message_text:
                      "❌ Data install panel tidak ditemukan atau sudah kadaluarsa.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          const { domainpanel, username, password, ipVps, pwVps } = cacheData;
          const teks = `<b>✅ Install Panel Berhasil!</b>\n\n<b>👤 Username:</b> <code>${escapeHTML(
            username
          )}</code>\n<b>🔐 Password:</b> <code>${escapeHTML(
            password
          )}</code>\n<b>🌐 Panel:</b> <span class="tg-spoiler">https://${escapeHTML(
            domainpanel
          )}</span>\n\n<b>Start Wing Command:</b>\n<code>.startwings ${ipVps}|${pwVps}|token_node</code>`;

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "installpanel-1",
                title: "✅ Install Panel Done",
                description: `Panel: ${domainpanel}`,
                input_message_content: {
                  message_text: teks,
                  parse_mode: "HTML",
                  disable_web_page_preview: true,
                },
                reply_markup: {
                  inline_keyboard: [
                    [
                      {
                        text: "🌐 Login Panel",
                        url: `https://${domainpanel}`,
                      },
                    ],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "ai-response": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          const cacheData = getCacheData(text);
          if (!cacheData) return ctx.answerInlineQuery([], { cache_time: 1 });

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "ai-1",
                title: "🤖 AI",
                description: cacheData.answer.slice(0, 80),
                input_message_content: {
                  message_text: `<b>Ai message:</b>\n${escapeHTML(
                    cacheData.answer
                  )}`,
                  parse_mode: "HTML",
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "npm-search": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          const cacheData = getCacheData(text);
          if (!cacheData) return ctx.answerInlineQuery([], { cache_time: 1 });

          let resultText = `<b>🔎 Hasil Search NPM:</b> <code>${text}</code>\n\n`;
          cacheData.res.objects.forEach((pkg, i) => {
            const p = pkg.package;
            resultText += `<b>${i + 1}. ${p.name}</b>\n📌 Version: <code>${
              p.version
            }</code>\n👤 Publisher: <code>${
              p.publisher?.username || "Unknown"
            }</code>\n📄 Desc: ${p.description || "-"}\n🔗 Link: ${
              p.links?.npm
            }\n`;
          });

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "npm-1",
                title: "NPM Search Result",
                description: "NPM Search",
                input_message_content: {
                  message_text: resultText.trim(),
                  parse_mode: "HTML",
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "tiktok-photo": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          try {
            const cacheData = getCacheData(text);
            if (!cacheData) return ctx.answerInlineQuery([], { cache_time: 1 });

            const keyboard = cacheData.imageUrl
              ? [[{ text: "📥 Photo URL", url: cacheData.imageUrl }]]
              : [];

            return ctx.answerInlineQuery(
              [
                {
                  type: "photo",
                  id: `tt-photo-${Date.now()}`,
                  photo_url: cacheData.imageUrl,
                  thumb_url: cacheData.imageUrl,
                  caption: cacheData.caption
                    ? escapeHTML(cacheData.caption)
                    : "🖼️ TikTok Slide Photo",
                  parse_mode: "HTML",
                  reply_markup: { inline_keyboard: keyboard },
                },
              ],
              { cache_time: 0, is_personal: true }
            );
          } catch (e) {
            console.error("TikTok photo inline error:", e);
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
        }

        case "tiktok-audio": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          try {
            const cacheData = getCacheData(text);
            if (!cacheData) return ctx.answerInlineQuery([], { cache_time: 1 });

            const keyboard = cacheData.audioUrl
              ? [[{ text: "📥 Audio URL", url: cacheData.audioUrl }]]
              : [];

            return ctx.answerInlineQuery(
              [
                {
                  type: "audio",
                  id: `tt-audio-${Date.now()}`,
                  performer: "TikTok Sound",
                  title:
                    cacheData.title?.substring(0, 64) || "TikTok Audio",
                  audio_url: cacheData.audioUrl,
                  caption: cacheData.caption
                    ? escapeHTML(cacheData.caption)
                    : "🎵 TikTok Audio",
                  parse_mode: "HTML",
                  reply_markup: { inline_keyboard: keyboard },
                },
              ],
              { cache_time: 0 }
            );
          } catch (e) {
            console.error("TikTok audio inline error:", e);
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
        }

        case "tiktok-video": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          try {
            const cacheData = getCacheData(text);
            if (!cacheData) return ctx.answerInlineQuery([], { cache_time: 1 });

            const keyboard = cacheData.videoUrl
              ? [[{ text: "📥 Video URL", url: cacheData.videoUrl }]]
              : [];

            return ctx.answerInlineQuery(
              [
                {
                  type: "video",
                  id: `tt-video-${Date.now()}`,
                  performer: "TikTok Video",
                  title:
                    cacheData.title?.substring(0, 64) || "TikTok Video",
                  thumb_url:
                    cacheData.cover ||
                    "https://img.icons8.com/color/480/tiktok--v1.png",
                  video_url: cacheData.videoUrl,
                  mime_type: "video/mp4",
                  caption: cacheData.caption
                    ? escapeHTML(cacheData.caption)
                    : "TikTok Video",
                  parse_mode: "HTML",
                  reply_markup: { inline_keyboard: keyboard },
                },
              ],
              { cache_time: 0, is_personal: true }
            );
          } catch (e) {
            console.error("TikTok video inline error:", e);
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
        }

        case "play-result": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          try {
            const cacheData = getCacheData(text);
            if (!cacheData || cacheData.type !== "play-result") {
              return ctx.answerInlineQuery(
                [
                  {
                    type: "article",
                    id: "play-error-1",
                    title: "❌ Error",
                    description: "Data tidak ditemukan",
                    input_message_content: {
                      message_text:
                        "❌ Data lagu tidak ditemukan atau sudah kadaluarsa.",
                      parse_mode: "HTML",
                    },
                  },
                ],
                { cache_time: 1 }
              );
            }

            const { youtubeUrl, audioUrl, title } = cacheData;
            if (!youtubeUrl || !audioUrl || !title) {
              return ctx.answerInlineQuery([], { cache_time: 1 });
            }

            const escapedTitle = escapeHTML(title);
            return ctx.answerInlineQuery(
              [
                {
                  type: "audio",
                  id: `play-${Date.now()}`,
                  title: escapedTitle.substring(0, 64),
                  performer: "YouTube",
                  audio_url: audioUrl,
                  parse_mode: "HTML",
                  reply_markup: {
                    inline_keyboard: [
                      [{ text: "🎥 YouTube Link", url: youtubeUrl }],
                    ],
                  },
                },
              ],
              { cache_time: 0 }
            );
          } catch (error) {
            console.error("Play-result error:", error);
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "play-error-1",
                  title: "❌ Error",
                  description: "Gagal memuat audio",
                  input_message_content: {
                    message_text:
                      "❌ Terjadi kesalahan saat memuat audio.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }
        }

        case "subdomain": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data subdomain tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          const { text: subdomainText } = cacheData;
          if (!subdomainText.includes("|")) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }

          const [host, ip] = subdomainText.split("|").map((v) => v.trim());
          const domains = Object.keys(config.subdomain || {});
          if (!domains.length) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }

          const buttons = domains.map((dom) => [
            {
              text: `🌐 ${dom}`,
              callback_data: `subdo|${dom}|${host}|${ip}`,
            },
          ]);

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "subdo-1",
                title: "🌐 Create Subdomain",
                description: `Host: ${host} | IP: ${ip}`,
                input_message_content: {
                  message_text: `<b>Subdomain Information</b>\n\n⌯ <b>Hostname:</b> <code>${escapeHTML(
                    host
                  )}</code>\n⌯ <b>IP:</b> <code>${escapeHTML(
                    ip
                  )}</code>\n\nPilih domain server:`,
                  parse_mode: "HTML",
                },
                reply_markup: { inline_keyboard: buttons },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "listpanel": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data list panel tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "listpanel-1",
                title: "📊 List Server Panel",
                description: "Daftar semua server panel",
                input_message_content: {
                  message_text: cacheData.teks,
                  parse_mode: "HTML",
                  disable_web_page_preview: true,
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "listadmin": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data list admin tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "listadmin-1",
                title: "📊 List Admin Panel",
                description: "Daftar semua admin panel",
                input_message_content: {
                  message_text: cacheData.teks,
                  parse_mode: "HTML",
                  disable_web_page_preview: true,
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "ping": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data ping tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "ping-1",
                title: "📊 System Status",
                description: "Status sistem dan bot",
                input_message_content: {
                  message_text: cacheData.tt,
                  parse_mode: "HTML",
                  disable_web_page_preview: true,
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "bl": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data blacklist tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "bl-1",
                title: "✅ Blacklist Added",
                description: `Grup ${cacheData.id} ditambahkan ke blacklist`,
                input_message_content: {
                  message_text: `<b>✅ Grup berhasil di blacklist.</b>\nID: <code>${escapeHTML(
                    cacheData.id
                  )}</code>`,
                  parse_mode: "HTML",
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "delbl": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data blacklist tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "delbl-1",
                title: "✅ Blacklist Removed",
                description: `Grup ${cacheData.id} dihapus dari blacklist`,
                input_message_content: {
                  message_text: `<b>✅ Blacklist berhasil dihapus.</b>\nID: <code>${escapeHTML(
                    cacheData.id
                  )}</code>`,
                  parse_mode: "HTML",
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "tourl": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data upload tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "tourl-1",
                title: "🔗 Upload Success",
                description: "Media berhasil diupload ke Catbox",
                input_message_content: {
                  message_text: `<b>✅ Media berhasil diupload</b>\n\n🔗 ${escapeHTML(
                    cacheData.url
                  )}`,
                  parse_mode: "HTML",
                  disable_web_page_preview: true                  
                },
                parse_mode: "HTML",
                reply_markup: {
                  inline_keyboard: [
                    [{ text: "📤 Direct Link", url: cacheData.url }],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "tourl2": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data upload tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "tourl2-1",
                title: "🔗 Upload Success",
                description: "Gambar berhasil diupload ke Pixhost",
                input_message_content: {
                  message_text: `<b>✅ Upload Pixhost berhasil</b>\n\n🖼️ ${escapeHTML(
                    cacheData.url
                  )}`,
                  parse_mode: "HTML",
                  disable_web_page_preview: true
                },
                parse_mode: "HTML",
                reply_markup: {
                  inline_keyboard: [
                    [{ text: "📤 Direct Link", url: cacheData.url }],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "remini": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "remini-error",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data Remini tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "photo",
                id: "remini-1",
                photo_url: cacheData.after,
                thumb_url: cacheData.after,
                caption: `<b>✅ Remini / HD Success</b>`,
                parse_mode: "HTML",
                reply_markup: {
                  inline_keyboard: [
                    [{ text: "📸 Photo URL", url: cacheData.after }],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "jadianime": {
          if (!text) return ctx.answerInlineQuery([], { cache_time: 1 });

          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "jadianime-error",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data jadianime tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "photo",
                id: "remini-1",
                photo_url: cacheData.after,
                thumb_url: cacheData.after,
                caption: `<b>✅ Convert To Anime Style Success</b>`,
                parse_mode: "HTML",
                reply_markup: {
                  inline_keyboard: [
                    [{ text: "📸 Photo URL", url: cacheData.after }],
                  ],
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "eval": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data eval tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "eval-1",
                title: "✅ Eval Result",
                description: "Hasil evaluasi kode",
                input_message_content: {
                  message_text: `<b>✅ Eval berhasil:</b>\n<pre>${escapeHTML(
                    cacheData.result
                  )}</pre>`,
                  parse_mode: "HTML",
                  disable_web_page_preview: true,
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        case "eval-error": {
          if (!isOwner(ctx) || !text) {
            return ctx.answerInlineQuery([], { cache_time: 1 });
          }
          const cacheData = getCacheData(text);
          if (!cacheData) {
            return ctx.answerInlineQuery(
              [
                {
                  type: "article",
                  id: "error-1",
                  title: "❌ Error",
                  description: "Data tidak ditemukan",
                  input_message_content: {
                    message_text: "❌ Data eval error tidak ditemukan.",
                    parse_mode: "HTML",
                  },
                },
              ],
              { cache_time: 1 }
            );
          }

          return ctx.answerInlineQuery(
            [
              {
                type: "article",
                id: "eval-error-1",
                title: "❌ Eval Error",
                description: "Error evaluasi kode",
                input_message_content: {
                  message_text: `<b>❌ Eval error:</b>\n<pre>${escapeHTML(
                    cacheData.error
                  )}</pre>`,
                  parse_mode: "HTML",
                  disable_web_page_preview: true,
                },
              },
            ],
            { cache_time: 0 }
          );
        }

        default:
          return ctx.answerInlineQuery([], { cache_time: 1 });
      }
    } catch (e) {
      console.log("❌ Inline error:", e);
      return ctx.answerInlineQuery([], { cache_time: 1 });
    }
  });

  // ==============================
  //      CALLBACK QUERY HANDLER
  // ==============================
  bot.on("callback_query", async (ctx) => {
    try {
      const data = ctx.callbackQuery.data || "";

      if (data.startsWith("menu:")) {
        const menuType = data.split(":")[1];
        switch (menuType) {
          case "main":
            return ctx.editMessageMedia(
              {
                type: "photo",
                media: "https://files.catbox.moe/vwm0om.jpg",
                caption: getMenuText(ctx),
                parse_mode: "HTML",
              },
              {
                reply_markup: {
                  inline_keyboard: [
                    [{ text: "🏪 Store & Business", callback_data: "menu:store" }],
                    [
                      { text: "☁️ Panel", callback_data: "menu:panel" },
                      { text: "💻 VPS", callback_data: "menu:vps" },
                    ],
                    [
                      { text: "🛠️ Tools", callback_data: "menu:tools" },
                      { text: "📥 Download", callback_data: "menu:download" },
                      { text: "🔍 Search", callback_data: "menu:search" },
                    ],
                    [
                      { text: "👑 Owner", callback_data: "menu:owner" },
                      { text: "Buy Script", callback_data: "menu:buy" },
                    ],
                    [
                      {
                        text: "🌟 Channel Information",
                        url: "https://t.me/aboutzete",
                      },
                    ],
                  ],
                },
              }
            );

          case "store": // from menu:store
            return ctx.editMessageText(getStoreMenu(), {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back to Main Menu",
                      callback_data: "menu:main",
                    },
                  ],
                ],
              },
            });

          case "panel": // from menu:panel
            return ctx.editMessageText(getPanelMenu(), {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back to Main Menu",
                      callback_data: "menu:main",
                    },
                  ],
                ],
              },
            });

          case "owner": // from menu:owner
            return ctx.editMessageText(getOwnerMenu(), {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back to Main Menu",
                      callback_data: "menu:main",
                    },
                  ],
                ],
              },
            });

          case "tools": // from menu:tools
            return ctx.editMessageText(getToolsMenu(), {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back to Main Menu",
                      callback_data: "menu:main",
                    },
                  ],
                ],
              },
            });

          case "download": // from menu:download
            return ctx.editMessageText(getDownloadMenu(), {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back to Main Menu",
                      callback_data: "menu:main",
                    },
                  ],
                ],
              },
            });

          case "search": // from menu:search
            return ctx.editMessageText(getSearchMenu(), {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back to Main Menu",
                      callback_data: "menu:main",
                    },
                  ],
                ],
              },
            });

          case "vps": // from menu:vps
            return ctx.editMessageText(getVpsMenu(), {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back to Main Menu",
                      callback_data: "menu:main",
                    },
                  ],
                ],
              },
            });

          case "buy": {
            const developerUsername = "kyounoichi"; // Diambil dari konteks file
            const scriptPrice = "Rp 25.000"; // Anda bisa mengubah harga ini
            const buyText = `<b>Buy Script</b>\n\n<b>Harga:</b> ${scriptPrice}\n\nSilakan hubungi developer untuk melakukan pembelian.`;
            return ctx.editMessageText(buyText, {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "Hubungi Developer", url: `https://t.me/${developerUsername}` }
                        ],
                        [
                            { text: "🔙 Back to Main Menu", callback_data: "menu:main" }
                        ]
                    ]
                }
            });
          }

          default:
            return ctx.answerCbQuery("❌ Menu tidak ditemukan");
        }
      }

      if (data.startsWith("delpanel|")) {
        if (!isOwner(ctx)) return;
        const [, serverId] = data.split("|");
        await ctx.answerCbQuery("⏳ Memproses hapus server...");

        try {
          const [serverRes, userRes] = await Promise.all([
            fetch(`${config.domain}/api/application/servers/${serverId}`, {
              method: "GET",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${config.apikey}`,
              },
            }),
            fetch(`${config.domain}/api/application/users`, {
              method: "GET",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${config.apikey}`,
              },
            }),
          ]);

          const server = (await serverRes.json()).attributes;
          const users = (await userRes.json()).data || [];

          if (!server) {
            return ctx.editMessageText(`❌ Server ID ${serverId} tidak ditemukan`, {
              parse_mode: "HTML",
            });
          }

          const delServer = await fetch(
            `${config.domain}/api/application/servers/${serverId}`,
            {
              method: "DELETE",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${config.apikey}`,
              },
            }
          );

          if (!delServer.ok) throw new Error("Gagal hapus server");

          const serverNameLower = server.name.toLowerCase();
          const user = users.find(
            (u) =>
              u.attributes.first_name &&
              u.attributes.first_name.toLowerCase() === serverNameLower
          );

          if (user) {
            await fetch(
              `${config.domain}/api/application/users/${user.attributes.id}`,
              {
                method: "DELETE",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${config.apikey}`,
                },
              }
            );
          }

          return ctx.editMessageText(
            `<b>✅ Server ${escapeHTML(
              server.name
            )} (ID: ${serverId}) berhasil dihapus beserta user terkait!</b>`,
            {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back To List Server",
                      callback_data: "delpanel-back",
                    },
                  ],
                ],
              },
            }
          );
        } catch (err) {
          console.error("❌ Hapus server error:", err);
          return ctx.editMessageText(
            `<b>❌ Gagal hapus server ID ${serverId}!</b>\n${escapeHTML(
              err.message
            )}`,
            {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔄 Back To List Server",
                      callback_data: "delpanel-back",
                    },
                  ],
                ],
              },
            }
          );
        }
      }

      if (data === "delpanel-back") {
        if (!isOwner(ctx)) return;
        await ctx.answerCbQuery("🔄 Menampilkan daftar server...");

        const serverRes = await fetch(
          `${config.domain}/api/application/servers`,
          {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${config.apikey}`,
            },
          }
        );
        const servers = (await serverRes.json()).data || [];

        if (!servers.length) {
          return ctx.editMessageText("⚠️ Tidak ada server tersedia.", {
            parse_mode: "HTML",
          });
        }

        const buttons = servers.map((s) => [
          {
            text: `📡 ${s.attributes.name} (ID: ${s.attributes.id})`,
            callback_data: `delpanel|${s.attributes.id}`,
          },
        ]);

        return ctx.editMessageText(
          `<b>⚠️ Hapus User & Server Panel</b>\n\nPilih server yang ingin dihapus:`,
          {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: buttons },
          }
        );
      }

      if (data.startsWith("subdo|")) {
        if (!isOwner(ctx)) return;
        const [, domain, host, ip] = data.split("|");
        const api = config.subdomain[domain];
        if (!api) return ctx.answerCbQuery("❌ Domain tidak valid!");

        await ctx.answerCbQuery("⏳ Memproses...");

        const cleanHost = host.replace(/[^a-z0-9.-]/gi, "").toLowerCase();
        const cleanIp = ip.replace(/[^0-9.]/g, "");
        const rand = Math.floor(100 + Math.random() * 900);
        const panel = `${cleanHost}.${domain}`;
        const node = `node${rand}.${cleanHost}.${domain}`;

        async function createSub(name) {
          const res = await axios.post(
            `https://api.cloudflare.com/client/v4/zones/${api.zone}/dns_records`,
            {
              type: "A",
              name,
              content: cleanIp,
              ttl: 3600,
              proxied: false,
            },
            {
              headers: {
                Authorization: `Bearer ${api.apitoken}`,
                "Content-Type": "application/json",
              },
            }
          );
          if (!res.data.success) {
            throw new Error(
              res.data.errors?.[0]?.message || "Gagal membuat subdomain"
            );
          }
        }

        try {
          await createSub(panel);
          await createSub(node);

          return ctx.editMessageText(
            `<b>✅ Subdomain berhasil dibuat!</b>\n\n⌯ <b>Panel:</b>\n<code>${escapeHTML(
              panel
            )}</code>\n⌯ <b>Node:</b>\n<code>${escapeHTML(
              node
            )}</code>\n⌯ <b>IP:</b>\n<code>${escapeHTML(cleanIp)}</code>`,
            { parse_mode: "HTML" }
          );
        } catch (e) {
          return ctx.editMessageText(
            `<b>❌ Gagal membuat subdomain!</b>\n${escapeHTML(e.message)}`,
            {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back to Main Menu", callback_data: "menu:main"
                    },
                    {
                      text: "🔄 Buat Ulang Subdomain",
                      callback_data: `retry|${host}|${ip}`,
                    },
                  ],
                ],
              },
            }
          );
        }
      }

      if (data.startsWith("retry|")) {
        if (!isOwner(ctx)) return;
        const [, host, ip] = data.split("|");
        await ctx.answerCbQuery("🔄 Pilih domain lagi...");

        const buttons = Object.keys(config.subdomain).map((dom) => [
          {
            text: `🌐 ${dom}`,
            callback_data: `subdo|${dom}|${host}|${ip}`,
          },
        ]);

        return ctx.editMessageText(
          `⌯ <b>Hostname:</b> <code>${escapeHTML(
            host
          )}</code>\n⌯ <b>IP:</b> <code>${escapeHTML(
            ip
          )}</code>\n\nPilih domain server:`,
          {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: buttons },
          }
        );
      }

      if (data.startsWith("deladmin|")) {
        if (!isOwner(ctx)) return;
        const [, userId] = data.split("|");
        await ctx.answerCbQuery("⏳ Memproses hapus admin...");

        try {
          const res = await fetch(`${config.domain}/api/application/users`, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${config.apikey}`,
            },
          });
          const users = (await res.json()).data || [];
          const targetAdmin = users.find(
            (u) =>
              u.attributes.id == userId && u.attributes.root_admin === true
          );

          if (!targetAdmin) throw new Error("Admin tidak ditemukan!");

          const delRes = await fetch(
            `${config.domain}/api/application/users/${userId}`,
            {
              method: "DELETE",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${config.apikey}`,
              },
            }
          );

          if (!delRes.ok) {
            const errData = await delRes.json();
            throw new Error(
              errData.errors?.[0]?.detail || "Gagal menghapus admin"
            );
          }

          return ctx.editMessageText(
            `<b>✅ Admin ${escapeHTML(
              targetAdmin.attributes.username
            )} berhasil dihapus!</b>`,
            {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔙 Back To List Admin",
                      callback_data: "deladmin-back",
                    },
                  ],
                ],
              },
            }
          );
        } catch (err) {
          console.error("❌ Hapus admin error:", err);
          return ctx.editMessageText(
            `<b>❌ Gagal hapus admin!</b>\n${escapeHTML(err.message)}`,
            {
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "🔄 Back To List Admin",
                      callback_data: "deladmin-back",
                    },
                  ],
                ],
              },
            }
          );
        }
      }

      if (data === "deladmin-back") {
        if (!isOwner(ctx)) return;
        await ctx.answerCbQuery("🔄 Menampilkan daftar admin...");

        const res = await fetch(`${config.domain}/api/application/users`, {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.apikey}`,
          },
        });
        const users = (await res.json()).data || [];
        const admins = users.filter((u) => u.attributes.root_admin === true);

        if (!admins.length) {
          return ctx.editMessageText("⚠️ Tidak ada admin tersedia.", {
            parse_mode: "HTML",
          });
        }

        const buttons = admins.map((a) => [
          {
            text: `🗑️ ${a.attributes.username} (ID: ${a.attributes.id})`,
            callback_data: `deladmin|${a.attributes.id}`,
          },
        ]);

        return ctx.editMessageText(
          `<b>⚠️ Hapus Admin Panel</b>\n\nPilih admin yang ingin dihapus:`,
          {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: buttons },
          }
        );
      }
    } catch (err) {
      console.log("❌ Callback error:", err);
      try {
        await ctx.editMessageText("❌ Terjadi kesalahan.");
      } catch {}
    }
  });
};

// ==============================
//         HOT RELOAD
// ==============================
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  delete require.cache[file];
  require(file);
});